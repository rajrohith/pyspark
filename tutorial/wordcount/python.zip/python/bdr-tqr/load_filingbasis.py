from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

url = config.get('tqr','trmurl')
userId = config.get('tqr','userId')
passwordVal = config.get('tqr','passwordVal')
TimeOut = config.get('tqr','TimeOut')
dbschema=config.get('tqr','trmdbschema')
dataload_dt = config.get('tqr','dataload_dt')
spark = SparkSession \
    .builder \
    .appName("Tqrs filing App") \
    .enableHiveSupport()\
    .getOrCreate()



#url ="jdbc:oracle:thin:@fqt-tmng-db-1.fqt.uspto.gov:1612/TRMNGFQT12"

fb_query="""SELECT TM.TRADEMARK_GID,TM.SERIAL_NUM_TX serial_no,TMFB.FK_FILING_BASIS_CD AS filing_basis_cd ,TMFB.current_in,TMFB.amended_in,TMFB.filed_in
FROM """+dbschema+""".TRADEMARK TM JOIN """+dbschema+""".TM_FILING_BASIS TMFB ON TMFB.FK_TRADEMARK_GID = TM.TRADEMARK_GID
WHERE TMFB.create_ts >= to_timestamp("""+dataload_dt+""", 'YYYY-MM-DD HH24:MI:SS') """


max_dt_df= spark.sql("select max(load_ts) from tqr.job_control where job_nm = 'filingbasis' ")
trm_fb_dt=max_dt_df.collect()[0][0]

if str(trm_fb_dt) =='None':
    fb_query = fb_query  

else:
    trm_fb_dt = str(trm_fb_dt)[: -7]
    fb_query += " And TMFB.last_mod_ts   > to_timestamp('"+str(trm_fb_dt)+"', 'YYYY-MM-DD HH24:MI:SS')    "

print("fb_query is " + fb_query )
tmpDF = spark.read.jdbc(url,"("+fb_query+")", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut} )
tmpDF.createOrReplaceTempView("event_filingbasis")
#spark.sql("DROP TABLE IF EXISTS tqr.src_trm_filing_basis ")

spark.sql("Insert into table tqr.src_trm_filing_basis  select distinct *,current_timestamp as create_ts,'etl' as create_job_id,current_timestamp as last_mod_ts,'etl' as last_mod_job_id   from event_filingbasis")

spark.sql(" insert into tqr.job_control select * from (select 'filingbasis' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl') tab ")
spark.sql("insert into tqr.job_log select   'tqr-load_filingbasis',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(tmpDF.count())+",'filing basis count'")


spark.stop()
