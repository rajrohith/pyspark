from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
import json
import requests
from io import BytesIO
from datetime import datetime
import sys,os
import traceback
import ConfigParser
import urllib, json

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')
dataload_dt=config.get('tqr','dataload_dt')
conf = SparkConf().setAppName('tqr-Report')
conf = conf.setMaster("yarn-client")
sc = SparkContext(conf=conf)
date = sys.argv[2]
date_new = date.replace("$"," ")
hive =  HiveContext(sc)

hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")
hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","20")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')
mysqlurl = config.get('tqr','mysqlurl')
userId = config.get('tqr','mysqluserId')
passwordVal = config.get('tqr','mysqlpasswordVal')
mysqltablename = config.get('tqr','tablename1')

my_sqlhost=config.get('tqr','mysqlhost')
my_sqlport=config.get('tqr','mysqlport')
my_sqldatabase=config.get('tqr','mysqldatabase')
def getsearchSufficient(serial_no):
	data = json.loads(str(serial_no))
	searchSufficient='false'
	if("sufficient" in data['search']):
		if data['search']['sufficient']=='yes':
			searchSufficient='true'
	return   searchSufficient


def getSound(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedSound=[]
	taggedunSound=[]
	for keys,values in data['detail'].items():
		for keys1,values1 in data['detail'][keys].items():
		  if(keys1=='new'):
			if data['detail'][keys]['new']['sound']=='sound':
				taggedSound.append(keys)
           
	return   ' '.join(list(set(taggedSound)))
    except Exception as ex:
        return "error"
        #return "0"
def getUnSound(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedunSound=[]
	for keys,values in data['detail'].items():
		for keys1,values1 in data['detail'][keys].items():
		  if(keys1=='new'):
			if data['detail'][keys]['new']['sound']=='unsound':
				taggedunSound.append(keys)
           
	return   ' '.join(list(set(taggedunSound)))
    except Exception as ex:
        return "error"
        #return "0"

def getMissedtagged(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedMissed=[]
	for keys,values in data['missedNewIssues'].items():
		if(keys=='issues'):
			for missedkeys,missedvalues in data['missedNewIssues']['issues'].items():
			#    print "{0} = {1}".format(key, data['detail'].items())
				for missedkeys1,missedvalues1 in data['missedNewIssues']['issues'][missedkeys].items():
					 if data['missedNewIssues']['issues'][missedkeys]['type']=='missed':
						 taggedMissed.append(missedkeys)
		else:
			for missedkeys,missedvalues in data['missedNewIssues'].items():
				for missedkeys1,missedvalues1 in data['missedNewIssues'][missedkeys].items():
					if data['missedNewIssues'][missedkeys]['type']=='missed':
						 taggedMissed.append(missedkeys)										 
	return   ' '.join(list(set(taggedMissed)))
    except Exception as ex:
        return "error"

def getNewtagged(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	getNewtagged=[]
	for keys,values in data['missedNewIssues'].items():
		if(keys=='issues'):
			for missedkeys,missedvalues in data['missedNewIssues']['issues'].items():
			#    print "{0} = {1}".format(key, data['detail'].items())
				for missedkeys1,missedvalues1 in data['missedNewIssues']['issues'][missedkeys].items():
					 if data['missedNewIssues']['issues'][missedkeys]['type']=='new':
						 getNewtagged.append(missedkeys)
		else:
			for missedkeys,missedvalues in data['missedNewIssues'].items():
				for missedkeys1,missedvalues1 in data['missedNewIssues'][missedkeys].items():
					if data['missedNewIssues'][missedkeys]['type']=='new':
						 getNewtagged.append(missedkeys)
	return   ' '.join(list(set(getNewtagged)))
    except Exception as ex:
        return "error"

def getWritingtaggedExcellent(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedWritingExcellent=[]
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='writing'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['writing'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['writing']['status']=='Excellent':
										taggedWritingExcellent.append(Soundkeys)
													 
	return    ' '.join(list(set(taggedWritingExcellent)))
    except Exception as ex:
        return "error"

def getWritingtaggedDeficient(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedWritingDeficient=[]
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='writing'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['writing'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['writing']['status']=='Deficient':
										taggedWritingDeficient.append(Soundkeys)
	return   ' '.join(list(set(taggedWritingDeficient)))
    except Exception as ex:
        return "error"

def getWritingtaggedSatisfactory(serial_no): 
    try:  
        data = json.loads(str(serial_no))
	taggedWritingSatisfactory=[]
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='writing'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['writing'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['writing']['status']=='Satisfactory':
										taggedWritingSatisfactory.append(Soundkeys)
	return   ' '.join(list(set(taggedWritingSatisfactory)))
    except Exception as ex:
        return "error"

def getEvidencetaggedSatisfactory(serial_no): 
    try:  
	taggedevidenceSatisfactory=[]
        data = json.loads(str(serial_no))
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='evidence'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['evidence'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['evidence']['status']=='Satisfactory':
										taggedevidenceSatisfactory.append(Soundkeys)
	return   ' '.join(list(set(taggedevidenceSatisfactory)))
    except Exception as ex:
        return "error"

def getEvidencetaggedExcellent(serial_no): 
    try:  
	taggedevidenceExcellent=[]
        data = json.loads(str(serial_no))
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='evidence'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['evidence'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['evidence']['status']=='Excellent':
										taggedevidenceExcellent.append(Soundkeys)
	return   ' '.join(list(set(taggedevidenceExcellent)))
    except Exception as ex:
        return "error"

def getEvidencetaggedDeficient(serial_no): 
    try:  
	taggedevidenceDeficient=[]
        data = json.loads(str(serial_no))
	for Soundkeys,Soundvalues in data['detail'].items():
		for Soundkeys1,Soundvalues1 in data['detail'][Soundkeys].items():
			if (Soundkeys1 =='new'):
					for evidencekeys3,evidencevalues3 in data['detail'][Soundkeys]['new'].items():
						if (evidencekeys3 =='evidence'):
							for evidencekeys4,evidencevalues4 in data['detail'][Soundkeys]['new']['evidence'].items():
								if (evidencekeys4 =='status'): 
									if data['detail'][Soundkeys]['new']['evidence']['status']=='Deficient':
										taggedevidenceDeficient.append(Soundkeys)
	return   ' '.join(list(set(taggedevidenceDeficient)))
    except Exception as ex:
        return "error"
'''
def getStatus(saveSound,saveUnSound,saveMissedtagged ,saveMissedtagged ,saveNewtagged ,saveWritingExcellent ,saveWritingSatisfactory ,saveWritingDeficient ,saveEvidenceExcellent ,saveEvidenceSatisfactory ,saveEvidenceDeficient )
    try:
	if(saveSound == 'error' or saveUnSound == 'error' or saveMissedtagged  == 'error' or saveMissedtagged  == 'error' or saveNewtagged  == 'error' or saveWritingExcellent  == 'error' or saveWritingSatisfactory  == 'error' or saveWritingDeficient  == 'error' or saveEvidenceExcellent  == 'error' or saveEvidenceSatisfactory  == 'error' or saveEvidenceDeficient == 'error'):
		return "error"
	else:
		return "success"		
    except Exception as ex:
        return "test"	
'''	
saveSound = udf(getSound)
saveUnSound = udf(getUnSound)
saveMissedtagged = udf(getMissedtagged)
saveNewtagged = udf(getNewtagged)
saveWritingExcellent = udf(getWritingtaggedExcellent)
saveWritingSatisfactory = udf(getWritingtaggedSatisfactory)
saveWritingDeficient = udf(getWritingtaggedDeficient)
saveEvidenceExcellent = udf(getEvidencetaggedExcellent)
saveEvidenceSatisfactory = udf(getEvidencetaggedSatisfactory)
saveEvidenceDeficient = udf(getEvidencetaggedDeficient)
savesearchSufficient = udf(getsearchSufficient)
#saveStatus=udf(getStatus)
def getData(appids):
    appids = appids.repartition(10)
    appids = appids.withColumn("soundTaggedElements",saveSound(appids[0]))
    appids = appids.withColumn("unsoundTaggedElements",saveUnSound(appids[0]))
    appids = appids.withColumn("missedTaggedElements",saveMissedtagged(appids[0]))
    appids = appids.withColumn("newTaggedElements",saveNewtagged(appids[0]))
    appids = appids.withColumn("writingExcellentTaggedElements",saveWritingExcellent(appids[0]))
    appids = appids.withColumn("writingSatisfactoryTaggedElements",saveWritingSatisfactory(appids[0]))
    appids = appids.withColumn("writingDeficientTaggedElements",saveWritingDeficient(appids[0]))
    appids = appids.withColumn("evidenceDeficientTaggedElements",saveEvidenceDeficient(appids[0]))
    appids = appids.withColumn("evidenceSatisfactoryTaggedElements",saveEvidenceSatisfactory(appids[0]))
    appids = appids.withColumn("evidenceExcellentTaggedElements",saveEvidenceExcellent(appids[0]))
    appids = appids.withColumn("searchSufficientIndicator",savesearchSufficient(appids[0]))
    #appids = appids.withColumn("status",saveStatus)
    appids.createOrReplaceTempView("event_search")
    
    appids.count()

    hive.sql("Drop table if exists tqr.tqr_detail_metrics_new ")
    hive.sql("create table  tqr.tqr_detail_metrics_new as select cast(eventInventoryId as int) eventInventoryId ,cast(qualityReviewId as int) qualityReviewId ,cast(reviewTypeCode as int) reviewTypeCode ,serialNumber,sourceEventDate,examinerEmployeeNumber,organizationCode, \
searchPresentIndicator,reviewerEmployeeNumber,reviewStatusTs,assignedTs,completedTs,financialYear,financialQuarter,soundTaggedElements,unsoundTaggedElements,missedTaggedElements,newTaggedElements,writingExcellentTaggedElements,writingSatisfactoryTaggedElements,writingDeficientTaggedElements,evidenceDeficientTaggedElements,evidenceSatisfactoryTaggedElements,evidenceExcellentTaggedElements ,cast(searchSufficientIndicator as boolean), \
    case when cast(Length(trim(missedTaggedElements )) as int) > 0   then true else false end as missedIssuesIndicator, \
    case when cast(Length(trim(newTaggedElements )) as int ) > 0    then true else false end as newIssuesIndicator, \
    case when cast(Length(trim(missedTaggedElements)) as int ) > 0 or  cast(Length(trim(unsoundTaggedElements)) as int ) > 0   then true else false end as overallDeficientIndicator, \
    case when cast(Length(trim(evidenceDeficientTaggedElements)) as int ) > 0    then true else false end as evidenceDeficientIndicator, \
    case when cast(Length(trim(evidenceSatisfactoryTaggedElements)) as int ) > 0    then true else false end as evidenceSatisfactoryIndicator, \
    case when cast(Length(trim(evidenceExcellentTaggedElements)) as int ) > 0    then true else false end as evidenceExcellentIndicator, \
    case when cast(Length(trim(writingDeficientTaggedElements)) as int ) > 0    then true else false end as writingDeficientIndicator, \
    case when cast(Length(trim(writingSatisfactoryTaggedElements)) as int ) > 0    then true else false end as writingSatisfactoryIndicator, \
    case when cast(Length(trim(writingExcellentTaggedElements)) as int ) > 0    then true else false end as writingExcellentIndicator, \
    current_timestamp as create_ts,'etl' as create_job_id,current_timestamp as last_mod_ts ,'etl' as last_mod_user_id  FROM event_search \
    	Where soundTaggedElements <> 'error' or writingSatisfactoryTaggedElements <> 'error' or writingDeficientTaggedElements <> 'error'  \
	or evidenceDeficientTaggedElements <> 'error' or evidenceSatisfactoryTaggedElements <> 'error' or evidenceExcellentTaggedElements <> 'error' ")

    TaggedElementdf=hive.sql(" Select * from tqr.tagged_element " )
    TaggedElementdf.createOrReplaceTempView("STND_TAGGED_ELEMENT")
    reportdf= hive.sql("select distinct qualityreviewid ,trim(exp.soundTaggedElements) soundTaggedElements,trim(exp2.unsoundTaggedElements) unsoundTaggedElements,trim(exp3.missedTaggedElements) missedTaggedElements , \
	trim(exp4.newTaggedElements) newTaggedElements,trim(exp5.writingExcellentTaggedElements) writingExcellentTaggedElements,trim(exp6.writingSatisfactoryTaggedElements) writingSatisfactoryTaggedElements, trim(exp7.writingDeficientTaggedElements) writingDeficientTaggedElements , \
	trim(exp8.evidenceDeficientTaggedElements ) evidenceDeficientTaggedElements ,trim(exp9.evidenceSatisfactoryTaggedElements) evidenceSatisfactoryTaggedElements,trim(exp10.evidenceExcellentTaggedElements ) evidenceExcellentTaggedElements \
	from  tqr.tqr_detail_metrics_new \
	lateral view explode(split(soundTaggedElements,' ')) exp as soundTaggedElements \
	lateral view explode(split(unsoundTaggedElements ,' ')) exp2 as unsoundTaggedElements \
	lateral view explode(split(missedTaggedElements,' ')) exp3 as missedTaggedElements  \
	lateral view explode(split(newTaggedElements,' ')) exp4 as newTaggedElements \
	lateral view explode(split(writingExcellentTaggedElements,' ')) exp5 as writingExcellentTaggedElements  \
	lateral view explode(split(writingSatisfactoryTaggedElements,' ')) exp6 as writingSatisfactoryTaggedElements  \
	lateral view explode(split(writingDeficientTaggedElements,' ')) exp7 as writingDeficientTaggedElements \
	lateral view explode(split(evidenceDeficientTaggedElements,' ')) exp8 as evidenceDeficientTaggedElements \
	lateral view explode(split(evidenceSatisfactoryTaggedElements,' ')) exp9 as evidenceSatisfactoryTaggedElements \
	lateral view explode(split(evidenceExcellentTaggedElements,' ')) exp10 as evidenceExcellentTaggedElements ")

    reportdf.createOrReplaceTempView("report")		

    dfFinal=hive.sql("select distinct a.qualityreviewid  , b.tagged_element_nm as soundTaggedElements,c.tagged_element_nm as unsoundTaggedElements, \
	d.tagged_element_nm as missedTaggedElements,e.tagged_element_nm as newTaggedElements ,f.tagged_element_nm as writingExcellentTaggedElements, \
	g.tagged_element_nm as writingSatisfactoryTaggedElements ,h.tagged_element_nm as writingDeficientTaggedElements,i.tagged_element_nm as evidenceDeficientTaggedElements , \
	j.tagged_element_nm as evidenceSatisfactoryTaggedElements,k.tagged_element_nm as evidenceExcellentTaggedElements \
	from report a \
	left join STND_TAGGED_ELEMENT b on COALESCE(a.soundtaggedelements,'x')=COALESCE(b.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  c on COALESCE(a.unsoundTaggedElements,'x')=COALESCE(c.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  d on COALESCE(a.missedTaggedElements,'x')=COALESCE(d.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  e on COALESCE(a.newTaggedElements,'x')=COALESCE(e.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  f on COALESCE(a.writingExcellentTaggedElements,'x')=COALESCE(f.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  g on COALESCE(a.writingSatisfactoryTaggedElements,'x')=COALESCE(g.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  h on COALESCE(a.writingDeficientTaggedElements,'x')=COALESCE(h.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  i on COALESCE(a.evidenceDeficientTaggedElements,'x')=COALESCE(i.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  j on COALESCE(a.evidenceSatisfactoryTaggedElements,'x')=COALESCE(j.cfk_tagged_element_id,'x') \
	left join STND_TAGGED_ELEMENT  k on COALESCE(a.evidenceExcellentTaggedElements,'x')=COALESCE(k.cfk_tagged_element_id,'x') ")
    dfFinal.createOrReplaceTempView("PivotTable")

    PivotTabledf=hive.sql("""select qualityreviewid ,concat(concat_ws(',',collect_set(trim(soundTaggedElements))) )   AS soundTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(unsoundTaggedElements))))   AS unsoundTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(missedTaggedElements))))   AS missedTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(newTaggedElements)) ))   AS newTaggedElements  \
	  ,concat(concat_ws(',',collect_set(trim(writingExcellentTaggedElements))) )   AS writingExcellentTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(writingSatisfactoryTaggedElements))) )   AS writingSatisfactoryTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(writingDeficientTaggedElements))) )   AS writingDeficientTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(evidenceDeficientTaggedElements))) )  AS evidenceDeficientTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(evidenceSatisfactoryTaggedElements))) )   AS evidenceSatisfactoryTaggedElements  \
	 ,concat(concat_ws(',',collect_set(trim(evidenceExcellentTaggedElements))))   AS evidenceExcellentTaggedElements  \
	from PivotTable group by  qualityreviewid """)
    PivotTabledf.createOrReplaceTempView("PivotTableFinal")

    global QUALITY_METRIC_INDICATORList
    global REFUSAL_REQUIREMENTList
    global SUBSTANTIVEList
    global PROCEDURALList
    QUALITY_METRIC_INDICATORList = TaggedElementdf.select("cfk_tagged_element_id").filter("QUALITY_METRIC_INDICATOR == 'YES'").rdd.flatMap(lambda x: x).collect()
    REFUSAL_REQUIREMENTList=TaggedElementdf.select("cfk_tagged_element_id").filter("REFUSAL_REQUIREMENTS == 'YES'").rdd.flatMap(lambda x: x).collect()
    SUBSTANTIVEList=TaggedElementdf.select("cfk_tagged_element_id").filter("SUBSTANTIVE == 'YES'").rdd.flatMap(lambda x: x).collect()
    PROCEDURALList=TaggedElementdf.select("cfk_tagged_element_id").filter("PROCEDURAL == 'YES'").rdd.flatMap(lambda x: x).collect()

    hive.sql("drop table if exists  tqr.formed_json_review ")
    hive.sql("create table tqr.formed_json_review as Select * from tqr.tqr_detail_metrics_new")
    formed_json_reviewdf=hive.sql("Select * from tqr.formed_json_review ")
     
    print QUALITY_METRIC_INDICATORList

    def customFunction(row):
		qualityMetricDeficientIndicator='false'
		refusalsUnsoundIndicator='false'
		substantiveDeficientIndicator='false'
		proceduralDeficientIndicator='false'
		overallExcellentIndicator = 'false'
		#print row['qualityreviewid']
		for p in QUALITY_METRIC_INDICATORList:
			if (str(p) in row['missedTaggedElements'].split()):
				qualityMetricDeficientIndicator='true'
		for p in QUALITY_METRIC_INDICATORList:
			if (str(p) in row['unsoundTaggedElements'].split()):
				qualityMetricDeficientIndicator='true'
		#refusalsUnsoundIndicator
		for p in REFUSAL_REQUIREMENTList:
			if (str(p) in row['unsoundTaggedElements'].split()):
				refusalsUnsoundIndicator='true'
		#substantiveDeficientIndicator
		for p in SUBSTANTIVEList:
			if (str(p) in row['missedTaggedElements'].split()):
				substantiveDeficientIndicator='true'
		for p in SUBSTANTIVEList:
			if (str(p) in row['unsoundTaggedElements'].split()):
				substantiveDeficientIndicator='true'  
		#substantiveDeficientIndicator        
		for p in PROCEDURALList:
			if (str(p) in row['missedTaggedElements'].split()):
				proceduralDeficientIndicator='true'
		for p in PROCEDURALList:
			if (str(p) in row['unsoundTaggedElements'].split()):
				proceduralDeficientIndicator='true'
        	if (str(qualityMetricDeficientIndicator).strip().lower() == 'false' and len(str(row['writingDeficientTaggedElements']).strip()) ==0 and len(str(row['evidenceDeficientTaggedElements']).strip())  ==0 and (str(row['evidenceExcellentIndicator']).strip().lower() == 'true' or str(row['writingExcellentIndicator']).strip().lower() == 'true' ) and str(row['overallDeficientIndicator']).strip().lower() =='false' and str(row['searchSufficientIndicator']).strip().lower()=='true'  ) :
    	       		overallExcellentIndicator = 'true'	  
			#return (row,refusalsUnsoundIndicator,substantiveDeficientIndicator,proceduralDeficientIndicator)
		return (row['eventInventoryId'],row['qualityReviewId'],row['reviewTypeCode'],row['serialNumber'],row['sourceEventDate'],row['examinerEmployeeNumber'], 
	row['organizationCode'],row['searchPresentIndicator'],row['reviewerEmployeeNumber'],row['reviewStatusTs'],
	row['assignedTs'],row['completedTs'],row['financialYear'],row['financialQuarter'] ,row['soundTaggedElements'],row['unsoundTaggedElements'],row['missedTaggedElements'],row['newTaggedElements'],row['writingExcellentTaggedElements']
				,row['writingSatisfactoryTaggedElements'],row['writingDeficientTaggedElements'],row['evidenceDeficientTaggedElements'],row['evidenceSatisfactoryTaggedElements'],row['evidenceExcellentTaggedElements'],row['searchSufficientIndicator'],row['missedIssuesIndicator'],row['newIssuesIndicator'],row['overallDeficientIndicator'],row['evidenceDeficientIndicator'],
					row['evidenceSatisfactoryIndicator'],row['evidenceExcellentIndicator'],row['writingDeficientIndicator'],row['writingSatisfactoryIndicator'],
					row['writingExcellentIndicator'],row['create_ts'],row['create_job_id'],row['last_mod_ts'],row['last_mod_user_id'],qualityMetricDeficientIndicator,refusalsUnsoundIndicator,substantiveDeficientIndicator,proceduralDeficientIndicator,overallExcellentIndicator )
					
    formed_json_reviewdfMi = formed_json_reviewdf.rdd.map(lambda y: y.asDict()).map(customFunction)
    #formed_json_reviewdfMi.toDF().show(2)
    preFinaldf=formed_json_reviewdfMi.toDF(sampleRatio=100).selectExpr("_1 as eventInventoryId" , "_2 as qualityReviewId ", "_3 as reviewTypeCode","_4 as serialNumber","_5 as sourceEventDate","_6 as examinerEmployeeNumber", "_7 as organizationCode","_8 as searchPresentIndicator","_9 as reviewerEmployeeNumber","_10 as reviewStatusTs","_11 as assignedTs","_12 as completedTs","_13 as financialYear","_14 as financialQuarter" ,"_15 as soundTaggedElements","_16 as unsoundTaggedElements","_17 as missedTaggedElements","_18 as newTaggedElements","_19 as writingExcellentTaggedElements"            ,"_20 as writingSatisfactoryTaggedElements","_21 as writingDeficientTaggedElements","_22 as evidenceDeficientTaggedElements","_23 as evidenceSatisfactoryTaggedElements","_24 as evidenceExcellentTaggedElements","_25 as searchSufficientIndicator","_26 as missedIssuesIndicator","_27 as newIssuesIndicator","_28 as overallDeficientIndicator","_29 as evidenceDeficientIndicator","_30 as evidenceSatisfactoryIndicator","_31 as evidenceExcellentIndicator","_32 as writingDeficientIndicator","_33 as writingSatisfactoryIndicator","_34 as writingExcellentIndicator","_35 as create_ts","_36 as create_job_id","_37 as last_mod_ts","_38 as last_mod_user_id","_39 as qualityMetricDeficientIndicator","_40 as refusalsUnsoundIndicator","_41 as substantiveDeficientIndicator","_42 as proceduralDeficientIndicator","_43 as overallExcellentIndicator")
    preFinaldf.createOrReplaceTempView("preFinalTable")
    preFinaldf.show(2,False)
    '''
    cntl_cnt_df= hive.sql("select count(1) from tqr.tqr_detail_metrics ")
    detail_metrics_cnt=cntl_cnt_df.collect()[0][0]
    print('detail_metrics_cnt' + str(detail_metrics_cnt))
    if (detail_metrics_cnt > 0 ):
	tqr_detail_metricsdfold = hive.sql("Select * from tqr.tqr_detail_metrics")
	tqr_detail_metricsdfold.createOrReplaceTempView("tqr_detail_metrics_v")
   	print(str(tqr_detail_metricsdfold.count()) +' tqr_detail_metricsdfold count ')
    hive.sql("drop table if exists tqr.tqr_detail_metrics")
    '''
    Finaldf=hive.sql("Select a.eventInventoryId as eventInventoryIdentifier,a.qualityReviewId as qualityReviewIdentifier ,a.reviewTypeCode as reviewTypeCode,a.serialNumber as  trademarkSerialNumber ,a.sourceEventDate as eventDateTime,a.examinerEmployeeNumber as examinerEmployeeNumber ,a.organizationCode as organizationCode, \
	a.searchPresentIndicator as searchCompleteIndicator ,a.reviewerEmployeeNumber reviewerEmployeeNumber ,a.reviewStatusTs lastReviewDateTime ,a.assignedTs assignDateTime ,a.completedTs as completeDateTime ,a.financialYear as financialYear,a.financialQuarter as financialQuarterNumber,b.missedTaggedElements missedTagElementNameBag, \
	b.newTaggedElements newTagElementNameBag,b.unsoundTaggedElements unsoundTagElementNameBag,b.soundTaggedElements soundTagElementNameBag,b.evidenceDeficientTaggedElements evidenceDeficientTagElementNameBag,b.evidenceSatisfactoryTaggedElements evidenceSatisfactoryTagElementNameBag, \
	b.evidenceExcellentTaggedElements evidenceExcellentTagElementNameBag, b.writingDeficientTaggedElements writingDeficientTagElementNameBag,b.writingSatisfactoryTaggedElements writingSatisfactoryTagElementNameBag,b.writingExcellentTaggedElements writingExcellentTagElementNameBag,a.searchSufficientIndicator searchSufficientIndicator, \
	a.qualityMetricDeficientIndicator qualityMetricDeficientIndicator,  a.missedIssuesIndicator missIssueIndicator,a.newIssuesIndicator newIssueIndicator, a.refusalsUnsoundIndicator refusalUnsoundIndicator,a.substantiveDeficientIndicator substantiveDeficientIndicator, \
	a.proceduralDeficientIndicator proceduralDeficientIndicator, a.overallDeficientIndicator overallDeficientIndicator, a.overallExcellentIndicator overallExcellentIndicator, a.evidenceDeficientIndicator evidenceDeficientIndicator , a.evidenceSatisfactoryIndicator evidenceSatisfactoryIndicator,a.evidenceExcellentIndicator evidenceExcellentIndicator, \
	a.writingDeficientIndicator writingDeficientIndicator,a.writingSatisfactoryIndicator writingSatisfactoryIndicator,  a.writingExcellentIndicator writingExcellentIndicator, case when a.missedIssuesIndicator == 'true' then 'true'  when a.newIssuesIndicator == 'true' then 'true'  when Length(b.unsoundTaggedElements) > 1 then 'true'  when a.evidenceExcellentIndicator == 'true' then 'true'  when a.writingExcellentIndicator == 'true' then 'true'  when a.evidenceDeficientIndicator == 'true' then 'true'  when a.writingDeficientIndicator == 'true' then 'true'  when a.searchSufficientIndicator == 'false' then 'true' else 'false' end as findingIndicator from  preFinalTable a inner join PivotTableFinal   \
	b on a.qualityReviewId = b.qualityReviewId ")
    Finaldf.createOrReplaceTempView("DesTable")
    Finaldf.show(6,False)
    
    hive.sql("Insert into tqr.tqr_detail_metrics select * ,current_timestamp as createDateTime,'etl' as createUserIdentifier,current_timestamp as lastModifiedDateTime ,'etl' as lastModifiedUserIdentifier from DesTable " ) 

    insmysqldf = hive.sql("select eventInventoryIdentifier as evntid,case when findingIndicator='true' then 1 else 0 end as findind from DesTable") 

    sql=""" UPDATE """+mysqltablename+""" quality INNER JOIN temp_table_review  temp ON temp.evntid = quality.fk_event_inventory_id SET quality.finding_in = temp.findind,
    quality.last_mod_ts = now(),quality.last_mod_user_id = 'etl'; """
    mysqlurl = config.get('tqr','mysqlurl')
    userId = config.get('tqr','mysqluserId')
    passwordVal = config.get('tqr','mysqlpasswordVal')
    import mysql.connector                              
    cnx = mysql.connector.connect(user=userId, password=passwordVal,
                              host=my_sqlhost,port=my_sqlport,
                              database=my_sqldatabase)
    cursor = cnx.cursor()
    #cursor.execute("drop table temp_table ")
    #cursor.execute("commit")
    print ('update_qualityreview count'+ str(insmysqldf.count()))
    insmysqldf.write.format('jdbc').options(url=mysqlurl,driver='com.mysql.jdbc.Driver',dbtable='temp_table_review',user=userId,
    	password=passwordVal).mode('overwrite').save()
    
    cursor.execute(sql)
    cursor.execute("commit")
    #cursor.execute("drop table temp_table_review")
    cnx.close()
    
    hive.sql("drop table if exists  tqr.formed_json_review ")
    hive.sql("drop table if exists  tqr.tqr_detail_metrics_new ")

    '''
    if (detail_metrics_cnt > 0 ):
	print("inserting data into detail metrics table ")
	hive.sql("insert into tqr.tqr_detail_metrics   select * from tqr_detail_metrics_v ")
    '''

print str(datetime.now())


mysqlurl = config.get('tqr','mysqlurl')
mysqluserId = config.get('tqr','mysqluserId')
mysqlpasswordVal = config.get('tqr','mysqlpasswordVal')


qlty_reviewdf=hive.read.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable='v_quality_review',
      user=mysqluserId,
      password=mysqlpasswordVal).load()
qlty_reviewdf.createOrReplaceTempView("qlty_review")


cntl_dt_df= hive.sql("select max(load_ts) from tqr.job_control where job_nm = 'tqr_report'")
review_evnt_dt=cntl_dt_df.collect()[0][0]

query="Select trim(cast(review_form_json_doc as string)) ,event_inventory_id eventInventoryId, \
quality_review_id qualityReviewId, \
fk_review_type_id reviewTypeCode, \
serial_no serialNumber, \
source_event_dt sourceEventDate, \
examiner_employee_no examinerEmployeeNumber, \
organization_cd organizationCode, \
search_present_in searchPresentIndicator, \
reviewer_employee_no reviewerEmployeeNumber, \
latest_review_status_ts reviewStatusTs, \
assigned_dt assignedTs, \
completed_dt completedTs , COALESCE(fk_review_year_qt,YEAR(source_event_dt)) financialYear , QUARTER(source_event_dt) as financialQuarter  from  qlty_review  where review_form_json_doc is not null and latest_overall_review_status_cd in ('FINALIZED','C_FINALIZED') "  
review_ins_query = query
 

if str(review_evnt_dt) =='None':
    review_ins_query = query
else:
    review_ins_query = query + " And  latest_review_status_ts  >   '"+str(review_evnt_dt)+"'" 

print('review_ins_query ' + review_ins_query )
appids_temp = hive.sql(review_ins_query)
#appids_temp.show(10,False)
if(appids_temp.count() > 0 ):
     getData(appids_temp)


print "Number of serial_no processed successfully: " + str(appids_temp.count())   
print str(datetime.now())
