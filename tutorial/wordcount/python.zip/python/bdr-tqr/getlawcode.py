from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
import json
import requests
from io import BytesIO
from datetime import datetime
import sys,os
import traceback
import ConfigParser
import urllib, json

config_path=sys.argv[1]
date = sys.argv[2]
date_new = date.replace("$"," ")
config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')
dataload_dt=config.get('tqr','dataload_dt')
conf = SparkConf().setAppName('tqr-search present')
conf = conf.setMaster("yarn-client")
sc = SparkContext(conf=conf)

hive =  HiveContext(sc)

hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")
hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","20")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')



def getLawcode(examiner_employee_no): 
    try:  
        import urllib2
        import ssl

        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
 	lawcode_host = config.get('tqr','LAWCODE_HOST') 
        url = "/".join((lawcode_host, examiner_employee_no ))
        
        response = urllib2.urlopen(url, context=ctx)
        data =  json.loads(response.read())
        lawcode = str(data['primaryOrganization']['shortName'])
        return lawcode[-3:]
    except Exception as ex:
        print  traceback.format_exc()
        return "404"

    
savemetadata = udf(getLawcode)

def getData(appids):
    appids = appids.repartition(10)
    appids = appids.withColumn("organization_cd",savemetadata(appids[0]))

    appids.createOrReplaceTempView("event_lawcode")
   
    appids.count()
  
    hive.sql("insert into table tqr.employee_organization select examiner_employee_no, organization_cd, case when organization_cd = 404 then 'error' else 'completed' end as status_ct,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts ,'etl' as last_mod_user_id   FROM event_lawcode")
    
print str(datetime.now())

#hive.sql("truncate table tqr.trm_stg_law_office ")

appids = hive.sql("select distinct a.examiner_employee_no from tqr.src_trm_application a where a.filing_dt > "+dataload_dt+" and not exists (select distinct b.employee_no from  tqr.employee_organization b where a.examiner_employee_no = b.employee_no and b.status_ct='completed' )   ")

appids.createOrReplaceTempView("lawcode_tobe_processed")
recscount=appids.count()
print "Number of lawcodes going to be processed : " + str(recscount)  

appids_temp = hive.sql("select examiner_employee_no from lawcode_tobe_processed  ")
getData(appids_temp)
hive.sql("insert into tqr.job_log select  'tqr-getlawcode',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(appids_temp.count())+",'organization code count'")
print "Number of lawcodes  processed successfully: " + str(appids_temp.count())   
print str(datetime.now())
