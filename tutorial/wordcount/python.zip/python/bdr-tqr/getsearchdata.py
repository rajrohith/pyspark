from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
import json
import requests
from io import BytesIO
from datetime import datetime
import sys,os
import traceback
import ConfigParser
import urllib, json

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')
dataload_dt=config.get('tqr','dataload_dt')
rec_to_process=config.get('tqr','rec_to_process')

conf = SparkConf().setAppName('tqr-search present')
conf = conf.setMaster("yarn-client")
sc = SparkContext(conf=conf)
date = sys.argv[2]
date_new = date.replace("$"," ")
hive =  HiveContext(sc)

hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")
hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","20")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')



def getMetadata(serial_no): 
    try:  
        search_host = config.get('tqr','SEARCH_HOST') 
        url = "/".join((search_host, serial_no))
        response = urllib.urlopen(url)
        data = json.dumps(json.loads(response.read()))
        if data.find("XSRCH") == -1:
            return "0"
        else:
            return "1" 
    except Exception as ex:
        print traceback.format_exc()
        return "0"

    
savemetadata = udf(getMetadata)

def getData(appids):
    appids = appids.repartition(10)
    appids = appids.withColumn("search_present_in",savemetadata(appids[0]))

    appids.createOrReplaceTempView("event_search")
   
    appids.count()
  
    hive.sql("insert into table tqr.application_search_present select a.serial_num_tx,a.search_present_in, case when a.search_present_in = 0 then 'error' else 'completed' end as status_ct,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts ,'etl' as last_mod_user_id  FROM event_search a where not exists (select distinct b.serial_num_tx from  tqr.application_search_present  b where a.serial_num_tx = b.serial_num_tx and b.search_present_in=0 ) ")
    
print str(datetime.now())

#hive.sql("truncate table tqr.event_search_present")
query="""
select  app.serial_num_tx from tqr.src_trm_application app join tqr.src_fast_application_event fifn on app.serial_num_tx=fifn.serial_num_tx
  Where fifn.completed_ts >="""+dataload_dt+"""  

UNION

select  cast(event.serial_num_tx as string) from tqr.src_trm_application app join  tqr.src_trm_application_event  event on app.serial_num_tx=event.serial_num_tx
    Where event.effective_ts  >="""+dataload_dt

search_df=hive.sql(query) 
search_df.createOrReplaceTempView("search_data")


print 'rec_to_process', rec_to_process


if(rec_to_process=='None'):
	appids = hive.sql("select distinct a.serial_num_tx from search_data a where not exists (select distinct b.serial_num_tx from  tqr.application_search_present  b where a.serial_num_tx = b.serial_num_tx and b.search_present_in=1 )   ")
	recscount=appids.count()
else:
	appids = hive.sql("select distinct a.serial_num_tx from search_data a where not exists (select distinct b.serial_num_tx from  tqr.application_search_present  b where a.serial_num_tx = b.serial_num_tx and b.search_present_in=1 )  limit "+rec_to_process+" ")
	recscount=int(rec_to_process)
appids.createOrReplaceTempView("serial_tobe_processed")

print "Number of serial no going to be processed : " + str(recscount)  
datasettoprocess=0
while (datasettoprocess <= ((recscount/5000)) ):
   appids_temp = hive.sql("select cast(serial_num_tx as string) from serial_tobe_processed  a where not exists (select distinct b.serial_num_tx from  tqr.application_search_present  b where a.serial_num_tx = b.serial_num_tx and b.search_present_in=1 ) limit 5000 ")
   getData(appids_temp)
   datasettoprocess = datasettoprocess + 1
   print("processing data set  " + str(datasettoprocess))

hive.sql("insert into tqr.job_log select  'tqr-getsearchdata',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(recscount)+",'search data count'")

print "Number of serial_no processed successfully: " + str(recscount)   
print str(datetime.now())

