#!/bin/bash

########################################################################################

# This script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# export HADOOP_USER_NAME=hdfs
# ./extract_public_applications_from_palm.sh bdr-itwp-hdfs-4.dev.uspto.gov 
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values

#########################################################################################

PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-tqr'
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs/bdr-tqr'
RUNDATE=$(date +'%Y%m%d')
export HADOOP_USER_NAME=hdfs
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')

exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "Starting $JOB:" $(date +'%Y-%m-%d:%H:%M')
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=12g  --jars $EXTRAJARPATH/ojdbc6.jar  $CODEPATH/event_filingbasis.py $CODEPATH   

if [ $? -ne 0 ]; then
  echo "Spark-submit Python script failed"
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
