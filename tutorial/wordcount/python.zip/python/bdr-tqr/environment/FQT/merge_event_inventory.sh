#!/bin/bash

JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-tqr'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-tqr'
export HADOOP_USER_NAME=hdfs
echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')

exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1

hive -f $CODEPATH/merge_event_inventory.sql
 
if [ $? -ne 0 ]; then
  echo "merge_event_inventory script failed"
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
