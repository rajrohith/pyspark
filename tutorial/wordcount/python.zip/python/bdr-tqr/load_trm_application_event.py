from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

url = config.get('tqr','trmurl')
userId = config.get('tqr','userId')
passwordVal = config.get('tqr','passwordVal')
TimeOut = config.get('tqr','TimeOut')
dbschema=config.get('tqr','trmdbschema')
soulist=config.get('tqr','soulist')
dataload_dt = config.get('tqr','dataload_dt')

#url ="jdbc:oracle:thin:@fqt-tmng-db-1.fqt.uspto.gov:1612/TRMNGFQT12"

souquery = """  select TM.TRADEMARK_GID as cfk_trademark_gid, 
       BE.BUSINESS_EVENT_ID, 
       TM.SERIAL_NUM_TX, 
       st.BUSINESS_EVENT_REASON_ID as ckf_business_event_reason_id, 
       st.business_event_Reason_cd as business_event_reason_cd, 
       BE.EFFECTIVE_TS
from """+dbschema+""".TRADEMARK tm, 
     """+dbschema+""".BUSINESS_EVENT_OBJECT beo, 
     """+dbschema+""".BUSINESS_EVENT be, 
    """+dbschema+""". STND_BUSINESS_EVENT_REASON st
where TM.TRADEMARK_GID = BEO.CFK_OBJECT_GID 
and BE.BUSINESS_EVENT_ID = BEO.FK_BUSINESS_EVENT_ID
and be.FK_BUSINESS_EVENT_REASON_ID = st.BUSINESS_EVENT_REASON_ID"""
#and st.business_Event_reason_cd IN ("""+soulist+""")  """
spark = SparkSession \
    .builder \
    .appName("trm event load") \
    .enableHiveSupport()\
    .getOrCreate()

cntl_dt_df= spark.sql("select max(load_ts) from tqr.job_control where job_nm = 'trm_application_event'")
sou_evnt_dt=cntl_dt_df.collect()[0][0]

sou_ins_query="select  distinct a.*,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from sou_event a"
sou_ins_queryCnt="select count(1) from sou_event "

sou_evnt_dt = str(sou_evnt_dt)
'''
if str(sou_evnt_dt) =='None':
    sou_ins_query = sou_ins_query 
else:
    sou_ins_query += " where create_ts   > '"+sou_evnt_dt+"'  "
    sou_ins_queryCnt += " where create_ts  > '"+sou_evnt_dt+"'  "
'''
if str(sou_evnt_dt) =='None':
    souquery += " And  BE.create_ts  > to_timestamp("+dataload_dt+", 'YYYY-MM-DD HH24:MI:SS') "   

else:
    if str(sou_evnt_dt).find('.')==-1:
	sou_evnt_dt = str(sou_evnt_dt)
    else:
        sou_evnt_dt = sou_evnt_dt[:str(sou_evnt_dt).find('.')]
        souquery += " And  BE.create_ts > to_timestamp('"+str(sou_evnt_dt)+"', 'YYYY-MM-DD HH24:MI:SS')    "

print(souquery + " trm_event_ins_query ")


appDF = spark.read \
    .jdbc(url, "("+souquery+")", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
appDF.createOrReplaceTempView("sou_event")


spark.sql("INSERT INTO tqr.src_trm_application_event  " + sou_ins_query)

spark.sql(" insert into tqr.job_control select * from (select 'trm_application_event' as job_name ,current_timestamp as loaded_dt,current_timestamp,'etl',current_timestamp,'etl'  ) tab ")

spark.sql("insert into tqr.job_log select  'tqr-trm_application_event',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(appDF.count())+",'trm application event count'")

spark.stop()

