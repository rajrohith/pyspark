# -*- coding: utf-8 -*-
"""
Created on Mon Aug 27 12:48:22 2018

@author: rshanmugam
"""

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
from pyspark.sql.functions import udf, lit, unix_timestamp, from_unixtime
from pyspark.sql.functions import col
from datetime import date,datetime
import json, traceback, datetime, hashlib, sys
from functools import partial
import json, re
from pyspark.sql import functions as F
from pyspark.sql.functions import lit
import os

import datetime
import json
import hashlib
import traceback
spark = SparkSession \
    .builder \
    .appName("quality_review ") \
    .enableHiveSupport()\
    .getOrCreate()

hive = HiveContext(spark)


import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

mysqlurl = config.get('tqr','mysqlurl')
mysqluserId = config.get('tqr','mysqluserId')
mysqlpasswordVal = config.get('tqr','mysqlpasswordVal')

ES_nodes = config.get('tqr','ES_nodes')
ES_index = config.get('tqr','ES_index')
ES_type = config.get('tqr','ES_type')
ES_user = config.get('tqr','ES_user')
ES_pass = config.get('tqr','ES_pass')
json_path = config.get('tqr','JSON_PATH')
#ES_port = config.get('tqr','ES_port')
dataload_dt = config.get('tqr','dataload_dt')

def get_id(row):
    import hashlib

    keys = str(row)
    _id = hashlib.sha224(keys).hexdigest()

    return (_id)


def gettag(data):
	try:
		a=json.dumps(data)
		b=json.loads(a)
		parsejson=str(b).replace('"19":','"Fees":').replace('"18":','"Failure to Function - other - non specimen based":').replace('"17":','"Entity/Citizenships":').replace('"16":','"Drawing":').replace('"15":','"Decl./Verification ":').replace('"14":','"2e(5)":').replace('"13":','"2(e)(3)":').replace('"12":','"2(c)":').replace('"11":','"2(b)":').replace('"10":','"2(a)":').replace('"9":','"Substantive Specimen Issue":').replace('"8":','"Administrative  Specimen Issue":').replace('"7":','"Identifications":').replace('"6":','"Disclaimers":').replace('"5":','"2(e)(4)":').replace('"4":','"2(e)(2)":').replace('"3":','"2(e)(1)":').replace('"2":','"2(d)(pending)":').replace('"1":','"2(d)":').replace('"32":','"Other - Collective Marks":').replace('"46":','"Other - Partial refusal/requirement":').replace('"31":','"Other - Classification":').replace('"52":','"Other - Transliteration":').replace('"25":','"Other - Abandonment - other":').replace('"20":','"Filing Basis Issue(s) ":').replace('"21":','"Generic/2(f)Supp":').replace('"23":','"Not Inherently Distinct":').replace('"25":','"Other - Abandonment - other":').replace('"29":','"Other - Certification Marks":').replace('"45":','"Other - Multiple Class":')
		return parsejson
	except Exception as ex:
		return "data error"



savedata=udf(gettag)
saveid=udf(get_id)

def getdata(loadDF):
	loadDF = loadDF.withColumn('tagElementNumber',savedata(loadDF[0]).cast("string"))
	loadDF = loadDF.withColumn('eventDateTime', from_unixtime(timestamp=unix_timestamp(timestamp='eventDateTime' )))
	loadDF = loadDF.withColumn('assignDateTime', from_unixtime(timestamp=unix_timestamp(timestamp='assignDateTime' )))
	loadDF = loadDF.withColumn('completeDateTime', from_unixtime(timestamp=unix_timestamp(timestamp='completeDateTime' )))
	loadDF = loadDF.withColumn('lastReviewDateTime', from_unixtime(timestamp=unix_timestamp(timestamp='lastReviewDateTime')))
	loadDF = loadDF.withColumn('substantiveDeficientIndicator', (col("substantiveDeficientIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('refusalUnsoundIndicator', (col("refusalUnsoundIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('qualityMetricDeficientIndicator', (col("qualityMetricDeficientIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('proceduralDeficientIndicator', (col("proceduralDeficientIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('overallExcellentIndicator', (col("overallExcellentIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('evidenceDeficientIndicator', (col("evidenceDeficientIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('evidenceExcellentIndicator', (col("evidenceExcellentIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('writingDeficientIndicator', (col("writingDeficientIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('writingExcellentIndicator', (col("writingExcellentIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('findingIndicator', (col("findingIndicator").cast("boolean")))
	loadDF = loadDF.withColumn('id',saveid(loadDF[1]))
	os.system("hdfs dfs -rm -r "+ json_path)
	loadDF.select('tagElementNumber').coalesce(1).write.format("text").save(json_path)
	parsejson=spark.read.json(json_path)
	schema=parsejson.schema.json()
	schema=StructType.fromJson(json.loads(schema))

	loadDF=loadDF.select(col("id").alias("id"),col("eventInventoryIdentifier").alias("eventInventoryIdentifier"), col("qualityReviewIdentifier").alias("qualityReviewIdentifier"), col("reviewTypeCode").alias("reviewTypeCode") ,col("trademarkSerialNumber").alias("trademarkSerialNumber"), col("eventDateTime").alias("eventDateTime"), col("examinerEmployeeNumber").alias("examinerEmployeeNumber")  
	,col("organizationCode").alias("organizationCode"), col("searchCompleteIndicator").alias("searchCompleteIndicator"), col("reviewerEmployeeNumber").alias("reviewerEmployeeNumber")  
	,col("lastReviewDateTime").alias("lastReviewDateTime"), col("assignDateTime").alias("assignDateTime"), col("completeDateTime").alias("completeDateTime")  
	,col("financialYear").alias("financialYear"), col("missedTagElementNameBag").alias("missedTagElementNameBag")  
	,col("newTagElementNameBag").alias("newTagElementNameBag"), col("unsoundTagElementNameBag").alias("unsoundTagElementNameBag"), col("soundTagElementNameBag").alias("soundTagElementNameBag")  
	,col("evidenceDeficientTagElementNameBag").alias("evidenceDeficientTagElementNameBag"), col("evidenceSatisfactoryTagElementNameBag").alias("evidenceSatisfactoryTagElementNameBag"), col("evidenceExcellentTagElementNameBag").alias("evidenceExcellentTagElementNameBag")  
	,col("writingDeficientTagElementNameBag").alias("writingDeficientTagElementNameBag"), col("writingSatisfactoryTagElementNameBag").alias("writingSatisfactoryTagElementNameBag"), col("writingExcellentTagElementNameBag").alias("writingExcellentTagElementNameBag")  
	,col("searchSufficientIndicator").alias("searchSufficientIndicator"), col("qualityMetricDeficientIndicator").alias("qualityMetricDeficientIndicator"), col("missIssueIndicator").alias("missIssueIndicator")  
	,col("newIssueIndicator").alias("newIssueIndicator"), col("refusalUnsoundIndicator").alias("refusalUnsoundIndicator"), col("substantiveDeficientIndicator").alias("substantiveDeficientIndicator")  
	,col("proceduralDeficientIndicator").alias("proceduralDeficientIndicator"), col("overallDeficientIndicator").alias("overallDeficientIndicator"),col("overallExcellentIndicator").alias("overallExcellentIndicator"), col("evidenceDeficientIndicator").alias("evidenceDeficientIndicator")  
	,col("evidenceSatisfactoryIndicator").alias("evidenceSatisfactoryIndicator"), col("evidenceExcellentIndicator").alias("evidenceExcellentIndicator"), col("writingDeficientIndicator").alias("writingDeficientIndicator"),col("writingExcellentIndicator").alias("writingExcellentIndicator"),col("writingSatisfactoryIndicator").alias("writingSatisfactoryIndicator"),col("findingIndicator").alias("findingIndicator"),F.from_json(col("tagElementNumber"),schema).alias("reviewFormJsonDoc"))
	
	loadDF.show(2)
	loadDF.dropDuplicates()

	
	try:
		loadDF.write.format("org.elasticsearch.spark.sql").option("es.nodes.wan.only","true").option("es.port","9200").option("es.net.ssl","true").option("es.nodes",ES_nodes).option("es.mapping.id","id").option("es.batch.write.retry.count","20").option("es.batch.write.retry.wait","100").option("es.batch.size.entries","5000").option("es.batch.size.bytes","10mb").option("es.net.http.auth.user", ES_user).option("es.write.operation","index").option("es.net.http.auth.pass",ES_pass).save(ES_index+'/'+ES_type, mode="append")
		print 'Exported to Elastic Search'
	except Exception as ex:
		print traceback.format_exc()	
	

cntl_dt_df= hive.sql("select max(load_ts) from tqr.job_control where job_nm = 'tqr_report'")
review_evnt_dt=cntl_dt_df.collect()[0][0]
 
review_ins_query="select  b.review_form_json_doc as form_json_doc,a.* from tqr.tqr_detail_metrics a join temp b on a.qualityreviewidentifier= b.quality_review_id  "
review_ins_queryCnt="select  count(1) from tqr.tqr_detail_metrics  "

if str(review_evnt_dt) =='None':
    review_ins_query = review_ins_query
    review_ins_queryCnt = review_ins_queryCnt 
else:
    review_ins_query += " Where lastModifiedDateTime >   '"+str(review_evnt_dt)+"'" 
    review_ins_queryCnt += " Where lastModifiedDateTime >   '"+str(review_evnt_dt)+"'" 

count_df= hive.sql(review_ins_queryCnt)
exportCnt=count_df.collect()[0][0]
qlty_reviewdf=spark.read.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable='quality_review',
      user='bdr_admin',
      password=mysqlpasswordVal).load()
qlty_reviewdf.createOrReplaceTempView("temp")

spark.sql("USE TQR")
loadDF=spark.sql(review_ins_query)
#loadDF.printSchema()

#print loadDF.count(),"count of data"
loadDF.createOrReplaceTempView("quality_review_view")
loadDF=loadDF.dropDuplicates()
print ' this is the input records'
loadDF.show(2)
getdata(loadDF)

hive.sql("insert into tqr.job_log select  'tqr_detail_metrics',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(exportCnt)+",'no of records exported to elastic for tqr detail metrics'")
hive.sql(" insert into tqr.job_control select * from (select 'tqr_report' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl') tab ")

spark.stop()
