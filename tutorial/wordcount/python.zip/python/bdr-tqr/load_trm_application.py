from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

url = config.get('tqr','trmurl')
userId = config.get('tqr','userId')
passwordVal = config.get('tqr','passwordVal')
TimeOut = config.get('tqr','TimeOut')
dbschema=config.get('tqr','trmdbschema')
dataload_dt = config.get('tqr','dataload_dt')
date = sys.argv[2]
date_new = date.replace("$"," ")



trmquery = """ SELECT                              
        TM.TRADEMARK_GID cfk_trademark_gid,
	TM.SERIAL_NUM_TX serial_num_tx,
	TM.FILING_DT filing_dt ,
        substr(regexp_replace(TML.LITERAL_ELEMENT_TX, '( ){2,}',' '),1,10000)  literal_element_tx,
	substr(regexp_replace(tm.standard_character_tx, '( ){2,}',' '),1,10000) standard_character_tx,
        substr(regexp_replace(TM.MARK_DESCRIPTION_TX , '( ){2,}',' '),1,10000)  mark_description_tx,
        substr(regexp_replace(SMDT.MARK_DRAWING_TYPE_CD , '( ){2,}',' '),1,10000) mark_drawing_type_cd,
        substr(regexp_replace(SMDT.TITLE_TX  , '( ){2,}',' '),1,10000) as mark_drawing_type_title_tx,
        EM.CFK_EMPLOYEE_NO examiner_employee_no,
	FT.TITLE_TX as source_system_nm
         FROM    """+dbschema+""".TRADEMARK TM 
	   INNER JOIN """+dbschema+""".TM_EMPLOYEE_ASSIGNMENT EM ON TM.TRADEMARK_GID = EM.FK_TRADEMARK_GID
	   INNER JOIN """+dbschema+""".STND_MARK_DRAWING_TYPE SMDT ON SMDT.MARK_DRAWING_TYPE_CD = TM.FK_MARK_DRAWING_TYPE_CD
	   INNER JOIN """+dbschema+""".STND_FEE_PROCESS_TYPE FT ON TM.FK_FEE_PROCESS_TYPE_CD = FT.FEE_PROCESS_TYPE_CD
           LEFT OUTER JOIN """+dbschema+""".TM_LITERAL TML ON TML.FK_TRADEMARK_GID = TM.TRADEMARK_GID  where exists (select 1 from serial_num_data temp where temp."serial_num_tx" =TM.serial_num_tx ) and  EM.FK_TM_EMPLOYEE_ROLE_CD='EA' """
spark = SparkSession \
    .builder \
    .appName("tqr event load") \
    .enableHiveSupport()\
    .getOrCreate()


#url='jdbc:oracle:thin:@//sit-tmng-db-1.sit.uspto.gov:1610/TMNGDEV12'
fastappDF=spark.sql("select  distinct trim(fast.serial_num_tx) as serial_num_tx  from tqr.src_fast_application_event fast where not exists ( select app.serial_num_tx from  tqr.src_trm_application app where app.serial_num_tx = fast.serial_num_tx ) ")
trmappDF=spark.sql("select  distinct trim(trm.serial_num_tx) as serial_num_tx  from tqr.src_trm_application_event trm where not exists ( select app.serial_num_tx from  tqr.src_trm_application app where app.serial_num_tx = trm.serial_num_tx )  ")
#trmappDF.show(10,False)
trmappDF.select("serial_num_tx").write.format('jdbc').options(
      url=url,
      driver='oracle.jdbc.driver.OracleDriver',
      dbtable='serial_num_data',
      user=userId,
      password=passwordVal).mode('overwrite').save()
fastappDF.select("serial_num_tx").write.format('jdbc').options(
      url=url,
      driver='oracle.jdbc.driver.OracleDriver',
      dbtable='serial_num_data',
      user=userId,
      password=passwordVal).mode('append').save()


app_ins_query="select  distinct a.*,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from event a"
app_ins_queryCnt="select count(1) from event "


print(trmquery  + " trm query is ")


appDF = spark.read \
    .jdbc(url, "("+trmquery+")",  properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
appDF.createOrReplaceTempView("event")

'''
#appDF.count()
#spark.sql("DROP TABLE IF EXISTS tqr.stage_trm_application ")

fastdf=spark.sql("select serial_num_tx from tqr.src_fast_application_event")
fastdf.createOrReplaceTempView("Fast")
print ("fast count " + str(fastdf.count()) )
Trmdf=spark.sql("select serial_num_tx from tqr.src_trm_application_event ")
Trmdf.createOrReplaceTempView("Trm")
print ("trm count " + str(Trmdf.count()) )
insertFastDF=spark.sql(" Select distinct event.* from event join Fast on event.serial_num_tx = Fast.serial_num_tx where not exists ( select app.serial_num_tx from  tqr.src_trm_application app where app.serial_num_tx = Fast.serial_num_tx ) ")
insertFastDF.createOrReplaceTempView("FastData")

insertTrmDF=spark.sql(" Select distinct event.* from event join Trm on event.serial_num_tx = Trm.serial_num_tx where not exists ( select app.serial_num_tx from  tqr.src_trm_application app where app.serial_num_tx = Trm.serial_num_tx ) ")
insertTrmDF.createOrReplaceTempView("TrmData")
'''

spark.sql("INSERT INTO tqr.src_trm_application select  distinct a.*,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from event a ")
#spark.sql("INSERT INTO tqr.src_trm_application select  distinct b.*,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from TrmData b ")

spark.sql(" insert into tqr.job_control select * from (select 'trm_application' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl' ) tab ")
spark.sql("insert into tqr.job_log select   'tqr-load_trm_application',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(appDF.count())+",'tqr-load_trm_application'")
     
spark.stop()

