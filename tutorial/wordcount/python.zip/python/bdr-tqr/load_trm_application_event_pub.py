from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]
date = sys.argv[2]
date_new = date.replace("$"," ")

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

url = config.get('tqr','trmurl')
userId = config.get('tqr','userId')
passwordVal = config.get('tqr','passwordVal')
TimeOut = config.get('tqr','TimeOut')
dbschema=config.get('tqr','trmdbschema')
publist=config.get('tqr','publist')
dataload_dt = config.get('tqr','dataload_dt')
#url ="jdbc:oracle:thin:@fqt-tmng-db-1.fqt.uspto.gov:1612/TRMNGFQT12"
pubquery = """ select TM.TRADEMARK_GID, 
       BE.BUSINESS_EVENT_ID, 
       TM.SERIAL_NUM_TX, 
       st.BUSINESS_EVENT_REASON_ID, 
       st.business_event_Reason_cd, 
       BE.EFFECTIVE_TS
from """+dbschema+""".TRADEMARK tm, 
     """+dbschema+""".BUSINESS_EVENT_OBJECT beo, 
     """+dbschema+""".BUSINESS_EVENT be, 
    """+dbschema+""". STND_BUSINESS_EVENT_REASON st
where TM.TRADEMARK_GID = BEO.CFK_OBJECT_GID 
and BE.BUSINESS_EVENT_ID = BEO.FK_BUSINESS_EVENT_ID
and be.FK_BUSINESS_EVENT_REASON_ID = st.BUSINESS_EVENT_REASON_ID
and st.business_Event_reason_cd IN ("""+publist+""") """
spark = SparkSession \
    .builder \
    .appName("trm pub load") \
    .enableHiveSupport()\
    .getOrCreate()

cntl_dt_df= spark.sql("select max(loaded_dt) from tqr.job_cntl where job_name = 'trm_application_event_pub'")
pub_evnt_dt=cntl_dt_df.collect()[0][0]

pub_ins_query="select  distinct a.trademark_gid,a.business_event_id,a.serial_num_tx,a.business_event_reason_id,a.business_event_Reason_cd ,a.effective_ts, current_timestamp as create_ts,'etl' as create_job_id,current_timestamp as last_mod_ts,'etl' as last_mod_job_id from pub_event a"
pub_ins_queryCnt="select count(1) from pub_event "

pub_evnt_dt = str(pub_evnt_dt)
'''
if str(pub_evnt_dt) =='None':
    pub_ins_query = pub_ins_query 
else:
    pub_ins_query += " where MILESTONE_DT  > '"+pub_evnt_dt+"'  "
    pub_ins_queryCnt +=" where MILESTONE_DT  > '"+pub_evnt_dt+"'  "
'''
if str(pub_evnt_dt) =='None':
    pubquery += " And BE.create_ts > to_timestamp("+dataload_dt+", 'YYYY-MM-DD HH24:MI:SS') "   

else:
    if str(pub_evnt_dt).find('.')==-1:
	pub_evnt_dt = str(pub_evnt_dt)
    else:
        pub_evnt_dt = pub_evnt_dt[:str(pub_evnt_dt).find('.')]
        pubquery += " And BE.create_ts > to_timestamp('"+str(pub_evnt_dt)+"', 'YYYY-MM-DD HH24:MI:SS')    "

print(pubquery + " pubquery is ")
print(pubquery + " pub_ins_query is ")



appDF = spark.read \
    .jdbc(url, "("+pubquery+")", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
appDF.createOrReplaceTempView("pub_event")
print("Total count of pub " + str(appDF.count()))

spark.sql("INSERT INTO tqr.src_trm_application_event  " + pub_ins_query)

spark.sql(" insert into tqr.job_cntl select * from (select 'trm_application_event_pub' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl') tab ")

spark.sql("insert into tqr.job_log select  'tqr-trm_application_event_pub',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed','pub application count',"+str(appDF.count()))
     
spark.stop()

