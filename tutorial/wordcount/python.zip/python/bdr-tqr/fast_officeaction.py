from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
spark = SparkSession \
    .builder \
    .appName("Tqrs fast App") \
    .enableHiveSupport()\
    .getOrCreate()

url ="jdbc:oracle:thin:@dev-eis-scan.etc.uspto.gov:1626/TMNGFQT"
query="""select completed_dt as source_event_dt ,fk_cf_id as serial_no from  FASTUSRQ.OFFICE_ACTION 
"""

tmpDF = spark.read.jdbc(url,"("+query+")", properties={"user": "BIGDATAREAD", "password": "changeitnow_1128"})
tmpDF.createOrReplaceTempView("officeaction")
spark.sql("DROP TABLE IF EXISTS tqrs.office_action ")
spark.sql("create table tqr.office_action  as select * from officeaction")  
spark.stop()
