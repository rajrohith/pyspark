insert overwrite table tqr.event_inventory
select * from (Select a.review_type_cd,a.serial_num_tx,a.source_system_nm,a.search_present_in,
a.source_event_dt,
a.docket_in ,
a.mark_literal_element_tx,
a.mark_drawing_type_cd  ,
a.mark_drawing_type_title_tx ,
a.mark_description_tx ,
a.examiner_employee_no,
a.organization_cd,
a.event_json_doc,
a.inventory_create_ts,
a.lock_control_no ,
a.create_ts,
a.create_user_id,
a.last_mod_ts,
a.last_mod_user_id

From tqr.event_inventory_stage a
Left outer join tqr.event_inventory b on a.serial_num_tx = b.serial_num_tx and a.source_event_dt = b.source_event_dt and a.review_type_cd=b.review_type_cd
Where b.serial_num_tx is null and  b.source_event_dt is null

UNION

Select c.review_type_cd,c.serial_num_tx,c.source_system_nm,c.search_present_in,
c.source_event_dt,
c.docket_in ,
c.mark_literal_element_tx,
c.mark_drawing_type_cd  ,
c.mark_drawing_type_title_tx ,
c.mark_description_tx ,
c.examiner_employee_no,
c.organization_cd,
c.event_json_doc,
d.inventory_create_ts,
c.lock_control_no ,
d.create_ts,
d.create_user_id,
case when ( c.docket_in <>  d.docket_in OR c.mark_literal_element_tx <> d.mark_literal_element_tx OR c.mark_drawing_type_title_tx <> d.mark_drawing_type_title_tx OR c.mark_drawing_type_title_tx
 <> d.mark_drawing_type_title_tx OR c.mark_description_tx <> d.mark_description_tx OR c.examiner_employee_no <> d.examiner_employee_no OR c.organization_cd <> d.organization_cd OR c.event_json_doc <> d.event_json_doc) then c.last_mod_ts else d.last_mod_ts end last_mod_ts,
c.last_mod_user_id

From tqr.event_inventory_stage c
join tqr.event_inventory d on c.serial_num_tx = d.serial_num_tx and c.source_event_dt = d.source_event_dt and c.review_type_cd=d.review_type_cd
) Tab ;
