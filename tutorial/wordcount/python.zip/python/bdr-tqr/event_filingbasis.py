from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
spark = SparkSession \
    .builder \
    .appName("Tqrs filing App") \
    .enableHiveSupport()\
    .getOrCreate()

url ="jdbc:oracle:thin:@pvt-tmng-db-3.pvt.uspto.gov:1602:TRMNGPVT"
query="""SELECT TM.SERIAL_NUM_TX serial_no,'{"FILINGBASIS": ['|| LISTAGG('"'||TMFB.FK_FILING_BASIS_CD||'"', ',' )  WITHIN GROUP (ORDER BY TM.SERIAL_NUM_TX)||']}' AS event_json_doc
FROM TMNGPVTDB.TRADEMARK TM JOIN TMNGPVTDB.TM_FILING_BASIS TMFB ON TMFB.FK_TRADEMARK_GID = TM.TRADEMARK_GID
WHERE TMFB.FILED_IN='Y' 
GROUP BY  TM.SERIAL_NUM_TX 
"""

tmpDF = spark.read.jdbc(url,"("+query+")", properties={"user": "BIGDATAREAD", "password": "Pat3nt_Trad3mark"})
tmpDF.createOrReplaceTempView("event_filingbasis")
spark.sql("DROP TABLE IF EXISTS tqr.event_filing_basis ")
spark.sql("create table tqr.event_filing_basis  as select * from event_filingbasis")  
spark.stop()
