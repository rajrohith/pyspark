from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

url = config.get('tqr','fasturl')
userId = config.get('tqr','fastuserId')
passwordVal = config.get('tqr','fastpasswordVal')
TimeOut = config.get('tqr','TimeOut')
dbschema=config.get('tqr','fastdbschema')

spark = SparkSession \
    .builder \
    .appName("Tqrs fast tagged elements") \
    .enableHiveSupport()\
    .getOrCreate()

#url ="jdbc:oracle:thin:@dev-eis-scan.etc.uspto.gov:1626/TMNGFQT"

date = sys.argv[2]
date_new = date.replace("$"," ")
dataload_dt = config.get('tqr','dataload_dt')

tagged_dt_df= spark.sql("select  max(load_ts) from tqr.job_control where job_nm = 'fast_taggeddata'")
last_modified_dt=tagged_dt_df.collect()[0][0]

last_modified_dt = str(last_modified_dt)

taggedquery="SELECT "+dbschema+".OFFICE_ACTION.FK_CF_ID as serial_num_tx  \
 ,"+dbschema+".OFFICE_ACTION.OA_ID \
, "+dbschema+".FP_CATEGORY.FP_CATEGORY_ID \
, "+dbschema+".FP_CATEGORY.NAME as fp_category_name  \
, "+dbschema+".FORM_PARAGRAPH.LAST_MODIFIED_TIMPESTAMP \
 From "+dbschema+".OFFICE_ACTION left Join "+dbschema+".OFFICE_ACTION_FORM_PARA_ASSOC \
  On "+dbschema+".OFFICE_ACTION.OA_ID = "+dbschema+".OFFICE_ACTION_FORM_PARA_ASSOC.FK_OA_ID \
RIGHT Join "+dbschema+".FORM_PARAGRAPH \
On "+dbschema+".OFFICE_ACTION_FORM_PARA_ASSOC.FK_FP_ID = "+dbschema+".FORM_PARAGRAPH.FP_ID \
INNER JOIN "+dbschema+".FP_GROUP on "+dbschema+".FORM_PARAGRAPH.fk_fp_group_id =  "+dbschema+".FP_GROUP.fp_group_id \
INNER JOIN "+dbschema+".FP_CATEGORY \
 on "+dbschema+".FORM_PARAGRAPH.FK_FP_CATEGORY_ID = "+dbschema+".FP_CATEGORY.FP_CATEGORY_ID Where lower("+dbschema+".FP_GROUP.name) in ('refusal','requirement')  " 

tagged_ins_query="select distinct serial_num_tx,oa_id as cfk_office_action_id,fp_category_id as cfk_form_paragraph_category_id ,fp_category_name  as form_paragraph_ct ,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from tagged_data "
tagged_ins_queryCnt="select count(1) from tagged_data "

if str(last_modified_dt) =='None':
    taggedquery =  taggedquery
else:
    if str(last_modified_dt).find('.')==-1:
	last_modified_dt = str(last_modified_dt)
    else:
        last_modified_dt = last_modified_dt[:str(last_modified_dt).find('.')]
        taggedquery += " And COMPLETED_DT    > to_timestamp('"+str(last_modified_dt)+"', 'YYYY-MM-DD HH24:MI:SS') "

print(taggedquery + " This is taggedquery ")

oaDF = spark.read.jdbc(url,"("+taggedquery+")", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
oaDF.createOrReplaceTempView("tagged_data")


spark.sql("INSERT INTO tqr.src_fast_tagged_element  " + tagged_ins_query ) 
spark.sql(" insert into tqr.job_control  select * from (select 'fast_taggeddata' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl' ) tab ")

spark.sql("insert into tqr.job_log select  'tqr-fast_taggeddata',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(oaDF.count())+",'fast tagged data count'")

spark.stop()
