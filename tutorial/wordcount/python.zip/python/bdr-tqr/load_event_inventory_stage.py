from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
spark = SparkSession \
    .builder \
    .appName("event inventory load") \
    .enableHiveSupport()\
    .getOrCreate()

hive = HiveContext(spark)

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

mysqlurl = config.get('tqr','mysqlurl')
mysqluserId = config.get('tqr','mysqluserId')
mysqlpasswordVal = config.get('tqr','mysqlpasswordVal')
interveninglist=config.get('tqr','interveninglist')

firstactionlist_hive = config.get('tqr','firstactionlist_hive')
finalactionlist_hive = config.get('tqr','finalactionlist_hive')
dataload_dt = config.get('tqr','dataload_dt')
publist = config.get('tqr','publist') 
soulist = config.get('tqr','soulist')

First24hr=config.get('tqr','First24hr')
Other24hr=config.get('tqr','Other24hr')
First66hr=config.get('tqr','First66hr') 
Other24hrPlusOne=int(Other24hr)+1
First66MinusOne=int(First66hr)-1

stnd_reviewdf=spark.read.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable='stnd_review_type',
      user=mysqluserId,
      password=mysqlpasswordVal).load()
stnd_reviewdf.createOrReplaceTempView("stnd_review")
print ('soulist is ' + soulist )
print ('publist is ' + publist )
'''
cntl_dt_df= spark.sql("select max(load_ts) from tqr.job_control where job_nm = 'event_inventory_stage'")
stg_evnt_dt=cntl_dt_df.collect()[0][0]
'''

first_df= spark.sql("Select cast(review_type_id as string) review_type_id from stnd_review where review_type_cd = 'FIRSTACTION' ")
first_id=str(first_df.collect()[0][0])

final_df= spark.sql("Select cast(review_type_id as string) review_type_id from stnd_review where review_type_cd = 'FINALACTION' ")
final_id=str(final_df.collect()[0][0])

Pub_df= spark.sql("Select cast(review_type_id as string) review_type_id from stnd_review where review_type_cd = 'PUB' ")
Pub_id=str(Pub_df.collect()[0][0])

Sou_df= spark.sql("Select cast(review_type_id as string) review_type_id from stnd_review where review_type_cd = 'SOU' ")
Sou_id=str(Sou_df.collect()[0][0])

#stg_ins_query="select distinct cast(temp.review_type_cd as int) review_type_cd,temp.serial_no , temp.source_system_nm , temp.search_present_in ,temp.source_event_dt , temp.docket_in ,temp.mark_literal_element_tx as mark_literal_element_tx,temp.mark_drawing_type_cd as mark_drawing_type_cd,temp.mark_drawing_type_title_tx ,temp.mark_description_tx as mark_description_tx,temp.examiner_employee_no,temp.organization_cd,temp.event_json_doc,temp.inventory_create_ts,temp.lock_control_no,  temp.create_ts, temp.create_user_id, temp.last_mod_ts,temp.last_mod_user_id  from event_inventory_temp temp Where temp.source_system_nm is not null and not exists (select 1 from tqr.event_inventory final where final.serial_num_tx=temp.serial_no and final.review_type_cd=temp.review_type_cd and final.source_event_dt=temp.source_event_dt )  and temp.source_event_dt  >="+dataload_dt
stg_ins_query="select distinct cast(temp.review_type_cd as int) review_type_cd,temp.serial_no , temp.source_system_nm , temp.search_present_in ,temp.source_event_dt , temp.docket_in ,temp.mark_literal_element_tx as mark_literal_element_tx,temp.mark_drawing_type_cd as mark_drawing_type_cd,temp.mark_drawing_type_title_tx ,temp.mark_description_tx as mark_description_tx,temp.examiner_employee_no,temp.organization_cd,temp.event_json_doc,temp.inventory_create_ts,temp.lock_control_no,  temp.create_ts, temp.create_user_id, temp.last_mod_ts,temp.last_mod_user_id  from event_inventory_temp temp Where temp.source_system_nm is not null  and temp.source_event_dt  >="+dataload_dt

stg_disc_query="select distinct cast(review_type_cd as int) review_type_cd,serial_no , source_system_nm , search_present_in ,source_event_dt , docket_in ,mark_literal_element_tx as mark_literal_element_tx,mark_drawing_type_cd as mark_drawing_type_cd,mark_drawing_type_title_tx ,mark_description_tx as mark_description_tx,examiner_employee_no,organization_cd,event_json_doc,inventory_create_ts ,lock_control_no,  create_ts, create_user_id, last_mod_ts,last_mod_user_id  from event_inventory_discarded Where source_system_nm is not null "

stg_ins_queryCnt="select count(1) from event_inventory_temp temp Where temp.source_system_nm is not null and not exists (select 1 from tqr.event_inventory final where final.serial_num_tx=temp.serial_no and final.review_type_cd=temp.review_type_cd and final.source_event_dt=temp.source_event_dt )  and temp.source_event_dt   >="+dataload_dt

stg_disc_queryCnt="select count(1) from event_inventory_discarded Where source_system_nm is not null "

querytagged ="""select a.serial_num_tx as serial_num_tx ,a.cfk_office_action_id as oa_id, concat('"taggedElements":',concat('[',concat_ws(',',collect_set(concat('"',b.cfk_tagged_element_id ,'"'))) ,']'),'}')   AS tagged_json  from tqr.src_fast_tagged_element  a join tqr.tagged_element_mapping b on a.form_paragraph_ct = b.form_paragraph_ct group by a.serial_num_tx ,a.cfk_office_action_id
"""

queryFilingbasis = """select serial_num_tx ,concat('{"filingBasis":',concat('[',concat_ws(',',collect_set(concat('"',filing_basis_cd,'"'))) ,']'))   AS filing_basis_json  from tqr.src_trm_filing_basis where current_in ='Y' group by serial_num_tx 
"""

tagged_df=hive.sql(querytagged)
tagged_df.createOrReplaceTempView("taggedElements")

filingBasis_df=hive.sql(queryFilingbasis)
filingBasis_df.createOrReplaceTempView("filingBasis")

updateActionMadrid_df=hive.sql("Select distinct trm.serial_num_tx serial_num_tx , trm.effective_ts effective_ts from tqr.src_trm_filing_basis fb inner join tqr.src_trm_application_event trm on fb.serial_num_tx = trm.serial_num_tx where  fb.current_in ='Y' and trim(fb.filing_basis_cd)='66(a)' and upper(trim(trm.business_event_reason_cd)) = 'RFCSP' ")
updateActionMadrid_df.createOrReplaceTempView("updateActionMadrid")

tagged_fb_df=hive.sql(" Select a.serial_num_tx,b.oa_id , case when b.serial_num_tx is null then concat(a.filing_basis_json,'}') else concat(filing_basis_json,',',tagged_json) end as event_json  from filingBasis a Left join taggedElements b on a.serial_num_tx = b.serial_num_tx   ")
tagged_fb_df.createOrReplaceTempView("tagged_filingBasis")

firstaction_query = """SELECT oa_id ,serial_num_tx ,transactional_literal_tx , transaction_no , completed_ts,examiner_employee_no    
FROM (
SELECT fast.cfk_office_action_id as oa_id , fast.serial_num_tx ,fast.transactional_literal_tx    , fast.review_type_ct transaction_no ,fast.completed_ts completed_ts, fast.examiner_employee_no, row_number() over (partition by fast.serial_num_tx order by fast.completed_ts asc) as visit_number 
from tqr.src_fast_application_event fast join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct where upper(map_lit.first_action_in) =  'TRUE'  ) tab
WHERE visit_number = 1"""


first_action_df=hive.sql(firstaction_query) 
first_action_df.createOrReplaceTempView("first_action")
'''
if str(stg_evnt_dt) =='None':
    date_diff_df=spark.sql("select datediff(current_timestamp,current_timestamp)")
else:
    date_diff_df=spark.sql("select datediff(current_timestamp,'"+str(stg_evnt_dt)+"')")
date_diff_val=date_diff_df.collect()[0][0]
'''
date_diff_val=0

datetoadd_7day=int(First66hr)+int(date_diff_val)
datetoadd_2day=int(Other24hr)+1+int(date_diff_val)

Intervening24hrFirstquery="""select distinct fast.serial_num_tx,fast.transactional_literal_tx,cfk_office_action_id from tqr.src_fast_application_event fast join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct where   upper(map_lit.first_action_intervening_in)  = 'TRUE'  and cast(fast.completed_ts as date) between date_sub(current_timestamp,int("""+First66hr+""")) and  date_sub(current_timestamp,"""+str(First66MinusOne)+""")"""
Intervening24hrFirstDF=spark.sql(Intervening24hrFirstquery)
Intervening24hrFirstDF.createOrReplaceTempView("Intervening24hrFirst")
print 'Intervening24hrFirstquery is',Intervening24hrFirstquery

Intervening66FirstQuery="""select distinct fast.serial_num_tx,fast.transactional_literal_tx,cfk_office_action_id from tqr.src_trm_filing_basis fb join tqr.src_fast_application_event fast on fb.serial_num_tx=fast.serial_num_tx  join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct  where fb.filing_basis_cd='66(a)' and   upper(map_lit.first_action_intervening_in)  = 'TRUE'   and fb.current_in ='Y'   and cast(fast.completed_ts as date) between date_sub(current_timestamp,"""+First66hr+""") and  date_sub(current_timestamp,0)  """

Intervening66FirstDF=spark.sql(Intervening66FirstQuery)
Intervening66FirstDF.createOrReplaceTempView("Intervening66First")

print 'Intervening66FirstQuery is ', Intervening66FirstQuery

Intervening24hrFinalQuery="""select distinct fast.serial_num_tx,fast.transactional_literal_tx,cfk_office_action_id from tqr.src_fast_application_event fast join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct where  upper(map_lit.final_action_intervening_in)  = 'TRUE' and cast(fast.completed_ts as date) between date_sub(current_timestamp,"""+Other24hr+""") and  date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""" ) """

Intervening24hrFinalDF=spark.sql(Intervening24hrFinalQuery)
Intervening24hrFinalDF.createOrReplaceTempView("Intervening24hrFinal")



print 'Intervening24hrFinalQuery is ', Intervening24hrFinalQuery 

Intervening24hrPubQuery="""select distinct fast.serial_num_tx,fast.transactional_literal_tx,cfk_office_action_id from tqr.src_fast_application_event fast join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct where  upper(map_lit.pub_intervening_in)  = 'TRUE' and cast(fast.completed_ts as date) between date_sub(current_timestamp,"""+Other24hr+""") and  date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""" ) """

Intervening24hrPubDF=spark.sql(Intervening24hrPubQuery)
Intervening24hrPubDF.createOrReplaceTempView("Intervening24hrPub")
print 'Intervening24hrPubQuery is ', Intervening24hrPubQuery

Intervening24hrSouQuery="""select distinct fast.serial_num_tx,fast.transactional_literal_tx,cfk_office_action_id from tqr.src_fast_application_event fast join tqr.stnd_review_type map_lit on trim(fast.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fast.review_type_ct = map_lit.review_type_ct where  upper(map_lit.sou_intervening_in) = 'TRUE' and cast(fast.completed_ts as date) between date_sub(current_timestamp,"""+Other24hr+""") and  date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""" ) """

Intervening24hrSouDF=spark.sql(Intervening24hrSouQuery)
Intervening24hrSouDF.createOrReplaceTempView("Intervening24hrSou")
print 'Intervening24hrPubQuery is ', Intervening24hrSouQuery 

queryNoDate="""Select distinct """+first_id+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in search_present_in,case when um.serial_num_tx is not null then effective_ts else fifn.completed_ts end as  source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,fifn.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,fb.event_json as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no  
From tqr.src_trm_application app join first_action  fifn on app.serial_num_tx=fifn.serial_num_tx join tagged_filingBasis fb on app.serial_num_tx=fb.serial_num_tx   and fb.oa_id=fifn.oa_id
left join tqr.employee_organization emp on fifn.examiner_employee_no=emp.employee_no  
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and app.serial_num_tx=sp.serial_num_tx 
join tqr.stnd_review_type map_lit on trim(fifn.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fifn.transaction_no = map_lit.review_type_ct  
left join updateActionMadrid um on app.serial_num_tx= um.serial_num_tx 
where   upper(map_lit.first_action_in) =  'TRUE'  and not exists  ( Select 1 from Intervening66First 66fb where 66fb.serial_num_tx = app.serial_num_tx and fifn.oa_id = 66fb.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(66fb.transactional_literal_tx)  )    
and not exists  ( Select 1 from Intervening24hrFirst 24intFir where 24intFir.serial_num_tx = app.serial_num_tx  and fifn.oa_id = 24intFir.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(24intFir.transactional_literal_tx)  )   And fifn.completed_ts < date_sub(current_timestamp,"""+First66hr+""")  

UNION

Select distinct """+final_id+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,fifn.completed_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,fifn.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,fb.event_json as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no  
From tqr.src_trm_application app join tqr.src_fast_application_event fifn on app.serial_num_tx=fifn.serial_num_tx  
join tagged_filingBasis fb on app.serial_num_tx=fb.serial_num_tx and fb.oa_id=fifn.cfk_office_action_id 
join tqr.stnd_review_type map_lit on trim(fifn.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fifn.review_type_ct = map_lit.review_type_ct 
left join tqr.employee_organization emp on fifn.examiner_employee_no=emp.employee_no  
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and app.serial_num_tx=sp.serial_num_tx   
where   upper(map_lit.final_action_in) =  'TRUE' and not exists  ( Select 1 from Intervening24hrFinal int24Fin where int24Fin.serial_num_tx = app.serial_num_tx and fifn.cfk_office_action_id = int24Fin.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(int24Fin.transactional_literal_tx))   And fifn.completed_ts <= date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""")


UNION

Select distinct """+Pub_id+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,
pub.effective_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx ,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx  ,app.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,concat(fb.filing_basis_json,'}') as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no
From tqr.src_trm_application app join tqr.src_trm_application_event pub on app.serial_num_tx=pub.serial_num_tx  
join filingBasis fb on app.serial_num_tx=fb.serial_num_tx   
left join tqr.employee_organization emp on app.examiner_employee_no=emp.employee_no   
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and pub.serial_num_tx=sp.serial_num_tx  
Where    trim(pub.business_event_Reason_cd) in ("""+publist+""")  and not exists  ( Select 1 from Intervening24hrPub int24Pub where int24Pub.serial_num_tx = app.serial_num_tx )   And pub.effective_ts <= date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""")


UNION

Select distinct """+Sou_id+"""  as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,
sou.effective_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,app.examiner_employee_no  examiner_employee_no, case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end organization_cd,concat(fb.filing_basis_json,'}') as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no
From tqr.src_trm_application app join  tqr.src_trm_application_event sou on app.serial_num_tx=sou.serial_num_tx  
join filingBasis  fb on app.serial_num_tx=fb.serial_num_tx    
left join tqr.employee_organization emp on app.examiner_employee_no=emp.employee_no 
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and sou.serial_num_tx=sp.serial_num_tx  
Where   trim(sou.business_event_Reason_cd) in ("""+soulist+""")  and not exists  ( Select 1 from Intervening24hrSou int24Sou where int24Sou.serial_num_tx = app.serial_num_tx )   And sou.effective_ts <= date_sub(current_timestamp,"""+str(Other24hrPlusOne)+""")

 """

query_discarded="""Select distinct """+str(first_id)+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in search_present_in,fifn.completed_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,fifn.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,fb.event_json as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no  
From tqr.src_trm_application app join first_action  fifn on app.serial_num_tx=fifn.serial_num_tx 
join tagged_filingBasis fb on app.serial_num_tx=fb.serial_num_tx    and fb.oa_id=fifn.oa_id
left join tqr.employee_organization emp on fifn.examiner_employee_no=emp.employee_no 
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and app.serial_num_tx=sp.serial_num_tx 
join tqr.stnd_review_type map_lit on trim(fifn.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fifn.transaction_no = map_lit.review_type_ct  
where    upper(map_lit.first_action_in) =  'TRUE'  and (exists ( Select 1 from Intervening66First 66fb where 66fb.serial_num_tx = app.serial_num_tx  and fifn.oa_id = 66fb.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(66fb.transactional_literal_tx) )  
OR exists ( Select 1 from Intervening24hrFirst 24intFir where 24intFir.serial_num_tx = app.serial_num_tx   and fifn.oa_id = 24intFir.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(24intFir.transactional_literal_tx)  ) )  

UNION

Select distinct """+str(final_id)+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,fifn.completed_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,fifn.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,fb.event_json as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no  
From tqr.src_trm_application app join tqr.src_fast_application_event fifn on app.serial_num_tx=fifn.serial_num_tx 
join tagged_filingBasis fb on app.serial_num_tx=fb.serial_num_tx    and fb.oa_id=fifn.cfk_office_action_id
left join tqr.employee_organization emp on fifn.examiner_employee_no=emp.employee_no 
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and app.serial_num_tx=sp.serial_num_tx 
join tqr.stnd_review_type map_lit on trim(fifn.transactional_literal_tx) = trim(map_lit.transactional_literal_tx) and fifn.review_type_ct = map_lit.review_type_ct 
where   upper(map_lit.final_action_in) =  'TRUE'  and exists ( Select 1 from Intervening24hrFinal int24Fin where int24Fin.serial_num_tx = app.serial_num_tx and fifn.cfk_office_action_id = int24Fin.cfk_office_action_id and trim(fifn.transactional_literal_tx) = trim(int24Fin.transactional_literal_tx))   

UNION

Select distinct """+str(Pub_id)+""" as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,
pub.effective_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx ,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx  ,app.examiner_employee_no  examiner_employee_no,  case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end  organization_cd,concat(fb.filing_basis_json,'}') as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no
From tqr.src_trm_application app join tqr.src_trm_application_event pub on app.serial_num_tx=pub.serial_num_tx 
join filingBasis fb on app.serial_num_tx=fb.serial_num_tx   
left join tqr.employee_organization emp on app.examiner_employee_no=emp.employee_no  
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and pub.serial_num_tx=sp.serial_num_tx 
Where    trim(pub.business_event_Reason_cd) in ("""+publist+""")  and exists ( Select 1 from Intervening24hrPub int24Pub where int24Pub.serial_num_tx = app.serial_num_tx )   



UNION

Select distinct """+str(Sou_id)+"""  as review_type_cd,app.serial_num_tx serial_no, app.source_system_nm  as source_system_nm,sp.search_present_in  search_present_in,
sou.effective_ts source_event_dt,0 docket_in,case when app.literal_element_tx is null then app.standard_character_tx else app.literal_element_tx end mark_literal_element_tx,
app.mark_drawing_type_cd mark_drawing_type_cd,app.mark_drawing_type_title_tx mark_drawing_type_title_tx ,app.mark_description_tx mark_description_tx ,app.examiner_employee_no  examiner_employee_no, case when emp.status_ct = 'error' then 'ZZZ' else emp.organization_cd end organization_cd,concat(fb.filing_basis_json,'}') as event_json_doc,current_timestamp inventory_create_ts,current_timestamp create_ts,'etl' create_user_id,current_timestamp last_mod_ts,'etl' last_mod_user_id,0 as lock_control_no
From tqr.src_trm_application app join  tqr.src_trm_application_event sou on app.serial_num_tx=sou.serial_num_tx 
join filingBasis  fb on app.serial_num_tx=fb.serial_num_tx   
left join tqr.employee_organization emp on app.examiner_employee_no=emp.employee_no 
join tqr.application_search_present sp on app.serial_num_tx=sp.serial_num_tx and sou.serial_num_tx=sp.serial_num_tx 
Where   trim(sou.business_event_Reason_cd) in ("""+soulist+""")  and exists( Select 1 from Intervening24hrSou int24Sou where int24Sou.serial_num_tx = app.serial_num_tx )   


 """
query  = queryNoDate

spark.sql("USE TQR")


loadDF=spark.sql(query)
print("entire query is" + query)
loadDF.printSchema()

loadDF.createOrReplaceTempView("event_inventory_temp")

discardedDF=spark.sql(query_discarded )
print("entire discarded query is" + query_discarded )



discardedDF.createOrReplaceTempView("event_inventory_discarded")

insert_df= spark.sql(stg_ins_queryCnt)
ins_cnt=str(insert_df.collect()[0][0])
print 'stg_ins_query count', str(ins_cnt)

print 'stg_ins_query cnt query ', stg_ins_queryCnt

discard_df= spark.sql(stg_disc_queryCnt)
discard_cnt=str(discard_df.collect()[0][0])
print 'stg_discarded_query count', str(discard_cnt)

spark.sql("truncate table tqr.event_inventory_stage " )
spark.sql("insert into tqr.event_inventory_stage " + stg_ins_query)
spark.sql("insert into tqr.event_inventory_discarded " + stg_disc_query)
spark.sql(" insert into tqr.job_control select * from (select 'event_inventory_stage' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl') tab ")

spark.sql("insert into tqr.job_log select   'tqr-load_event_inventory_stage',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(ins_cnt)+",'event inventory stage table count'")
spark.sql("insert into tqr.job_log select   'tqr-load_event_inventory_discarded',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(discard_cnt)+",'event inventory discarded table count'")
spark.stop()
