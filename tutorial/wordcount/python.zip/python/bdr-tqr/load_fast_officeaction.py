from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')

spark = SparkSession \
    .builder \
    .appName("Tqrs fast final action") \
    .enableHiveSupport()\
    .getOrCreate()

#url ="jdbc:oracle:thin:@dev-eis-scan.etc.uspto.gov:1626/TMNGFQT"
url = config.get('tqr','fasturl')
userId = config.get('tqr','fastuserId')
passwordVal = config.get('tqr','fastpasswordVal')
TimeOut = config.get('tqr','TimeOut')
finalactionlist = config.get('tqr','finalactionlist')
date = sys.argv[2]
date_new = date.replace("$"," ")
dataload_dt = config.get('tqr','dataload_dt')
print ("Final actions ... ",finalactionlist)


dbschema=config.get('tqr','fastdbschema')


cntl_dt_df= spark.sql("select max(load_ts) from tqr.job_control where job_nm = 'fast_officeaction' ")
fast_app_evnt_dt=cntl_dt_df.collect()[0][0]


fastquery=""" SELECT oa_id as cfk_office_action_id , fk_cf_id as serial_num_tx,transactional_literal as transactional_literal_tx  ,transaction_no , completed_dt as completed_ts ,fk_wrkr_id as examiner_employee_no
 from  """+dbschema+""".OFFICE_ACTION """
#Where trim(TRANSACTIONAL_LITERAL) in ("""+finalactionlist+""")
oa_ins_query="select distinct * ,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts,'etl' as last_mod_user_id from officeaction "
oa_ins_queryCnt="select count(1) from officeaction "

fast_app_evnt_dt = str(fast_app_evnt_dt)


if str(fast_app_evnt_dt) =='None':
    fastquery += " Where  completed_dt   > "+"to_timestamp("+str(dataload_dt)+", 'YYYY-MM-DD HH24:MI:SS') "
else:
    if str(fast_app_evnt_dt).find('.')==-1:
	fast_app_evnt_dt = str(fast_app_evnt_dt)
    else:
        fast_app_evnt_dt = fast_app_evnt_dt[:str(fast_app_evnt_dt).find('.')]
        fastquery += " Where  completed_dt   > "+"to_timestamp('"+str(fast_app_evnt_dt)+"', 'YYYY-MM-DD HH24:MI:SS') "

print(fastquery + " This is fastquery ")
print( oa_ins_query + " This is oa_ins_query " )

oaDF = spark.read.jdbc(url,"("+fastquery+")", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
oaDF.createOrReplaceTempView("officeaction")



spark.sql("insert into tqr.src_fast_application_event " + oa_ins_query ) 
spark.sql(" insert into tqr.job_control select * from (select 'fast_officeaction' as job_nm ,current_timestamp as load_ts ,current_timestamp,'etl',current_timestamp,'etl'  ) tab ")

spark.sql("insert into tqr.job_log select   'tqr-load_fast_officeaction',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(oaDF.count())+",'fast office action event count'")

spark.stop()
