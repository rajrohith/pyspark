from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
from pyspark.sql.functions import udf, lit, unix_timestamp, from_unixtime
from pyspark.sql.functions import col
from datetime import date,datetime
import json, traceback, datetime, hashlib, sys
from functools import partial
import json, re
from pyspark.sql.functions import lit
import datetime
import pandas as pd
from datetime import datetime, timedelta
import json
import hashlib
import traceback
spark = SparkSession \
    .builder \
    .appName("upsert event_inventory ") \
    .enableHiveSupport()\
    .getOrCreate()
hive = HiveContext(spark)

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-tqr.properties')
print 'config path',config_path+'/bdr-tqr.properties'
date = sys.argv[2]
date_new = date.replace("$"," ")

mysqlurl = config.get('tqr','mysqlurl')
userId = config.get('tqr','mysqluserId')
passwordVal = config.get('tqr','mysqlpasswordVal')
mysqltablename = config.get('tqr','tablename')

my_sqlhost=config.get('tqr','mysqlhost')
my_sqlport=config.get('tqr','mysqlport')
my_sqldatabase=config.get('tqr','mysqldatabase')

event_inventorydf=spark.read.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable=mysqltablename,
      user=userId,
      password=passwordVal).load()
event_inventorydf.createOrReplaceTempView("mysqlevent_inventory")

merge_event_inventorydf=spark.sql("""Select   fk_review_type_id,  serial_no,source_system_nm,search_present_in,source_event_dt,docket_in,mark_literal_element_tx,mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no ,organization_cd,lock_control_no,event_json_doc,inventory_create_ts,create_ts, create_user_id,last_mod_ts, last_mod_user_id from ( Select review_type_cd as fk_review_type_id,serial_num_tx as serial_no,source_system_nm,search_present_in,source_event_dt,docket_in,mark_literal_element_tx,mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no,case when organization_cd is null then 'ZZZ' else organization_cd end as organization_cd,lock_control_no,event_json_doc,inventory_create_ts,create_ts,'etl' as create_user_id,last_mod_ts,'etl' as last_mod_user_id,row_number() over(partition by review_type_cd, serial_num_tx ,from_unixtime(unix_timestamp(stg.source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss')  order by from_unixtime(unix_timestamp(source_event_dt,"yyyy-MM-dd HH:mm:ss"))) as rownum from tqr.event_inventory_stage stg Where  not exists ( select 1 from  mysqlevent_inventory event where stg.serial_num_tx=event.serial_no and from_unixtime(unix_timestamp(stg.source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss')=from_unixtime(unix_timestamp(event.source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss') and stg.review_type_cd=event.fk_review_type_id ) ) As tab where  rownum=1 and fk_review_type_id is not null """)
print ('merge_event_inventorydf count' + str(merge_event_inventorydf.count()) )


merge_event_inventorydf.write.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable='temp_table',
      user=userId,
      password=passwordVal).mode('overwrite').save()
if merge_event_inventorydf.count() >0:
	sql=""" INSERT into """+mysqltablename+""" ( fk_review_type_id,serial_no,source_system_nm,search_present_in,source_event_dt,docket_in,mark_literal_element_tx,  \
	mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no,organization_cd,event_json_doc,inventory_create_ts,create_ts,create_user_id, \
	last_mod_ts,last_mod_user_id,lock_control_no) \
	   Select fk_review_type_id,serial_no,source_system_nm,search_present_in,source_event_dt,docket_in,mark_literal_element_tx,  \
	mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no,organization_cd,event_json_doc,inventory_create_ts,create_ts,create_user_id, \
	last_mod_ts,last_mod_user_id,lock_control_no from temp_table t \
	   ON DUPLICATE KEY UPDATE source_system_nm = t.source_system_nm , search_present_in = t.search_present_in ,  docket_in = t.docket_in , mark_literal_element_tx = t.mark_literal_element_tx , mark_drawing_type_cd = t.mark_drawing_type_cd , mark_drawing_type_title_tx = t.mark_drawing_type_title_tx , mark_description_tx = t.mark_description_tx , examiner_employee_no = t.examiner_employee_no , organization_cd = t.organization_cd , event_json_doc = t.event_json_doc , lock_control_no = t.lock_control_no, last_mod_ts = now() ;  """
	sqlbak=""" UPDATE  """+mysqltablename+""" t1 \
        INNER JOIN temp_table t2 \
             ON t1.serial_no = t2.serial_no  \
	SET t1.last_mod_ts =  now(),   t1.mark_description_tx = t2.mark_literal_element_tx """

import mysql.connector                              
cnx = mysql.connector.connect(user=userId, password=passwordVal,
                              host=my_sqlhost,port=my_sqlport,
                              database=my_sqldatabase)
cursor = cnx.cursor()
if merge_event_inventorydf.count() >0:
	cursor.execute(sql)
	cursor.execute("drop table IF EXISTS temp_table")
	cursor.execute("commit")

bdr_event_inventorydf=spark.read.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable=mysqltablename,
      user=userId,
      password=passwordVal).load()
bdr_event_inventorydf.createOrReplaceTempView("event_inventory_mysql")
print ('bdr_event_inventorydf.count',str(bdr_event_inventorydf.count()))

update_event_inventorydf=spark.sql("""Select   fk_review_type_id,  serial_no,source_system_nm,search_present_in,from_unixtime(unix_timestamp(source_event_dt,"yyyy-MM-dd HH:mm:ss")) as source_event_dt,docket_in,mark_literal_element_tx,mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no ,organization_cd,lock_control_no,event_json_doc,inventory_create_ts,create_ts, create_user_id,last_mod_ts, last_mod_user_id from ( Select review_type_cd as fk_review_type_id,serial_num_tx as serial_no,source_system_nm,search_present_in,source_event_dt,docket_in,mark_literal_element_tx,mark_drawing_type_cd,mark_drawing_type_title_tx,mark_description_tx,examiner_employee_no,case when organization_cd is null then 'ZZZ' else organization_cd end as organization_cd,lock_control_no,event_json_doc,inventory_create_ts,create_ts,'etl' as create_user_id,last_mod_ts,'etl' as last_mod_user_id,row_number() over(partition by review_type_cd, serial_num_tx ,from_unixtime(unix_timestamp(source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss')  order by from_unixtime(unix_timestamp(source_event_dt,"yyyy-MM-dd HH:mm:ss"))) as rownum from tqr.event_inventory_stage stg Where  exists ( select 1 from  event_inventory_mysql event where stg.serial_num_tx=event.serial_no and from_unixtime(unix_timestamp(stg.source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss')=from_unixtime(unix_timestamp(event.source_event_dt,"yyyy-MM-dd HH:mm:ss"),'yyyy-MM-dd HH:mm:ss') and stg.review_type_cd=event.fk_review_type_id  ) ) As tab where  rownum=1 and fk_review_type_id is not null  """)

update_event_inventorydf.write.format('jdbc').options(
      url=mysqlurl,
      driver='com.mysql.jdbc.Driver',
      dbtable='temp_table',
      user=userId,
      password=passwordVal).mode('overwrite').save()
print ('update_event_inventorydf count'+ str(update_event_inventorydf.count()))
sql=""" UPDATE """+mysqltablename+"""  event INNER JOIN temp_table temp ON event.fk_review_type_id = temp.fk_review_type_id and event.serial_no = temp.serial_no and event.source_event_dt= temp.source_event_dt \
    SET event.source_system_nm = temp.source_system_nm , event.search_present_in = temp.search_present_in ,  event.docket_in = temp.docket_in , event.mark_literal_element_tx = temp.mark_literal_element_tx , event.mark_drawing_type_cd = temp.mark_drawing_type_cd , event.mark_drawing_type_title_tx = temp.mark_drawing_type_title_tx , event.mark_description_tx = temp.mark_description_tx , event.event_json_doc = temp.event_json_doc , event.lock_control_no = temp.lock_control_no  , event.examiner_employee_no = temp.examiner_employee_no , event.organization_cd = temp.organization_cd  ,event.last_mod_ts=now();   """

cursor.execute("ALTER TABLE "+ mysqltablename +" MODIFY source_event_dt timestamp DEFAULT CURRENT_TIMESTAMP")
cursor.execute(sql)
cursor.execute("commit")
cursor.execute("drop table IF EXISTS temp_table")

spark.sql("insert into tqr.job_log select   'tqr-load_event_inventory',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(merge_event_inventorydf.count())+",'event inventory insert count'")
spark.sql("insert into tqr.job_log select   'tqr-load_event_inventory',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(update_event_inventorydf.count())+",'event inventory update count'")


cnx.close()
