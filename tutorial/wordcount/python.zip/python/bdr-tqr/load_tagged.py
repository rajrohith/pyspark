from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
spark = SparkSession \
    .builder \
    .appName("event inventory load") \
    .enableHiveSupport()\
    .getOrCreate()


query="""Select * from tqr.temp """
spark.sql("USE TQR")
loadDF=spark.sql(query)
print loadDF.count(),"Final count of data"
loadDF.createOrReplaceTempView("stnd_tagged_element")
loadDF.write.format('jdbc').options(
      url='jdbc:mysql://bdr-itwv-db-1.dev.uspto.gov:3306/bdr',
      driver='com.mysql.jdbc.Driver',
      dbtable='stnd_tagged_element',
      user='bdr_admin',
      password='ChangeMe_123').mode('append').save()

