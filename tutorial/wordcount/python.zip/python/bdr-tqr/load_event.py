from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
url ="jdbc:oracle:thin:@fqt-tmng-db-1.fqt.uspto.gov:1612/TRMNGFQT12"
trmquery = """ SELECT  TM.SERIAL_NUM_TX serial_no, EC.TRANSACTION_EFFECTIVE_DT ,                           
        TM.TRADEMARK_GID trademark_gid,
        EM.CFK_EMPLOYEE_NO examiner_employee_no,
        TML.LITERAL_ELEMENT_TX mark_literal_tx
        ,TM.MARK_DESCRIPTION_TX mark_literal_description_tx
        ,SMDT.MARK_DRAWING_TYPE_CD||'-'||SMDT.DESCRIPTION_TX mark_drawing_cd,
        TM.lock_control_no,
        case when FK_CREDIT_TRAN_RSN_TYPE_CD = 'FA' then 100 else 102 end as fk_review_type_id ,
	FT.TITLE_TX as source_system_nm                       
FROM    TMNGFQTDB12.TRADEMARK TM 
           INNER JOIN TMNGFQTDB12.EMPLOYEE_CREDIT_TRANSACTION EC ON TM.TRADEMARK_GID = EC.FK_TRADEMARK_GID
           INNER JOIN TMNGFQTDB12.TM_EMPLOYEE_ASSIGNMENT EM ON TM.TRADEMARK_GID = EM.FK_TRADEMARK_GID
		   INNER JOIN TMNGFQTDB12.TM_MILESTONE MI ON TM.TRADEMARK_GID = MI.FK_TRADEMARK_GID
		   INNER JOIN TMNGFQTDB12.STND_TM_MILESTONE SM ON MI.FK_TM_MILESTONE_CD = SM.TM_MILESTONE_CD
		   INNER JOIN TMNGFQTDB12.STND_TM_EMPLOYEE_ASGMT_ROLE ES ON EM.FK_TM_EMPLOYEE_ROLE_CD = ES.TM_EMPLOYEE_ROLE_CD
		   INNER JOIN TMNGFQTDB12.STND_MARK_DRAWING_TYPE SMDT ON SMDT.MARK_DRAWING_TYPE_CD = TM.FK_MARK_DRAWING_TYPE_CD 
                   INNER JOIN TMNGFQTDB12.STND_FEE_PROCESS_TYPE FT ON TM.FK_FEE_PROCESS_TYPE_CD = FT.FEE_PROCESS_TYPE_CD
                   LEFT OUTER JOIN TMNGFQTDB12.TM_LITERAL TML ON TML.FK_TRADEMARK_GID = TM.TRADEMARK_GID
WHERE      TM_EMPLOYEE_ROLE_CD = 'EA'                         
       AND FK_CREDIT_TRAN_RSN_TYPE_CD IN ('FA' ,'PUB')                   
 """
spark = SparkSession \
    .builder \
    .appName("tqr event load") \
    .enableHiveSupport()\
    .getOrCreate()
#jobdf= spark.sql("select 1 from tqr.job_log ")
#eventid =jobdf.count()+1
#spark.sql("insert into tqr.job_log select "+str(eventid)+" ,'bdr-tqr','load-event',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'started','',0 ") 

appDF = spark.read \
    .jdbc(url, "("+trmquery+")", properties={"user": "BIGDATAREAD", "password": "Pat3nt_Trad3mark", "connection_timeout": "1000"})
appDF.createOrReplaceTempView("event")
spark.sql("DROP TABLE IF EXISTS tqr.event ")
spark.sql("CREATE TABLE tqr.event STORED AS ORC select distinct serial_no, TRANSACTION_EFFECTIVE_DT ,trademark_gid,examiner_employee_no,mark_literal_tx \
, mark_literal_description_tx ,mark_drawing_cd,lock_control_no , cast(fk_review_type_id as int), source_system_nm from event")        

trminsquery = """
SELECT  TM.SERIAL_NUM_TX serial_no, EC.TRANSACTION_EFFECTIVE_DT ,                           
        TM.TRADEMARK_GID trademark_gid,
        EM.CFK_EMPLOYEE_NO examiner_employee_no,                         
        TML.LITERAL_ELEMENT_TX mark_literal_tx
        ,TM.MARK_DESCRIPTION_TX mark_literal_description_tx
        ,SMDT.MARK_DRAWING_TYPE_CD||'-'||SMDT.DESCRIPTION_TX mark_drawing_cd  ,
        TM.lock_control_no,
        case when WI.FK_WORK_ITEM_TYPE_CD LIKE 'FREF' then 101 else 103 end as fk_review_type_id,
	FT.TITLE_TX as source_system_nm                         
FROM    TMNGFQTDB12.TRADEMARK TM 
           INNER JOIN TMNGFQTDB12.EMPLOYEE_CREDIT_TRANSACTION EC ON TM.TRADEMARK_GID = EC.FK_TRADEMARK_GID
           INNER JOIN TMNGFQTDB12.TM_EMPLOYEE_ASSIGNMENT EM ON TM.TRADEMARK_GID = EM.FK_TRADEMARK_GID
		   INNER JOIN TMNGFQTDB12.TM_MILESTONE MI ON TM.TRADEMARK_GID = MI.FK_TRADEMARK_GID
		   INNER JOIN TMNGFQTDB12.STND_TM_MILESTONE SM ON MI.FK_TM_MILESTONE_CD = SM.TM_MILESTONE_CD
		   INNER JOIN TMNGFQTDB12.STND_TM_EMPLOYEE_ASGMT_ROLE ES ON EM.FK_TM_EMPLOYEE_ROLE_CD = ES.TM_EMPLOYEE_ROLE_CD
		   INNER JOIN TMNGFQTDB12.WORK_ITEM_OBJECT WIO ON TM.TRADEMARK_GID = WIO.CFK_OBJECT_GID
		   INNER JOIN TMNGFQTDB12.WORK_ITEM WI ON WI.WORK_ITEM_GID = WIO.FK_WORK_ITEM_GID
                   INNER JOIN TMNGFQTDB12.STND_MARK_DRAWING_TYPE SMDT ON SMDT.MARK_DRAWING_TYPE_CD = TM.FK_MARK_DRAWING_TYPE_CD
                   INNER JOIN TMNGFQTDB12.STND_FEE_PROCESS_TYPE FT ON TM.FK_FEE_PROCESS_TYPE_CD = FT.FEE_PROCESS_TYPE_CD 
                   LEFT OUTER JOIN TMNGFQTDB12.TM_LITERAL TML ON TML.FK_TRADEMARK_GID = TM.TRADEMARK_GID		    
WHERE       TM_EMPLOYEE_ROLE_CD = 'EA'                    
             AND (  WI.FK_WORK_ITEM_TYPE_CD LIKE 'FREF'  OR WI.FK_WORK_ITEM_TYPE_CD like '%CNPRP%'  
                        OR WI.FK_WORK_ITEM_TYPE_CD like  '%CNSRP%' ) """
eventDF = spark.read \
    .jdbc(url, "("+trminsquery +")", properties={"user": "BIGDATAREAD", "password": "Pat3nt_Trad3mark", "connection_timeout": "1000"})
eventDF.createOrReplaceTempView("event_ins")
spark.sql("INSERT INTO tqr.event  select distinct * from event_ins")   
#totreccnt = appDF.count()+eventDF.count() 

#spark.sql("update tqr.job_log set endtime = CURRENT_TIMESTAMP,status = 'completed',comments='No of records pushed to hive event table',no_of_recs_processed =10  where id= " +  str(eventid) +" ") 
spark.stop()

