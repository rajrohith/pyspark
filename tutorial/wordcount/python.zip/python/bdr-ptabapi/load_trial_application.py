from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-ptab.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

ptaburl = config.get('ptab','ptaburl')
userId = config.get('ptab','userId')
passwordVal = config.get('ptab','passwordVal')
TimeOut = config.get('ptab','TimeOut')
dbschema=config.get('ptab','ptabdbschema')
dataload_dt = config.get('ptab','dataload_dt')

spark = SparkSession \
    .builder \
    .appName("extract trials data") \
    .enableHiveSupport()\
    .getOrCreate()
import time
ts = time.time()	
import datetime
starttime = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')


git_id_query = """  SELECT p.PROCEEDING_ID as id, 
    p.PROCEEDING_NO      AS TRIAL_NO,
   p.PROCEEDING_NAME_TX AS TRIAL_NM,
    p.PATENT_NO          AS PATENT_NO,
    pid.APPLICATION_ID   AS APPLICATION_NO,
    pid.PATENT_OWNER_NM   AS PATENT_OWNER_NM,
    pid.INVENTOR_FULL_NM  AS INVENTORS_NM,
    sfts.STATE_NM         AS PROSECUTION_STATUS, 
    p.CREATE_TS           AS CREATE_TS,
    p.CREATE_USER_ID      AS CREATE_USER_ID,
    greatest(NVL(p.LAST_MOD_TS ,DATE '1900-01-01'),
    NVL(sfts.LAST_MOD_TS,DATE '1900-01-01'),
    NVL(pfi.LAST_MOD_TS,DATE '1900-01-01'),
    NVL(pid.LAST_MOD_TS,DATE '1900-01-01')) AS LAST_MOD_TS, 
    p.LAST_MOD_USER_ID    AS LAST_MOD_USER_ID,
    sfts.FSM_STATE_ID   AS FSM_STATE_ID,
    p.confidentiality_in AS CONFIDENTIALITY_IN,
    p.LAST_MOD_TS AS   LAST_MOD_TMSTMP,
    pt.FK_PARTY_TYPE_ID AS PARTY_TYPE_ID,
    pp.FK_PARTY_ID AS PARTY_ID,
    pp.RANK_NO  AS RANK_NO,
    pp.FK_PRCDNG_PARTY_TYPE_CD AS PRCDNG_PARTY_TYPE_CD,
    ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID AS PRCDNG_PARTY_GROUP_STAT_ID,
    ppg.PROCEEDING_PARTY_GROUP_ID AS PROCEEDING_PARTY_GROUP_ID,
    ppg.FK_PRCDNG_PARTY_GROUP_TYPE_ID AS PRCDNG_PARTY_GROUP_TYPE_ID
       
  FROM  """+dbschema+""".PROCEEDING p, 
        """+dbschema+""".STND_FSM_TYPE_STATE sfts, 
        """+dbschema+""".PROCEEDING_FSM_INSTANCE pfi,
        """+dbschema+""".PRCDNG_INVENTION_DISCLOSURE pid,
        """+dbschema+""".PARTY pt,
        """+dbschema+""".PROCEEDING_PARTY pp,
        """+dbschema+""".PROCEEDING_PARTY_GROUP ppg
        
  where pfi.CFK_CURRENT_FSM_STATE_ID = sfts.FSM_STATE_ID
  and p.PROCEEDING_ID = pfi.FK_PROCEEDING_ID
  and p.PROCEEDING_ID = pid.FK_PROCEEDING_ID
  and sfts.FSM_STATE_ID NOT IN (1001 , 1012, 1017, 1011)
  and p.confidentiality_in = 'N'
  
  and pt.PARTY_ID                        = pp.FK_PARTY_ID
  and p.PROCEEDING_ID                    = pp.FK_PROCEEDING_ID
  and pp.FK_PROCEEDING_PARTY_GROUP_ID    = ppg.PROCEEDING_PARTY_GROUP_ID
  and pp.RANK_NO                         = 1
  and ppg.FK_PRCDNG_PARTY_GROUP_TYPE_ID  = 1
  and ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID  = 1  
  AND pp.FK_PRCDNG_PARTY_TYPE_CD        ='REAL PARTY'
  """

  

get_party_nm_query = """  SELECT gid.id as id, 
       gid.PARTY_TYPE_ID as PARTY_TYPE_ID, 
       gid.PARTY_ID as PARTY_ID, 
       gid.RANK_NO as RANK_NO, 
       gid.PRCDNG_PARTY_TYPE_CD as PRCDNG_PARTY_TYPE_CD,
       gid.PRCDNG_PARTY_GROUP_STAT_ID as PRCDNG_PARTY_GROUP_STAT_ID,
       gid.PROCEEDING_PARTY_GROUP_ID as PROCEEDING_PARTY_GROUP_ID, 
       gid.PRCDNG_PARTY_GROUP_TYPE_ID as PRCDNG_PARTY_GROUP_TYPE_ID,
CASE
      WHEN (SELECT DISTINCT FK_PARTY_TYPE_ID
        FROM  """+dbschema+""".PARTY p,
           """+dbschema+""".PROCEEDING_PARTY pp,
           """+dbschema+""".PROCEEDING_PARTY_GROUP ppg
        WHERE p.PARTY_ID                      = pp.FK_PARTY_ID
        AND pp.FK_PROCEEDING_ID               = gid.id
        AND pp.RANK_NO                        = 1
        AND pp.FK_PRCDNG_PARTY_TYPE_CD        ='REAL PARTY'
        AND ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID = 1
        AND ROWNUM                            =1 ) = 1
      THEN
        (SELECT  ip.FIRST_NM || ', '|| ip.LAST_NM
        FROM  """+dbschema+""".PARTY p,
              """+dbschema+""".PROCEEDING_PARTY pp,
           """+dbschema+""".PROCEEDING_PARTY_GROUP ppg,
           """+dbschema+""".INDIVIDUAL_PARTY ip
        WHERE p.PARTY_ID                     = pp.FK_PARTY_ID 
        AND  pp.FK_PROCEEDING_ID             = ppg.FK_PROCEEDING_ID
        AND pp.FK_PROCEEDING_PARTY_GROUP_ID   = ppg.PROCEEDING_PARTY_GROUP_ID
        AND pp.FK_PARTY_ID                    = ip.FK_PARTY_ID
        AND pp.FK_PROCEEDING_ID               = gid.id
        AND pp.FK_PRCDNG_PARTY_TYPE_CD        = 'REAL PARTY'
        AND pp.RANK_NO                        = 1
        AND ppg.FK_PRCDNG_PARTY_GROUP_TYPE_ID = 1
        AND ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID = 1
        AND ROWNUM                            =1
        )
      WHEN (SELECT FK_PARTY_TYPE_ID
        FROM  """+dbschema+""".PARTY p,
           """+dbschema+""".PROCEEDING_PARTY pp,
           """+dbschema+""".PROCEEDING_PARTY_GROUP ppg
        WHERE p.PARTY_ID                      = pp.FK_PARTY_ID
        AND pp.FK_PROCEEDING_ID               = gid.id
        AND pp.RANK_NO                        = 1
        AND pp.FK_PRCDNG_PARTY_TYPE_CD        ='REAL PARTY'
        AND ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID = 1
        AND ROWNUM                            =1 ) = 2
      THEN
        (SELECT DISTINCT op.ORGANIZATION_NM

        FROM  """+dbschema+""".PARTY p, 
              """+dbschema+""".PROCEEDING_PARTY pp,
           """+dbschema+""".PROCEEDING_PARTY_GROUP ppg,
           """+dbschema+""".ORGANIZATION_PARTY op
        WHERE p.PARTY_ID                     = pp.FK_PARTY_ID 
        AND pp.FK_PROCEEDING_ID             = ppg.FK_PROCEEDING_ID
        AND pp.FK_PROCEEDING_PARTY_GROUP_ID   = ppg.PROCEEDING_PARTY_GROUP_ID
        AND pp.FK_PARTY_ID                    = op.FK_PARTY_ID
        AND pp.FK_PROCEEDING_ID               = gid.id
        AND pp.FK_PRCDNG_PARTY_TYPE_CD        = 'REAL PARTY'
        AND pp.RANK_NO                        = 1
        AND ppg.FK_PRCDNG_PARTY_GROUP_TYPE_ID = 1
        AND ppg.FK_PRCDNG_PARTY_GROUP_STAT_ID = 1
        AND ROWNUM                            =1
        )
      ELSE 'NA'
    END  AS PETITIONER_PARTY_NM,ROWNUM as row_num
  FROM  """
  
cntl_dt_df= spark.sql("select max(lastsuccessrunts) from ptab.job_master where jobnm = 'load_trial_application'")
trial_evnt_dt=str(cntl_dt_df.collect()[0][0])

if str(trial_evnt_dt) =='None':
    git_id_query += " and  (  ( trunc(p.create_ts) >= to_date('"+dataload_dt+"', 'YYYY-MM-DD')   )  \
        OR \
        ( trunc(greatest(NVL(p.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(sfts.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(pfi.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(pid.LAST_MOD_TS,DATE '1900-01-01')))\
                                >= to_date('"+dataload_dt+"', 'YYYY-MM-DD') \
        )\
      )  "   

else:
    if str(trial_evnt_dt).find('.')==-1:
	trial_evnt_dt = str(trial_evnt_dt)
    else:
        trial_evnt_dt = trial_evnt_dt[:str(trial_evnt_dt).find('.')]
        git_id_query += " and  (  ( trunc(p.create_ts) >= to_date('"+str(trial_evnt_dt)+"', 'YYYY-MM-DD HH24:MI:SS')   )  \
        OR \
        ( trunc(greatest(NVL(p.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(sfts.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(pfi.LAST_MOD_TS,DATE '1900-01-01'), \
                    NVL(pid.LAST_MOD_TS,DATE '1900-01-01')))\
                                >= to_date('"+str(trial_evnt_dt)+"', 'YYYY-MM-DD HH24:MI:SS') \
        )\
      )  "   
	
get_party_nm_query += " ( " + git_id_query + ") gid "	
get_filing_dt_query="""   SELECT gid.id as id, pms.MILESTONE_DT as FILING_DT, NVL(pms.LAST_MOD_TS, DATE '1900-01-01') as LAST_MOD_TS, pms.FK_MILESTONE_TYPE_ID as MILESTONE_TYPE_ID
  from ( """ + git_id_query +""" ) gid
  full JOIN """+dbschema+""".PROCEEDING_MILESTONE pms
  ON pms.FK_PROCEEDING_ID = gid.id
  AND pms.FK_MILESTONE_TYPE_ID = 1 """

get_accorded_filing_dt_query=""" SELECT  gid.id as id, pms.MILESTONE_DT as ACCORDED_FILING_DT, NVL(pms.LAST_MOD_TS, DATE '1900-01-01') as LAST_MOD_TS, pms.FK_MILESTONE_TYPE_ID as MILESTONE_TYPE_ID
  from ( """ + git_id_query +""" ) gid
  full JOIN """+dbschema+""".PROCEEDING_MILESTONE pms
  ON pms.FK_PROCEEDING_ID = gid.id
  AND pms.FK_MILESTONE_TYPE_ID = 2 """

get_institution_decision_dt_query=""" SELECT gid.id as id, pms.MILESTONE_DT as INSTITUTION_DECISION_DT,NVL(pms.LAST_MOD_TS, DATE '1900-01-01') as LAST_MOD_TS, pms.FK_MILESTONE_TYPE_ID as MILESTONE_TYPE_ID
  from ( """ + git_id_query +""" ) gid
  full JOIN """+dbschema+""".PROCEEDING_MILESTONE pms
  ON pms.FK_PROCEEDING_ID = gid.id
  AND pms.FK_MILESTONE_TYPE_ID = 5 """

get_final_decision_dt_query=""" SELECT gid.id as id, pms.MILESTONE_DT as FINAL_DECISION_DT, NVL(pms.LAST_MOD_TS, DATE '1900-01-01') as LAST_MOD_TS, pms.FK_MILESTONE_TYPE_ID as MILESTONE_TYPE_ID
  from ( """ + git_id_query +""" ) gid
  full JOIN """+dbschema+""".PROCEEDING_MILESTONE pms
  ON pms.FK_PROCEEDING_ID = gid.id
  AND pms.FK_MILESTONE_TYPE_ID = 6 """
trial_query =""" select get_id.TRIAL_NO, get_id.TRIAL_NM, get_id.APPLICATION_NO, get_id.PATENT_NO, 
    get_party_nm.PETITIONER_PARTY_NM, get_id.PATENT_OWNER_NM,
    get_id.INVENTORS_NM, get_id.PROSECUTION_STATUS, 
    get_filing_dt.FILING_DT, get_accorded_filing_dt.ACCORDED_FILING_DT, 
    get_institution_decision_dt.INSTITUTION_DECISION_DT, get_final_decision_dt.FINAL_DECISION_DT, 
    get_id.CREATE_TS, get_id.CREATE_USER_ID,
   case when get_id.LAST_MOD_TS >= get_filing_dt.LAST_MOD_TS and get_id.LAST_MOD_TS >= get_accorded_filing_dt.LAST_MOD_TS and get_id.LAST_MOD_TS >= get_institution_decision_dt.LAST_MOD_TS and get_id.LAST_MOD_TS >= get_final_decision_dt.LAST_MOD_TS then get_id.LAST_MOD_TS 
    when get_accorded_filing_dt.LAST_MOD_TS >= get_filing_dt.LAST_MOD_TS  and get_accorded_filing_dt.LAST_MOD_TS >=get_id.LAST_MOD_TS and get_accorded_filing_dt.LAST_MOD_TS >=get_institution_decision_dt.LAST_MOD_TS and get_accorded_filing_dt.LAST_MOD_TS >=get_final_decision_dt.LAST_MOD_TS then get_accorded_filing_dt.LAST_MOD_TS
     when get_institution_decision_dt.LAST_MOD_TS >= get_filing_dt.LAST_MOD_TS  and get_institution_decision_dt.LAST_MOD_TS >=get_id.LAST_MOD_TS and get_institution_decision_dt.LAST_MOD_TS >= get_accorded_filing_dt.LAST_MOD_TS and get_institution_decision_dt.LAST_MOD_TS >=get_final_decision_dt.LAST_MOD_TS then get_institution_decision_dt.LAST_MOD_TS
     when get_final_decision_dt.LAST_MOD_TS >= get_filing_dt.LAST_MOD_TS  and get_final_decision_dt.LAST_MOD_TS >=get_id.LAST_MOD_TS and get_final_decision_dt.LAST_MOD_TS >= get_accorded_filing_dt.LAST_MOD_TS and get_final_decision_dt.LAST_MOD_TS >=get_institution_decision_dt.LAST_MOD_TS then get_final_decision_dt.LAST_MOD_TS
     else '1900-01-01' end as LAST_MOD_TS , 
    get_id.LAST_MOD_USER_ID ,get_id.id, get_id.FSM_STATE_ID,get_id.CONFIDENTIALITY_IN,get_id.LAST_MOD_TMSTMP,
    get_filing_dt.LAST_MOD_TS,get_filing_dt.MILESTONE_TYPE_ID,
    get_accorded_filing_dt.LAST_MOD_TS,get_accorded_filing_dt.MILESTONE_TYPE_ID,
    get_institution_decision_dt.LAST_MOD_TS,get_institution_decision_dt.MILESTONE_TYPE_ID, get_filing_dt.LAST_MOD_TS,get_filing_dt.MILESTONE_TYPE_ID, get_party_nm.PARTY_TYPE_ID,get_party_nm.PARTY_ID,get_party_nm.RANK_NO,get_party_nm.PRCDNG_PARTY_TYPE_CD,get_party_nm.PRCDNG_PARTY_GROUP_STAT_ID,get_party_nm.PROCEEDING_PARTY_GROUP_ID,get_party_nm.PRCDNG_PARTY_GROUP_TYPE_ID,get_party_nm.row_num 
from get_id  join get_filing_dt  on get_id.id = get_filing_dt.id join  get_accorded_filing_dt  on get_id.id = get_accorded_filing_dt.id  
join get_institution_decision_dt  on get_id.id = get_institution_decision_dt.id join  get_final_decision_dt  on  get_id.id = get_final_decision_dt.id join get_party_nm  on get_id.id = get_party_nm.id """

print 'git_id_query ' , git_id_query 

git_id_DF = spark.read \
    .jdbc(ptaburl, "("+git_id_query+")",properties={"user": userId, "password": passwordVal,  "connection_timeout": TimeOut})
git_id_DF.createOrReplaceTempView("get_id")

get_party_nm_DF = spark.read \
    .jdbc(ptaburl, "("+get_party_nm_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
get_party_nm_DF.createOrReplaceTempView("get_party_nm")

get_filing_dt_DF = spark.read \
    .jdbc(ptaburl, "("+get_filing_dt_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
get_filing_dt_DF.createOrReplaceTempView("get_filing_dt")


get_accorded_filing_dt_DF = spark.read \
    .jdbc(ptaburl, "("+get_accorded_filing_dt_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
get_accorded_filing_dt_DF.createOrReplaceTempView("get_accorded_filing_dt")


get_institution_decision_dt_DF = spark.read \
    .jdbc(ptaburl, "("+get_institution_decision_dt_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
get_institution_decision_dt_DF.createOrReplaceTempView("get_institution_decision_dt")


get_final_decision_dt_DF = spark.read \
    .jdbc(ptaburl, "("+get_final_decision_dt_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
get_final_decision_dt_DF.createOrReplaceTempView("get_final_decision_dt")

trial_query_DF=spark.sql(trial_query)
trial_query_DF.createOrReplaceTempView("trial_data")


log_id_df= spark.sql("select  nvl(max(joblogid),0)  from ptab.job_log  ")

log_id=log_id_df.collect()[0][0]
log_id=int(log_id)+1

master_id_df= spark.sql("select  nvl(max(jobid),0)  from ptab.job_master   ")

master_id=master_id_df.collect()[0][0]
master_id=int(master_id)+1

spark.sql("insert into ptab.cases select * from (select distinct "+ str(log_id) +" , a.* ,b.groupartunitnumber,b.techcenter,b.workgroup,current_timestamp,'etl',current_timestamp,'etl' from trial_data a left join bdr.appmdr b on b.patentapplicationnumber=a.application_no   ) tab ")


spark.sql(" insert into ptab.job_master select * from ( select '"+str(master_id)+"'  jobid,'load_trial_application' as jobnm ,current_timestamp as last_success_run_date,'success','trials dataload' ) tab ")

spark.sql(" insert into ptab.job_log select * from (select  '"+ str(log_id) +"' ,'"+ str(master_id) +"'  ,'load_trial_application' as jobnm ,'"+str(starttime)+"' ,current_timestamp,'success',"+str(trial_query_DF.count())+",'trials dataload') tab ")
