#!/bin/bash

########################################################################################

# This script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# export HADOOP_USER_NAME=hdfs
# ./extract_public_applications_from_palm.sh bdr-itwp-hdfs-4.dev.uspto.gov 
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values

#########################################################################################


PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-ptabapi'
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs/bdr-ptabapi'
RUNDATE=$(date +'%Y%m%d')
export HADOOP_USER_NAME=hdfs
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
mkdir -p $LOGPATH
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "Starting $JOB:" $(date +'%Y-%m-%d:%H:%M')

#/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-tqr' 'tqr_detail_metrics' 'started' $startdatetime
#/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=12g  --jars $EXTRAJARPATH/mysql.jar,/usr/hdp/2.6.1.0-129/zeppelin/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar  $CODEPATH/report.py $CODEPATH  $startdatetime
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=12g   --conf spark.executor.cores=2 --conf spark.executor.instances=2 $CODEPATH/trials_export_solr.py $CODEPATH  $startdatetime
#pyspark --jars $EXTRAJARPATH/bigsolr-0.1.jar $CODEPATH/solr_test.py $CODEPATH  $startdatetime

echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
