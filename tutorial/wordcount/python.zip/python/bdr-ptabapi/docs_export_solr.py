from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
from pyspark.sql.functions import udf, lit, unix_timestamp, from_unixtime
from pyspark.sql.functions import col
from datetime import date,datetime
import json, traceback, datetime, hashlib, sys
from functools import partial
import json, re
from pyspark.sql.functions import lit
import solr

import pandas as pd 
import numpy as np
from io import StringIO
import requests
import time
import json

def solrSchemaFromPandasAssist(dataFrame, uniqueIDcol, columnsForPartialAndTokenSearch = []):
    """
    Returns a string of xml schema based on the Pandas data frame data types.
    """    
    #Will we need to convert Pandas object type to strings? Probably
    
    #Test the uniqueID col uniqueness
    assert(len(dataFrame)==len(set(dataFrame[uniqueIDcol]))), "Unique ID column contains duplicates"

    dataFrameColumnsForRegularSchema = dataFrame.columns

    #Field strings and field types empty values
    fieldSet = set()
    fieldTypeSet = set()

    #If there are any string columns to search on 
    if(len(columnsForPartialAndTokenSearch)>0):

        #If there are searchable fields needed, then do not include them in the basic schema
        dataFrameColumnsForRegularSchema = [col for col in dataFrame.columns if col not in columnsForPartialAndTokenSearch]
        
        #dtypes are all string/object
        partialSearchDtypes = [dataFrame.dtypes[col] for col in columnsForPartialAndTokenSearch]
        assert(all(col == np.dtype('O') for col in partialSearchDtypes)), "Column field in list not of proper dtype"

        fieldTypeSet.add(searchableTextFieldDefinition()) #Adding the text field type with schema changes

        for textColName in columnsForPartialAndTokenSearch:
            fieldSet.add(fieldStringFromNameAndFieldType(textColName, "text"))

    solrPandasTypeMappings = numpyToSolrMappings()
    
    fieldTypeCommonNames = solrFieldTypeMappings()

    for colName in dataFrameColumnsForRegularSchema:
        if(colName!=uniqueIDcol):
            columnDtype = dataFrame.dtypes[colName]
            dtypeSolrType = solrPandasTypeMappings[columnDtype]

            #Field type strings
            fieldTypeString = fieldTypeStringCreator(dtypeSolrType)
            fieldTypeSet.add(fieldTypeString)

            #Field strings
            fieldTypeCommonName = fieldTypeCommonNames[dtypeSolrType]
            fieldString = fieldStringFromNameAndFieldType(colName, fieldTypeCommonName)
            fieldSet.add(fieldString)
            

    #always add a long and a string fieldType for the version and unique keys
    longFieldTypeString = fieldTypeStringCreator("solr.TrieLongField")
    fieldTypeSet.add(longFieldTypeString)
    stringFieldTypeString = fieldTypeStringCreator("solr.StrField")
    fieldTypeSet.add(stringFieldTypeString)
    
    uniqueKeyFieldString = uniqueKeyStringFromIDfield(uniqueIDcol)

    #Generating the field strings to add to the schema.xml file from a set of field names. There should be no duplicates, but this verifies
    fieldStrings = ""
    for fieldStr in fieldSet:
        fieldStrings = fieldStrings + fieldStr + "\n"
    
    #Generating the field type string to add to the whole schema.xml file from a set of field types(to avoid duplicates)
    fieldTypeStrings = ""
    for fieldTypeStr in fieldTypeSet:
        fieldTypeStrings = fieldTypeStrings + fieldTypeStr + "\n"
    
    #Inputting the base schema and piecing all the schema data together
    schemaFile = '<?xml version="1.0" encoding="UTF-8" ?>' + '\n\n' + \
        '<schema name="example" version="1.6">' + '\n\n' + \
        '<field name="_version_" type="long" indexed="true" stored="true" multiValued="false"/>' + '\n\n' + \
        uniqueKeyFieldString + '\n\n' + fieldStrings + '\n\n' + \
        fieldTypeStrings + '\n\n' + '</schema>'  

        
    return(schemaFile)


def numpyToSolrMappings():
    """
    Dictionary of type mappings from numpy data types to map to basic solr field types.
    """

    numpySolrTypeMappings = {
        np.dtype('int64'):"solr.TrieLongField",
        np.dtype('<M8[ns]'):"solr.TrieDateField",
        np.dtype('float64'):"solr.TrieDoubleField",
        np.dtype('O'):"solr.StrField",
        np.dtype('bool'):"solr.BoolField"
    }

    return(numpySolrTypeMappings)

def solrFieldTypeMappings():
    """
    Returns a mapping of a solar class of field types with 
    a common name for the types.
    """
    
    fieldTypeMappings = {
        "solr.TrieLongField":"long",
        "solr.TrieDateField":"date",
        "solr.TrieDoubleField":"float",
        "solr.StrField":"string",
        "solr.BoolField":"boolean"
    }
    
    return(fieldTypeMappings)

def solrToNumpyMappings():
    """
    Often multiple Solr types can map to a single numpy data type, this creates mapping for solr fieldTypes to
    numpy/pandas data types. 
    """

    numpySolrSpecialMappings = {
        "text":np.dtype('O'),
        "currency":np.dtype('float64'),
        "string":np.dtype('O'),
        "long":np.dtype('int64'),
        "float":np.dtype('float64'),
        "boolean":np.dtype('bool'),
        "date":np.dtype('<M8[ns]')
    }

    return(numpySolrSpecialMappings)

def numpyToStringMappings():
    """
    With the migration to Python 3, some of the astype changes are different. We can map the older Python 2 
    numpy dtypes with a string to match the dtypes. 
    """

    numpyDtypeStringMappings = {
        np.dtype('O'):'str',
        np.dtype('float64'):'float64',
        np.dtype('int64'):'int64',
        np.dtype('bool'):'bool',
        np.dtype('<M8[ns]'):'datetime64'
    }

    return(numpyDtypeStringMappings)

def uniqueKeyStringFromIDfield(uniqueIDfieldName):
    """
    Returns the unique key string for the Solr schema with 
    an input of the field name. The data type of the column 
    must be a string.
    """
    uniqueFieldString = '<field name="' + str(uniqueIDfieldName) + \
        '" type="string" indexed="true" stored="true" required="true" multiValued="false"/>' + '\n' + \
        '<uniqueKey>' + str(uniqueIDfieldName) + '</uniqueKey>' 
        
    return(uniqueFieldString)


def fieldStringFromNameAndFieldType(fieldName, fieldTypeCommonName):
    """
    Returns an xml field string for the solr schema, 
    using a field name(likely from a data frame) and 
    and a fieldType string.
    """
    
    fieldString = '<field name="' + fieldName + '" type="' + \
        fieldTypeCommonName + '" indexed="true" stored="true" multiValued="false"/>'  
        ##TODO: docValues="true", will need to create a map of field type common names to fields that can have doc values
        
    return(fieldString)


def fieldTypeStringCreator(solrTypeClass):
    """
    From a solr type class, build an xml fieldType string. 
    """
    
    fieldTypeMappings = solrFieldTypeMappings()   
    
    if(solrTypeClass=="solr.StrField" or solrTypeClass=="solr.BoolField"):
        fieldTypeString = '<fieldType name="' + fieldTypeMappings[solrTypeClass] + \
            '" class="' + solrTypeClass + '" sortMissingLast="true" />'
    else:        
        fieldTypeString = '<fieldType name="' + fieldTypeMappings[solrTypeClass] + \
            '" class="' + solrTypeClass + '" precisionStep="0" positionIncrementGap="0" />'
    
    return(fieldTypeString)


def searchableTextFieldDefinition():
    """
    Creating a searchable field fieldType definition. 
    """

    textFieldType = '<fieldType name="text" class="solr.TextField" omitNorms="false">' + '\n' + \
      ' <analyzer type="index">' + '\n' + \
        '  <tokenizer class="solr.StandardTokenizerFactory"/>' + '\n' + \
        '  <filter class="solr.StandardFilterFactory"/>' + '\n' + \
        '  <filter class="solr.LowerCaseFilterFactory"/>' + '\n' + \
        '  <filter class="solr.EdgeNGramFilterFactory" minGramSize="1" maxGramSize="15" />' + '\n' + \
      ' </analyzer>' + '\n' + \
      ' <analyzer type="query">' + '\n' + \
        '  <tokenizer class="solr.StandardTokenizerFactory"/>' + '\n' + \
        '  <filter class="solr.StandardFilterFactory"/>' + '\n' + \
        '  <filter class="solr.LowerCaseFilterFactory"/>' + '\n' + \
      ' </analyzer>' + '\n' + \
    '</fieldType>' + '\n' 

    return(textFieldType)

def stripWhiteSpaceReplNullInAllDFstringCols(dataFrame):
    """
    Returns data frame with all object columns without
    leading and trailing whitespace.
    """
    for colName in dataFrame.columns:
        columnDtype = dataFrame.dtypes[colName]
        if(columnDtype==np.dtype('O')):
            dataFrame[colName] = dataFrame[colName].map(lambda x: str(x).strip())
            dataFrame[colName] = dataFrame[colName].map(lambda x: 'nan' if (pd.isnull(x)==True or x=="") else x)
    
    return dataFrame


def replaceNaNinNumericColumn(dataFrame, replacementValue = -2):
    """
    Returns data frame with all the NaNs in numeric columns
    replaced with the standard Capital One database null value 
    of -2 or whatever is assigned.
    """
    for colName in dataFrame.columns:
        columnDtype = dataFrame.dtypes[colName]
        if(columnDtype==np.dtype('float64') or columnDtype==np.dtype('int64')):
            dataFrame[colName] = dataFrame[colName].map(lambda x: replacementValue if pd.isnull(x)==True else x)
    
    return dataFrame

def replaceNaTinDatetimeColumn(dataFrame):
    """
    For NaT values in datetime columns, replace them with 1900-01-01 datetime. 
    This is so that Solr does not throw an error for any unrecognized fields. 
    """
    for colName in dataFrame.columns:
        columnDtype = dataFrame.dtypes[colName]
        if(columnDtype==np.dtype('<M8[ns]')):
            dataFrame[colName] = dataFrame[colName].map(lambda x: pd.to_datetime("1900-01-01") if pd.isnull(x)==True else x)

    return dataFrame

def shuffleAccountNumber(acctNbr):
    """
    Returns an account number and shuffle the inner numbers to
    randomize the details a bit.
    """
    
    random.seed(4)
    
    acctNbrStr = str(acctNbr)
    midAcctNo = list(acctNbrStr[1:-1])
    random.shuffle(midAcctNo)
    shuffledAcctNo = acctNbrStr[0] + "".join(midAcctNo) + acctNbrStr[-1]
    
    return(shuffledAcctNo)

def insertDataFrameIntoSolrIndex(dataFrameToUpload, solrServerCollectionName, uploadSizeLimit=50000, proxies={}, printRows = True):
    """
    Uploads the data from a data frame into Solr. Inputs are the data frame to upload to Solr, 
    a collection name(url), optional upload size limit which is still limited to 100k, and 
    an optional proxy url. 
    """
    assert(uploadSizeLimit>3), "Upload size value too small"
    assert(uploadSizeLimit<=100000), "Upload size too big"

    if(solrServerCollectionName[-1]!="/"):
        solrServerCollectionName = solrServerCollectionName + "/"


    #Check if data frame types and schema match
    solrRepoSchema = obtainSolrSchema(solrServerCollectionName)
    checkIfSolrSchemaMatchesDataFrame(solrRepoSchema, dataFrameToUpload.dtypes)
    
    solrCSVpostReturn = ['test', 'test'] #dummy return values

    #requests headers and url for upload
    headers = {'content-type': 'application/csv', 'Accept-Charset': 'UTF-8'}
    updateUrl = solrServerCollectionName + "update?commit=true&overwrite=true"

    for uploadRange in range(0, len(dataFrameToUpload), uploadSizeLimit):
        csvOutput = StringIO()
        dataFrameToUpload[uploadRange:uploadRange+uploadSizeLimit].to_csv(csvOutput, 
                                                                          na_rep='nan',
                                                                          index=False, 
                                                                          date_format='%Y-%m-%dT%H:%M:%SZ')

        if(printRows==True):
            print(len(dataFrameToUpload[uploadRange:uploadRange+uploadSizeLimit]))
            
        csvString = csvOutput.getvalue()

        if(len(proxies)>0): 
            r = requests.post(updateUrl, data=csvString, headers=headers, proxies=proxies)
        else:
            r = requests.post(updateUrl, data=csvString, headers=headers)
        
        
        if(("error" in r.text)):
            print(r.text)
        
        time.sleep(1)
        
    #TODO:Make sure all fields have data in them after upload
    return(r.text)


def obtainSolrSchema(solrServerCollectionName, keepVersionCol=False):
    """
    Given a Solr server collection name(url), fetch the schema from that url and return 
    a dictionary mapping of column names to data types.
    """

    if(solrServerCollectionName[-1]!="/"):
        solrServerCollectionName = solrServerCollectionName + "/"

    headers = {'content-type': 'application/csv', 'Accept-Charset': 'UTF-8'}

    schemaUrl = solrServerCollectionName + "schema"

    r = requests.get(schemaUrl)

    solrSchema = r.text 
    solrSchemaMappings = json.loads(solrSchema)

    solrSchemaNameType = {}
    
    if(keepVersionCol==False):
        for rowSchema in solrSchemaMappings["schema"]["fields"]:
            if(rowSchema["name"]!="_version_"):
                solrSchemaNameType[rowSchema["name"]] = rowSchema["type"]
    else:
        for rowSchema in solrSchemaMappings["schema"]["fields"]:
            solrSchemaNameType[rowSchema["name"]] = rowSchema["type"]

    return(solrSchemaNameType)


def checkIfSolrSchemaMatchesDataFrame(schemaFromSolrRepo, dataFrameDtypes):
    """
    Using a dictionary with the column name to Solr fieldType mappings from an existing
    Solr repo and the dtypes from the data frame, which is to populate the given Solr 
    repo, this will ensure that the types are matching so as to not allow 
    """
    solrToNumpyTypes = solrToNumpyMappings()

    for colName,colType in schemaFromSolrRepo.items():
        numpyColumnTypeShouldHave = solrToNumpyTypes[colType]
        dataFrameColumnType = dataFrameDtypes[colName]
        assert(numpyColumnTypeShouldHave==dataFrameColumnType), "Data frame and Solr schema types need to match for: " + colName
        
    return(True)


def checkAndConvertDataFrameTypesAgainstPredefinedTemplate(standardSchemaDict, dataFrame):
    """
    To ensure a dataframe has a standardized schema assigned to it, the standard schema is 
    compared against the existing data frame dtypes. If any types are not matching they are 
    converted to the proper type. This should be useful in etl processes where multiple 
    dataframes are used to pull and upload data where type integrity is necessary.
    """
    
    assert(len(standardSchemaDict)==len(dataFrame.dtypes)), "The number of columns are not matching"
    
    assert(set(standardSchemaDict.keys())==set(dataFrame.columns)), "The column names are not matching"

    astypeStrings = numpyToStringMappings()
    
    for columnName in standardSchemaDict.keys():
        try: 
            standardTypeOfCol = standardSchemaDict[columnName]
            existingTypeOfCol = dataFrame.dtypes[columnName]
            
            if(standardTypeOfCol!=existingTypeOfCol):
                dataFrame[columnName] = dataFrame[columnName].astype(astypeStrings[standardTypeOfCol])

                #Check if converted properly
                afterConvTypeOfCol = dataFrame.dtypes[columnName]
                if(standardTypeOfCol==afterConvTypeOfCol):
                    print("Column that did not match was: ", columnName)
        except:
            print("Error in converting this column: ", columnName)
            
    return(dataFrame)


def statusChangeStartEndDates(statusDF):
    """
    In a large table which contains statuses for an account by day, what is often required is 
    an aggregate view where only the date that the account status(s) started and the date that
    they ended. This aggregates all the status change columns along with an account column
    by a given date column. 
    
    This will also require that all the columns are the status or account number columns except
    for the final column which sould be a date field.
    """
    assert(statusDF[[i for i in statusDF.columns][-1]].dtype == np.dtype('<M8[ns]')), "Last column note datetime"
    
    statusAcctColumns = [i for i in statusDF.columns][:-1]
    
    statusChangeNestedList = []
    statusChangeNewDFcols = statusAcctColumns + ["StartDate", "EndDate"]
    statusChangeNestedList.append(statusChangeNewDFcols)
    
    listStatusDF = statusDF.values.tolist()
    
    statusSetter = 0
    statusChangeRow = []
    
    for i in range(1, len(listStatusDF)):
        currentRow = listStatusDF[i]
        previousRow = listStatusDF[i-1]
        
        if(statusSetter==0):
            statusChangeRow = previousRow
        
        if(previousRow[:-1] == currentRow[:-1]):
            statusSetter += 1
        else:
            statusChangeRow = statusChangeRow + [previousRow[-1]]
            statusChangeNestedList.append(statusChangeRow)
            statusChangeRow = []
            statusSetter = 0
    
    sortedStatChange = pd.DataFrame(statusChangeNestedList[1:], columns = statusChangeNestedList[0])
    sortedStatChange = sortedStatChange.sort_values(by=[statusDF.columns[0], "StartDate"], ascending=[1,1])
        
    return(sortedStatChange)

def makeSureAllFieldsHaveValuesInSolrCollection(solrServerCollectionName):
    """
    A check to make sure that all the fields in Solr for every document 
    have data. This is to ensure that tables in the UI are properly populated.
    """
    #Obtain solr schema
    #loop through individual JSON rows to check if all schema fields have values

def createSchemaDescriptionsSchema(dataFrameWithColNameBusNameDesc, solrCollectionURL):
    """
    Create a schema from an input of column descriptions. Will also return a data frame with
    the type information for each column also included. 
    """
    assert([col for col in dataFrameWithColNameBusNameDesc.columns] == ["name", "description"]), \
        "Description headers not matching standard"

    collectionSchema = obtainSolrSchema(solrCollectionURL, True)
    collectionSchemaDF = pd.DataFrame.from_dict(collectionSchema, orient="index")
    collectionSchemaDF.columns = ["type"]
    collectionSchemaDF["name"] = collectionSchemaDF.index
    collectionSchemaType = pd.merge(collectionSchemaDF, dataFrameWithColNameBusNameDesc, 
        on="name", how="left")

    collectionSchemaType = stripWhiteSpaceReplNullInAllDFstringCols(collectionSchemaType)

    columnDescriptionSchema = solrSchemaFromPandasAssist(collectionSchemaType, "name")
    print(columnDescriptionSchema)

    return(collectionSchemaType)

import datetime
import json
import hashlib
import traceback
spark = SparkSession \
    .builder \
    .appName("Solr Test ") \
    .enableHiveSupport()\
    .getOrCreate()

hive = HiveContext(spark)
s = solr.SolrConnection('https://developer-fqt.etc.uspto.gov/solr/ptab-documents')
trialsDF=spark.sql("select objectuuid,casenumber,documentnumber,type,documentname,documenttitle,mediatype,sizeinbytes,filingdatetime,filingparty,sourcecreatedatetime,sourcecreateuserid,sourcelastmoddatetime,sourcelastmoduserid from ptab.documents   ")


trialsDF=trialsDF.select(col("objectuuid").alias("objectUuId"), col("casenumber").alias("trialNumber"), col("documentNumber").alias("documentNumber") ,col("type").alias("type"), col("documentName").alias("documentName"), col("documentTitle").alias("documentTitle")  
,col("mediaType").alias("mediaType"), col("sizeinBytes").alias("sizeinBytes"), col("filingdatetime").alias("filingDateTime")  
, col("filingparty").alias("filingParty") , col("sourcecreatedatetime").alias("sourcecreateDateTime"), col("sourceCreateuserid").alias("sourceCreateUserId") , col("sourceLastModDatetime").alias("sourceLastModDatetime") , col("sourceLastModUserId").alias("sourceLastModUserId") ) 

trialsDF = trialsDF.withColumn('filingdatetime', from_unixtime(timestamp=unix_timestamp(timestamp='filingdatetime' )))
trialsDF = trialsDF.withColumn('sourcecreatedatetime', from_unixtime(timestamp=unix_timestamp(timestamp='sourcecreatedatetime' )))
trialsDF = trialsDF.withColumn('sourcelastmoddatetime', from_unixtime(timestamp=unix_timestamp(timestamp='sourcelastmoddatetime' )))
pDf=trialsDF.toPandas() 
rdd_mapped = trialsDF.rdd.map(lambda y: y.asDict()) 
for index, row in pDf.iterrows():
    i=index
    s.add(json.dumps(rdd_mapped.take(i)))

s.commit()

spark.stop()
