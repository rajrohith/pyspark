from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-ptab.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

ptaburl = config.get('ptab','ptaburl')
userId = config.get('ptab','userId')
passwordVal = config.get('ptab','passwordVal')
TimeOut = config.get('ptab','TimeOut')
dbschema=config.get('ptab','ptabdbschema')
dataload_dt = config.get('ptab','dataload_dt')

spark = SparkSession \
    .builder \
    .appName("extract trials data") \
    .enableHiveSupport()\
    .getOrCreate()
import time
ts = time.time()	
import datetime
starttime = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

document_query1 = """  SELECT  pa.CONTENT_MANAGEMENT_ID CONTENT_MANAGEMENT_ID,pid.FK_PROCEEDING_ID FK_PROCEEDING_ID,p.PROCEEDING_ID PROCEEDING_ID,d.DOCUMENT_NO DOCUMENT_NO, 
 sdt.DOCUMENT_TYPE_NM DOCUMENT_TYPE_NM,  pa.FILE_NM FILE_NM, pa.ARTIFACT_NM ARTIFACT_NM,
 pa.FK_MIME_TYPE_ID FK_MIME_TYPE_ID, pa.FILE_SIZE_QT FILE_SIZE_QT,pid.FILING_DT FILING_DT, pas.FK_PROXY_SUBMITTER_ROLE_NM FK_PROXY_SUBMITTER_ROLE_NM,pa.FK_ARTIFACT_SUBMISSION_ID FK_ARTIFACT_SUBMISSION_ID, pa.PROCEEDING_ARTIFACT_ID PROCEEDING_ARTIFACT_ID, pa.FK_AVAILABILITY_CD FK_AVAILABILITY_CD, sdt.DOCUMENT_TYPE_ID DOCUMENT_TYPE_ID, pas.FK_SUBMISSION_STATUS_CD FK_SUBMISSION_STATUS_CD,pas.STATUS_DT STATUS_DT,pa.CREATE_TS CREATE_TS,NULL as SOURCE_CREATE_USER_ID, pa.LAST_MOD_TS LAST_MOD_TS,NULL as SOURCE_LAST_MOD_USER_ID  
  FROM """+dbschema+""".PROCEEDING p JOIN """+dbschema+""".ARTIFACT_SUBMISSION asb ON p.PROCEEDING_ID = asb.FK_PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT pa ON pa.FK_ARTIFACT_SUBMISSION_ID = asb.ARTIFACT_SUBMISSION_ID
        JOIN """+dbschema+""".DOCUMENT d ON d.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID
        JOIN """+dbschema+""".STND_DOCUMENT_TYPE sdt ON sdt.DOCUMENT_TYPE_ID = d.FK_DOCUMENT_TYPE_ID
        JOIN """+dbschema+""".PRCDNG_INVENTION_DISCLOSURE pid ON pid.FK_PROCEEDING_ID = p.PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT_STATUS pas ON pas.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID     
WHERE pa.FK_AVAILABILITY_CD = 'PUBLIC' 
 AND pas.FK_SUBMISSION_STATUS_CD = 'SUBMITTED'
AND pas.STATUS_DT IS NOT NULL 
 AND d.DOCUMENT_NO IS NOT NULL  """

exhibit_query = """  SELECT  pa.CONTENT_MANAGEMENT_ID  CONTENT_MANAGEMENT_ID,pid.FK_PROCEEDING_ID FK_PROCEEDING_ID,p.PROCEEDING_ID PROCEEDING_ID, e.EXHIBIT_NO DOCUMENT_NO, 
  'Exhibit' as DOCUMENT_TYPE_NM ,pa.FILE_NM FILE_NM, pa.ARTIFACT_NM ARTIFACT_NM,
 pa.FK_MIME_TYPE_ID FK_MIME_TYPE_ID, pa.FILE_SIZE_QT FILE_SIZE_QT,pid.FILING_DT FILING_DT, pas.FK_PROXY_SUBMITTER_ROLE_NM FK_PROXY_SUBMITTER_ROLE_NM,pa.FK_ARTIFACT_SUBMISSION_ID FK_ARTIFACT_SUBMISSION_ID, pa.PROCEEDING_ARTIFACT_ID PROCEEDING_ARTIFACT_ID, pa.FK_AVAILABILITY_CD FK_AVAILABILITY_CD,NULL as DOCUMENT_TYPE_ID, pas.FK_SUBMISSION_STATUS_CD FK_SUBMISSION_STATUS_CD,pas.STATUS_DT STATUS_DT,pa.CREATE_TS CREATE_TS,NULL as SOURCE_CREATE_USER_ID, pa.LAST_MOD_TS LAST_MOD_TS,NULL as SOURCE_LAST_MOD_USER_ID 
FROM """+dbschema+""".PROCEEDING p JOIN """+dbschema+""".ARTIFACT_SUBMISSION asb ON p.PROCEEDING_ID = asb.FK_PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT pa ON pa.FK_ARTIFACT_SUBMISSION_ID = asb.ARTIFACT_SUBMISSION_ID
        JOIN """+dbschema+""".EXHIBIT e ON (e.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID AND e.FK_PROCEEDING_ID = p.PROCEEDING_ID)
        JOIN """+dbschema+""".PRCDNG_INVENTION_DISCLOSURE pid ON pid.FK_PROCEEDING_ID = p.PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT_STATUS pas ON pas.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID
WHERE pa.FK_AVAILABILITY_CD = 'PUBLIC' 
 AND pas.FK_SUBMISSION_STATUS_CD = 'SUBMITTED'
 AND pas.STATUS_DT IS NOT NULL 
 AND e.EXHIBIT_NO IS NOT NULL    """
 
cntl_dt_df= spark.sql("select max(lastsuccessrunts) from ptab.job_master where jobnm = 'load_document_application'")
document_evnt_dt=str(cntl_dt_df.collect()[0][0])

if str(document_evnt_dt) =='None':
	document_query1 += """  AND ( trunc(pa.CREATE_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pa.LAST_MOD_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pas.STATUS_DT) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') ) """
	exhibit_query += """  AND ( trunc(pa.CREATE_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pa.LAST_MOD_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pas.STATUS_DT) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD')  ) """  

else:
    if str(document_evnt_dt).find('.')==-1:
	document_evnt_dt = str(document_evnt_dt)
    else:
        document_evnt_dt = document_evnt_dt[:str(document_evnt_dt).find('.')]
        document_query1 += """  AND ( trunc(pa.CREATE_TS) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS') OR  trunc(pa.LAST_MOD_TS) >=to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS')  OR  trunc(pas.STATUS_DT) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS')) """
	exhibit_query += """  AND ( trunc(pa.CREATE_TS) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS') OR  trunc(pa.LAST_MOD_TS) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS')  OR  trunc(pas.STATUS_DT) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS') ) """   
	

print 'document_query1 ' , document_query1 
document_1_DF = spark.read \
    .jdbc(ptaburl, "("+document_query1+")",properties={"user": userId, "password": passwordVal,  "connection_timeout": TimeOut})
document_1_DF.createOrReplaceTempView("document_data")

print 'exhibit_query ' , exhibit_query 
exhibit_data_DF = spark.read \
    .jdbc(ptaburl, "("+exhibit_query+")",properties={"user": userId, "password": passwordVal,  "connection_timeout": TimeOut})
exhibit_data_DF.createOrReplaceTempView("exhibit_data")


log_id_df= spark.sql("select  nvl(max(joblogid),0)  from ptab.job_log ")

log_id=log_id_df.collect()[0][0]
log_id=int(log_id)+1

master_id_df= spark.sql("select  nvl(max(jobid),0)  from ptab.job_master  ")

master_id=master_id_df.collect()[0][0]
master_id=int(master_id)+1

spark.sql(" insert into  ptab.documents select tab.*,c.groupartunitnumber,c.techcenternumber,c.workgroupnumber,current_timestamp createtimestamp,'etl' createuserid,current_timestamp modifiedtimestamp,'etl' modifieduserid from (select distinct "+ str(log_id) +",*  from document_data a  union select distinct "+ str(log_id) +",* from exhibit_data b ) tab  left join ptab.cases c on c.casenumber= tab.FK_PROCEEDING_ID ")


spark.sql(" insert into ptab.job_master select * from ( select '"+str(master_id)+"'  jobid,'load_document_application' as jobnm ,current_timestamp as last_success_run_date,'success','documents dataload' ) tab ")

spark.sql(" insert into ptab.job_log select * from (select  '"+ str(log_id) +"' ,'"+ str(master_id) +"'  ,'load_document_application' as jobnm ,'"+str(starttime)+"' ,current_timestamp,'success',"+str(document_1_DF.count())+",'documents dataload') tab ")

