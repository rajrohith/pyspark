from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext
from pyspark.sql.functions import udf, lit, unix_timestamp, from_unixtime
from pyspark.sql.functions import col
from datetime import date,datetime
import json, traceback, datetime, hashlib, sys
from functools import partial
import json, re
from pyspark.sql.functions import lit

import datetime
import json
import hashlib
import traceback
spark = SparkSession \
    .builder \
    .appName("load v_quality_review ") \
    .enableHiveSupport()\
    .getOrCreate()

hive = HiveContext(spark)


import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-ptab.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")



ES_nodes = config.get('ptab','ES_nodes')
ES_index = config.get('ptab','ES_index')
ES_type = config.get('ptab','ES_type')
ES_user = config.get('ptab','ES_user')
ES_pass = config.get('ptab','ES_pass')
#ES_port = config.get('ptab','ES_port')
dataload_dt = config.get('ptab','dataload_dt')

def get_id(row):
    import hashlib

    keys = str(row['jobid'])

    _id = hashlib.sha224(keys).hexdigest()

    return (_id, row)
'''
cntl_dt_df= hive.sql("select max(load_ts) from ptab.job_control where job_nm = 'ptab_report'")
review_evnt_dt=cntl_dt_df.collect()[0][0]
''' 
review_ins_query="select  * from ptab.job_master  "
review_ins_queryCnt="select  count(1) from ptab.job_master    "
'''
if str(review_evnt_dt) =='None':
    review_ins_query = review_ins_query
    review_ins_queryCnt = review_ins_queryCnt 
else:
    review_ins_query += " Where lastModifiedDateTime >   '"+str(review_evnt_dt)+"'" 
    review_ins_queryCnt += " Where lastModifiedDateTime >   '"+str(review_evnt_dt)+"'" 
'''
count_df= hive.sql(review_ins_queryCnt)
exportCnt=count_df.collect()[0][0]

spark.sql("USE PTAB")
loadDF=spark.sql(review_ins_query)
loadDF.printSchema()

#print loadDF.count(),"count of data"
loadDF.createOrReplaceTempView("quality_review_view")

cols = ['jobid','jobnm'  ,'lastsuccessrunts'  ,'statusct','commenttx']

#loadDF = loadDF.withColumn('lastsuccessrunts', (col("sourceEventDate").cast("string")))
#loadDF = loadDF.withColumn('assignedTs', (col("assignedTs").cast("string")))
#loadDF = loadDF.withColumn('completedTs', (col("completedTs").cast("string")))
#loadDF = loadDF.withColumn('reviewStatusTs', (col("reviewStatusTs").cast("string")))

#loadDF = loadDF.withColumn('sourceEventDate', from_unixtime(timestamp=unix_timestamp(timestamp='sourceEventDate' , format='yyyy-MM-dd'), format='yyyy-MM-dd'))
#loadDF = loadDF.withColumn('assignedTs', from_unixtime(timestamp=unix_timestamp(timestamp='assignedTs' , format='yyyy-MM-dd'), format='yyyy-MM-dd'))
#loadDF = loadDF.withColumn('completedTs', from_unixtime(timestamp=unix_timestamp(timestamp='completedTs' , format='yyyy-MM-dd'), format='yyyy-MM-dd'))
#loadDF = loadDF.withColumn('reviewStatusTs', from_unixtime(timestamp=unix_timestamp(timestamp='reviewStatusTs' , format='yyyy-MM-dd'), format='yyyy-MM-dd'))

loadDF = loadDF.withColumn('lastsuccessrunts', from_unixtime(timestamp=unix_timestamp(timestamp='lastsuccessrunts' )))

#loadDF = loadDF.withColumn('overall_exclnt_in', lit("true").cast("boolean"))

loadDF=loadDF.select(cols)


rdd_mapped = loadDF.rdd.map(lambda y: y.asDict()).map(get_id)

print(json.dumps(rdd_mapped.take(1))) 

#rdd_mapped = rdd_mapped.map(lambda y: y.asDict())
def package(doc ,pkeys=[]):
	import json
	import hashlib

	if type(doc) is tuple:
		doc = doc[1]
	_json = json.dumps(doc)
	keys = doc.keys()
	for key in keys:
		if doc[key] == 'null' or doc[key] == 'None':
			del doc[key]
		else:
			# If we have a datetime, strip off the time
			if key[-4:] == 'Date' and doc[key].find('T')-1:
				doc[key] = doc[key].split('T')[0]
	if not doc.has_key('id'):
		key = ""
		if len(pkeys) == 0:
			id = hashlib.sha224(_json).hexdigest()
			doc['id'] = id
		else:
			for _key in pkeys:
				if type(doc[_key]) is int:
					key += str(doc[_key])

				if type(doc[_key]) is str or type(doc[_key]) is unicode:
					key += str(doc[_key].encode('utf-8').decode('string_escape'))

			id = hashlib.sha224(key).hexdigest()
			doc['id'] = id
	else:
		id = doc['id']

	_json = json.dumps(doc)
	return (id, _json)

package_call = partial(package, pkeys=['jobid'])     
exportRDD = rdd_mapped.map(package_call)

print 'Exporting to Elastic Search'

try:
	exportRDD.saveAsNewAPIHadoopFile(
		path='-', 
		outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
		keyClass="org.apache.hadoop.io.NullWritable",  
		valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
		conf={ "es.resource" :   ES_index+'/'+ES_type , "es.mapping.id":"jobid","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
			"es.batch.write.retry.count":"20","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
			"es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port":"9200", "es.net.ssl":"true"})
	print 'Exported to Elastic Search'
except Exception as ex:
	print traceback.format_exc()
'''
hive.sql("insert into ptab.job_log select  'ptab_detail_metrics',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed',"+str(exportCnt)+",'no of records exported to elastic for ptab detail metrics'")
hive.sql(" insert into ptab.job_control select * from (select 'ptab_report' as job_name ,current_timestamp as loaded_dt ,current_timestamp,'etl',current_timestamp,'etl') tab ")
'''
spark.stop()
