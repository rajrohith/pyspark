from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-ptab.properties')

date = sys.argv[2]
date_new = date.replace("$"," ")

ptaburl = config.get('ptab','ptaburl')
userId = config.get('ptab','userId')
passwordVal = config.get('ptab','passwordVal')
TimeOut = config.get('ptab','TimeOut')
dbschema=config.get('ptab','ptabdbschema')
dataload_dt = config.get('ptab','dataload_dt')

spark = SparkSession \
    .builder \
    .appName("extract trials data") \
    .enableHiveSupport()\
    .getOrCreate()
import time
ts = time.time()	
import datetime
starttime = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

exhibit_query = """  SELECT  pa.CONTENT_MANAGEMENT_ID,pid.FK_PROCEEDING_ID, e.EXHIBIT_NO, 
  'Exhibit' as DOCUMENT_TYPE_NM ,pa.FILE_NM, pa.ARTIFACT_NM,
 pa.FK_MIME_TYPE_ID, pa.FILE_SIZE_QT,pid.FILING_DT, pas.FK_PROXY_SUBMITTER_ROLE_NM,pa.FK_ARTIFACT_SUBMISSION_ID, pa.PROCEEDING_ARTIFACT_ID, pa.FK_AVAILABILITY_CD,  pas.FK_SUBMISSION_STATUS_CD,pas.STATUS_DT ,pa.CREATE_TS,NULL as SOURCE_CREATE_USER_ID, pa.LAST_MOD_TS ,NULL as SOURCE_LAST_MOD_USER_ID 
FROM """+dbschema+""".PROCEEDING p JOIN """+dbschema+""".ARTIFACT_SUBMISSION asb ON p.PROCEEDING_ID = asb.FK_PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT pa ON pa.FK_ARTIFACT_SUBMISSION_ID = asb.ARTIFACT_SUBMISSION_ID
        JOIN """+dbschema+""".EXHIBIT e ON (e.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID AND e.FK_PROCEEDING_ID = p.PROCEEDING_ID)
        JOIN """+dbschema+""".PRCDNG_INVENTION_DISCLOSURE pid ON pid.FK_PROCEEDING_ID = p.PROCEEDING_ID
        JOIN """+dbschema+""".PROCEEDING_ARTIFACT_STATUS pas ON pas.FK_PROCEEDING_ARTIFACT_ID = pa.PROCEEDING_ARTIFACT_ID
WHERE pa.FK_AVAILABILITY_CD = 'PUBLIC' 
 AND pas.FK_SUBMISSION_STATUS_CD = 'SUBMITTED'
 AND pas.STATUS_DT IS NOT NULL 
 AND e.EXHIBIT_NO IS NOT NULL    """

 

cntl_dt_df= spark.sql("select max(lastsuccessrunts) from ptab.job_master where jobnm = 'load_exhibit_application'")
document_evnt_dt=str(cntl_dt_df.collect()[0][0])

if str(document_evnt_dt) =='None':
	exhibit_query += """  AND ( trunc(pa.CREATE_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pa.LAST_MOD_TS) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD') OR  trunc(pas.STATUS_DT) >= to_date("""+ str(dataload_dt)+ """, 'YYYY-MM-DD')  ) """  

else:
    if str(document_evnt_dt).find('.')==-1:
	document_evnt_dt = str(document_evnt_dt)
    else:
        document_evnt_dt = document_evnt_dt[:str(document_evnt_dt).find('.')]

	exhibit_query += """  AND ( trunc(pa.CREATE_TS) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS') OR  trunc(pa.LAST_MOD_TS) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS')  OR  trunc(pas.STATUS_DT) >= to_date('"""+ str(document_evnt_dt)+ """', 'YYYY-MM-DD HH24:MI:SS') ) """   
	

print 'exhibit_query ' , exhibit_query

exhibit_DF = spark.read \
    .jdbc(ptaburl, "("+exhibit_query+")",properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
exhibit_DF.createOrReplaceTempView("exhibit_data")



log_id_df= spark.sql("select  nvl(max(joblogid),0)  from ptab.job_log ")

log_id=log_id_df.collect()[0][0]
log_id=int(log_id)+1


master_id_df= spark.sql("select  nvl(max(jobid),0)  from ptab.job_master ")

master_id=master_id_df.collect()[0][0]
master_id=int(master_id)+1

spark.sql("insert into ptab.exhibit select * from (select distinct "+ str(log_id) +" , a.*,current_timestamp,'etl' from exhibit_data a  ) tab ")

spark.sql(" insert into ptab.job_master select * from ( select '"+str(master_id)+"'  jobid,'load_exhibit_application' as jobnm ,current_timestamp as last_success_run_date,'success','exhibit dataload' ) tab ")

spark.sql(" insert into ptab.job_log select * from ( select '"+ str(log_id) +"' ,'"+ str(master_id) +"' ,'load_exhibit_application' as jobnm ,'"+str(starttime)+"' ,current_timestamp,'success',"+str(exhibit_DF.count())+",'exhibit dataload') tab ")