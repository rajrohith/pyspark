 
from pyspark.sql import SparkSession
import sys
job_group = sys.argv[1]
job_name = sys.argv[2]
status = sys.argv[3]
date = sys.argv[4]
date_new = date.replace("$"," ")

spark = SparkSession.builder.appName("Job Log").enableHiveSupport().getOrCreate()
print(job_name + " " + status + " " + date_new )
log_id_df= spark.sql("select  nvl(max(joblogid),0)  from ptab.job_log ")

log_id=log_id_df.collect()[0][0]
log_id=int(log_id)+1

master_id_df= spark.sql("select  nvl(max(jobid),0)  from ptab.job_master  ")

master_id=master_id_df.collect()[0][0]
master_id=int(master_id)+1

spark.sql(" insert into ptab.job_master select * from ( select '"+str(master_id)+"' jobid,'"+job_name +"'  as jobnm,current_timestamp as last_success_run_date,'error','failed to load data' ) tab ")

spark.sql(" insert into ptab.job_log select * from ( select '"+ str(log_id) +"' ,'"+ str(master_id) +"' ,'"+job_name+"' as jobnm ,cast('"+date_new+"' as  timestamp) ,current_timestamp,'No of records loaded',0,'failed to load data') tab ")

spark.stop()