All python/shellscripts would be checked in here.

Get the data from PED:
1. sh get_from_ped.sh -> ped file (original)
2. sh clean_ped.sh -> ped file with JSONL

Get the data from CMS (metadata):
3. ./extract_appids_from_ped_jsonl.sh -> push the file to HDFS (ped_appids_xx.txt)
4. ./cms_metadata_initial.sh --> process the ped_appids_current_data.txt will download cms_metadata_currentdate.jsonl

Get the data from CMS (OA XML):
5. ./extract_appids_ifws_from_cms_metadata.sh -> push the the cms_metadata_appids_ifws_currentdate.txt
6. ./cms_oa_initial.sh -->cms_oa_xx.jsonl, cms_oaxml_currentdate.jsonl and cms_oaxml_appids_ifws_currentdate.txt

Get the data from PALM:

