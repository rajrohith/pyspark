"""
Run this to prepare data (i.e. train the model) used in scoring algorithms; this can be run on a sporadic scheduler
"""
import pyspark
from pyspark.sql import SparkSession
import os
import json
import sys
from collections import Counter
from ConfigParser import SafeConfigParser
import findspark
from generate_pca_data import run_resilient_pca_data_generation
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# create a file handler
handler = logging.FileHandler('data_prep.log')
handler.setLevel(logging.DEBUG)
# create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
# add the handlers to the logger
logger.addHandler(handler)

config_path = 'bdr-txn-score-analytics-2.properties'

parser = SafeConfigParser()
parser.read(config_path)
env_type = parser.get("global_config", 'env_type')
if env_type == 'PROD':
    config_settings = 'dataprep_config_prod'
    run_prod_cmd = True
else:
    print "running dev"
    config_settings = 'dataprep_config_dev'
    run_prod_cmd = False


findspark.init(spark_home=parser.get(config_settings, 'findspark_init'))
#conf = pyspark.SparkConf().setAppName(parser.get(config_settings, 'app_name'))
#sc = pyspark.SparkContext(conf=conf).getOrCreate()

spark = SparkSession.builder.appName(parser.get(config_settings, 'app_name')).getOrCreate()

save_dir = parser.get(config_settings, 'save_dir')


def to_unix(date):
    import time
    return int(time.mktime(time.strptime(date, '%Y-%m-%d')))


def save_rdd(rdd, path, save_to_dir=save_dir):
    path = save_to_dir + path
    if run_prod_cmd:
        os.system('hdfs dfs -rm -f -R {}'.format(path))
    rdd.saveAsTextFile(path)


def get_transitions(history):
    from collections import Counter
    L = len(history)
    return Counter([(history[i], history[i+1]) for i in range(L-1)])


if len(sys.argv) == 1:
    """ pass in any argument from shell to skip this set of the data processing """
    palm = spark.sparkContext.textFile(parser.get(config_settings, 'palm')).map(lambda x: eval(x))

    """ note: "path" means code history """
    palm_paths_with_time = \
        palm.map(lambda x: (x['APPL_ID'], [(str(x['APP_STATUS_NO']), to_unix(x['APP_STATUS_DT'][:10]))]))
    palm_paths = \
        palm_paths_with_time.reduceByKey(lambda x,y: x+y).map(lambda x: (x[0], sorted(x[1], key=lambda u: u[1])))
    palm_status_paths = palm_paths.map(lambda x: (x[0], tuple([y[0] for y in x[1]]))) 
    palm_apps = spark.sparkContext.textFile(parser.get(config_settings, 'palm_apps')).map(lambda x: json.loads(x))
    art_class_public = palm_apps.map(lambda x: (str(x['APPL_ID']), str(x.get('DN_PTO_ART_CLASS_NO', '   '))))

    """ palm_status_paths_with_art_class: ((art class, appid), history) """
    palm_status_paths_with_art_class = palm_status_paths.join(art_class_public).map(lambda x: ((x[1][1], x[0]), x[1][0])) 
    save_rdd(palm_status_paths_with_art_class, 'palm_status_paths_with_art_class')
    logger.info('Done with palm_status_paths_with_art_class')

    """ palm_status_count_paths_by_art_class: (art class, {history:count}) """
    palm_status_count_paths_by_art_class = \
        palm_status_paths_with_art_class.map(lambda x: (x[0][0], Counter([x[1]]))).reduceByKey(lambda x, y: x+y).map(lambda x: (x[0], dict(x[1].items())))
    save_rdd(palm_status_count_paths_by_art_class, 'palm_status_count_paths_by_art_class')
    logger.info('Done with palm_status_count_paths_by_art_class')

    """ transitions_counter_by_art_class: (art class, {event:count}), where "event" means pair of consecutive codes """
    transitions_counter_by_art_class = \
        palm_status_paths_with_art_class.map(lambda x: (x[0][0], get_transitions(x[1]))).reduceByKey(lambda x,y: x+y).map(lambda x: (x[0], dict(x[1].items())))
    save_rdd(transitions_counter_by_art_class, 'transitions_counter_by_art_class')
    logger.info('Done with palm_status_paths_with_art_class')

    """ transitions_counter: {event:count}, where "event" means pair of consecutive codes """
    transitions_counter = palm_status_paths_with_art_class.map(lambda x: Counter([x[1]])).reduce(lambda x,y: x+y)
    transitions_counter = spark.sparkContext.parallelize(transitions_counter.items())
    save_rdd(transitions_counter, 'transitions_counter')
    logger.info('Done with transitions_counter')

    palm_status_paths_mass_by_art_class = \
        palm_status_count_paths_by_art_class.flatMap(lambda x: [((x[0], v), [k]) for k, v in x[1].items()]).reduceByKey(lambda x,y: x+y).map(lambda x: (x[0][0], Counter({tuple(x[1]): x[0][1]*len(x[1])}))).map(lambda x: (x[0], dict(x[1].items())))
    save_rdd(palm_status_paths_mass_by_art_class, 'palm_status_paths_mass_by_art_class')
    logger.info('Done with palm_status_paths_mass_by_art_class')

if run_prod_cmd:
    os.system('cp pca_data.txt pca_data_backup.txt')
    os.system('rm -f pca_data.txt')
else:
    os.system('copy pca_data.txt pca_data_backup.txt')
    os.system('del pca_data.txt')

# As of 9/15/2017 this for loop does not complete due to infrastructure issues
# As of 9/19/2017 it does now - Al Krinker
#
#                          oooo$$$$$$$$$$$$oooo
#                       oo$$$$$$$$$$$$$$$$$$$$$$$$o
#                    oo$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o         o$   $$ o$
#    o $ oo        o$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o       $$ $$ $$o$
# oo $ $ "$      o$$$$$$$$$    $$$$$$$$$$$$$    $$$$$$$$$o       $$$o$$o$
# "$$$$$$o$     o$$$$$$$$$      $$$$$$$$$$$      $$$$$$$$$$o    $$$$$$$$
#   $$$$$$$    $$$$$$$$$$$      $$$$$$$$$$$      $$$$$$$$$$$$$$$$$$$$$$$
#   $$$$$$$$$$$$$$$$$$$$$$$    $$$$$$$$$$$$$    $$$$$$$$$$$$$$  """$$$
#    "$$$""""$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     "$$$
#     $$$   o$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     "$$$o
#    o$$"   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$       $$$o
#    $$$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$" "$$$$$$ooooo$$$$o
#   o$$$oooo$$$$$  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$   o$$$$$$$$$$$$$$$$$
#   $$$$$$$$"$$$$   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$     $$$$""""""""
#  """"       $$$$    "$$$$$$$$$$$$$$$$$$$$$$$$$$$$"      o$$$
#             "$$$o     """$$$$$$$$$$$$$$$$$$"$$"         $$$
#               $$$o          "$$""$$$$$$""""           o$$$
#                $$$$o                                o$$$"
#                 "$$$$o      o$$$$$$o"$$$$o        o$$$$
#                   "$$$$$oo     ""$$$$o$$$$$o   o$$$$""
#                      ""$$$$$oooo  "$$$o$$$$$$$$$"""
#                         ""$$$$$$$oo $$$$$$$$$$
#                                 """"$$$$$$$$$$$
#                                     $$$$$$$$$$$$
#                                      $$$$$$$$$$"
#                                       "$$$""
#
run_resilient_pca_data_generation(spark)


if run_prod_cmd:
    os.system('hdfs dfs -mkdir ' + parser.get(config_settings, 'pca_data_dir'))
    os.system('hdfs dfs -copyFromLocal -f pca_data.txt ' + parser.get(config_settings, 'pca_data_dir') + 'pca_data.txt')
else:
    os.system('copy pca_data.txt ' + parser.get(config_settings, 'pca_data_dir') + 'pca_data.txt')
