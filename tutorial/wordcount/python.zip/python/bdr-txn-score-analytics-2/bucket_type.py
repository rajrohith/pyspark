threshold = {}
threshold[0] = (75, 90)
threshold[1] = (75, 90)
threshold[2] = (75, 90)
threshold[3] = (50, 75)


def get_color(i, score):
    if score is None:
        return None
    elif score < threshold[i][0]:
        return 'green'
    elif score < threshold[i][1]:
        return 'yellow'
    else:
        return 'red'


def colors(scores):
    return [get_color(i, scores[i]) for i in range(4)]

def get_agg_color(score):
    if score is None:
        return None
    elif score < threshold[0][0]:
        return 'green'
    elif score < threshold[0][1]:
        return 'yellow'
    else:
        return 'red'