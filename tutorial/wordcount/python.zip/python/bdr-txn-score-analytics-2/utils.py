from lookup import USPC_CODES
from copy import copy


def clean_dict(D):
    for C in D.keys():
        if C not in USPC_CODES:
            D.pop(C)
    return D


def sum_squares(vector, weights=None, cutoff=50, reverse=False, n=None):
    """ weighted sum of squares starting from beginning of vector til the last weight index
    if reverse=True, we reverse vector indices
    there is a cutoff=50 for each term of the sum """
    if not n:
        n = len(vector)
    if not weights:
        weights = [1] * n
    if reverse:
        try:
            vector = vector.toArray().tolist()
            vector.reverse()
        except:
            vector = copy(vector)
            vector.tolist().reverse()
    return sum([min(weights[i] * x ** 2, cutoff) for i, x in enumerate(vector[:len(weights)])])


def up_to_half_var(exp_var):
    """ returns index n of the highest principal component needed to achieve at least half the variance; n+1 = dof """
    total = 0
    for (i, x) in enumerate(exp_var):
        total += x
        if total >= 0.5 or x < .01:
            break
    return i


def last_ten_p_var(exp_var):
    total = 0
    reversed = exp_var
    reversed.reverse()
    for (i, x) in enumerate(reversed):
        total += x
        if total > 0.10:
            break
    return i