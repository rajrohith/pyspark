from ConfigParser import SafeConfigParser
import json
import findspark
import pyspark
from pyspark.sql import SparkSession

config_path = '/environment/production/model_appl_txn_score_analytics.properties'

parser = SafeConfigParser()
parser.read(config_path)
env_type = parser.get("global_config", 'env_type')
if env_type == 'PROD':
    config_settings = 'validate_score_config_prod'
    run_prod_cmd = True
else:
    print "running dev"
    config_settings = 'validate_score_config_dev'
    run_prod_cmd = False

findspark.init(spark_home=parser.get(config_settings, 'findspark_init'))
conf = pyspark.SparkConf().setAppName(parser.get(config_settings, 'app_name'))
conf.setMaster('local[*]')
#sc = pyspark.SparkContext(conf=conf).getOrCreate()
spark = SparkSession.builder.appName(parser.get(config_settings, 'app_name')).getOrCreate()

save_dir = parser.get(config_settings, 'save_dir')


def eval_json(x):
    return json.loads(x)


def low_scores(data, lo, hi, n, mode):
    top_scores(data, lo, hi, n, mode, order=True)


def top_scores(data, lo, hi, n, mode, order=False):
    """
    lo = cutoff for low score
    hi = cutoff for high score
    n = number of samples to return
    mode = 1,2,3,4 means we return n app ids whose score1, score2, score3, or score4 satisfy lo <= score <= hi;
    mode = 'all' means we return n app ids where all of the four scores lies in [lo, hi]
    mode = 'any' means we return n app ids where any of the four scores lies in [lo, hi]
    mode = 'avg' means we return n app ids where the average score lies in [lo, hi]

    Note: score2 and score4 tend to be on the low side. By default, score2 will score a history as 50 if it has not
    seen it before.
    """
    if mode == 'all':
        scores_list = data.filter(lambda x: all([lo <= x['score{}'.format(i)] <= hi for i in (1, 2, 3, 4)])).\
                           take(n)
    elif mode == 'any':
        scores_list = data.filter(lambda x: any([lo <= x['score{}'.format(i)] <= hi for i in (1, 2, 3, 4)])).\
                           take(n)
    elif mode == 'avg':
        scores_list = data.filter(lambda x: lo <= sum([x['score{}'.format(i)] for i in (1, 2, 3, 4)])/float(4) <= hi).\
                           take(n)
    elif mode in [1, 2, 3, 4]:
        scores_list = data.filter(lambda x: lo <= x['score{}'.format(mode)] <= hi).\
                           sortBy(lambda x: x['score{}'.format(mode)], ascending=order).\
                           take(n)
    else:
        print 'Invalid Mode'
        return None
    print 'lo:', lo, 'hi:', hi, 'mode:', mode
    print '-------------'
    for item in scores_list:
        scores = tuple([item['score{}'.format(i)] for i in (1, 2, 3, 4)])
        if mode in [1, 2, 3, 4]:
            print 'appid:', item['appid'], 'score:', scores[mode-1], '[ all scores:', scores, 'avg:', \
                  sum(scores)/float(4), ']'
        else:
            print 'appid:', item['appid'], 'scores:', scores, 'avg:', sum(scores) / float(4)
    print '============='

scores = spark.sparkContext.textFile(save_dir + 'output').\
         map(lambda x: eval_json(x)).\
         filter(lambda x: all([x['score{}'.format(i)] is not None for i in (1, 2, 3, 4)]))

top_scores(scores, 1, 100, 5, mode='all')
top_scores(scores, 90, 100, 5, mode='any')
top_scores(scores, 50, 100, 5, mode='avg')
top_scores(scores, 90, 100, 5, mode=1)
top_scores(scores, 50, 100, 5, mode=2)
top_scores(scores, 90, 100, 5, mode=3)
top_scores(scores, 80, 100, 5, mode=4)
