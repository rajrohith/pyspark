# script submits Two PySpark jobs to the BDR Spark Cluster using spark-submit
#
# Usage is as follows
# 1. export HADOOP_USER_NAME=hdfs
# 2. export SPARK_MAJOR_VERSION=2
# 3. data_prep.py - excecuted within model_appl_txn_score_analytics_2.sh
# 4. score.py - excecuted as step 2 within model_appl_txn_score_analytics_2.sh
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values
#
#########################################################################################
#
PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='./'
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs'
SPARK_SERVER=bdr-itwv-spark-1.dev.uspto.gov
HADOOP_USER_NAME=hdfs
#SPARK_MAJOR_VERSION=2
#
#exec >$LOGPATH/$JOB.$RUNDATE.log
#exec 2>&1
echo "Starting Data_Prep: " $(date +'%Y-%m-%d:%H:%M')
#
/usr/hdp/current/spark2-client/bin/spark-submit data_prep.py 
#
#if [ $? -ne 0 ]; then
#  echo "$Data_Prep Python script failed"
#  exit 1
#fi
echo "Completed  Data_Prep:" $(date +'%Y-%m-%d:%H:%M')
#
#exec >$LOGPATH/$JOB.$RUNDATE.log
#exec 2>&1
echo "Starting Data_Scoring: "  $(date +'%Y-%m-%d:%H:%M')
#
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars /data/workspace/trx/code_whs/ojdbc8.jar,/data/workspace/trx/code_whs/elasticsearch-hadoop-5.6.2/dist/elasticsearch-hadoop-5.6.2.jar --conf spark.executor.memory=30g  --conf spark.driver.memory=12g  --conf spark.executor.instances=4 --conf spark.executor.cores=5 --conf spark.yarn.executor.memoryoverhead=50g --conf spark.yarn.queue=default score.py 

#if [ $? -ne 0 ]; then
#  echo "Data_Scoring Python script failed"
#  exit 1
#fi
#echo "Completed $job2:" $(date +'%Y-%m-%d:%H:%M')