from pyspark.mllib.feature import StandardScaler
from pyspark.ml.feature import PCA as PCA
from utils import clean_dict, sum_squares, up_to_half_var, last_ten_p_var
from math import log
from copy import copy
from collections import Counter
from scipy.stats import norm
import findspark
import pyspark
from pyspark.sql import SparkSession
from ConfigParser import SafeConfigParser
import os.path
import logging


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# create a file handler
handler = logging.FileHandler('generate_pca_data.log')
handler.setLevel(logging.DEBUG)
# create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
# add the handlers to the logger
logger.addHandler(handler)

config_path = 'bdr-txn-score-analytics-2.properties'

parser = SafeConfigParser()
parser.read(config_path)
env_type = parser.get("global_config", 'env_type')

if env_type == 'PROD':
    config_settings = 'generate_pca_data_config_prod'
    run_prod_cmd = True
else:
    print "running dev"
    config_settings = 'generate_pca_data_config_dev'
    run_prod_cmd = False

errors_file = 'pca_data_generation_errors'
save_dir = parser.get(config_settings, 'save_dir')


def run_resilient_pca_data_generation(spark):
    logger.info("Starting pca data generation job...")
    paths_by_art_class_dict = clean_dict(
        spark.sparkContext.textFile(save_dir + 'palm_status_count_paths_by_art_class/').map(lambda x: eval(x)).collectAsMap())

    keys = sorted(paths_by_art_class_dict.keys())

    run_pca_data_generation(paths_by_art_class_dict, keys, spark)

    # now check if we have any errors
    while True:
        if os.path.isfile(errors_file):
            with open(errors_file, 'r+') as file:
                keys = [line.strip() for line in file]
                if not keys:
                    break
                file.seek(0)
                file.truncate(0)
            logger.warn("Processing following failed keys: ")
            logger.warn(keys)
            run_pca_data_generation(paths_by_art_class_dict, keys, spark)
        else:
            break

    print "finished generation of pca data"
    logger.info("Finishing pca data generation job...")


def run_pca_data_generation(paths_by_art_class_dict, keys, spark):
        for C in keys:
            try:
                if len(paths_by_art_class_dict[C]) > 1:
                    print('Processing {}...'.format(C))
                    logger.info('Processing %s...', C)

                    std_features, codes = counter_to_features(paths_by_art_class_dict[C], spark)
                    pc_matrix, exp_var, pc_data = PCA_model(std_features, len(codes))
                    scores = get_scores(pc_data.rdd, exp_var)
                    mu, s = fit_norm(scores)
                    # Standard deviations should be positive value
                    if s == 0:
                        s = 0.000001
                    scores_tail = get_scores(pc_data.rdd, exp_var, reverse=True)
                    mu_tail, s_tail = fit_norm(scores_tail)
                    if s_tail == 0:
                        s_tail = 0.000001
                    item = (C, {'codes': codes, 'pc_matrix': pc_matrix, 'exp_var': exp_var, 'norm_params': (mu, s),
                                'norm_params_tail': (mu_tail, s_tail)})
                    with open('pca_data.txt', 'a+') as f:
                        f.write(str(item) + '\n')
            except:
                logger.error('Processing of %s has failed!', C)
                logger.error("Error message", exc_info=True)
                with open(errors_file, 'a+') as f:
                    f.write(C + '\n')
                continue


def counter_to_codes(path_counter):
    """ given a path counter within an art class, return set of codes that occur """
    codes = set([c for path in path_counter for c in path])
    codes.discard('')
    return sorted(list(codes), key=lambda x: int(x))


def counter_to_features(counter, spark):
    from pyspark.ml.linalg import Vectors
    codes = counter_to_codes(counter)

    """ restricts dictionary to just codes that occur in counter passed in a list of lists, each list being a Counter 
    repeated v times; the Counter converts a path to a dictionary (to be vectorized)"""
    codes_one_hot = {i: codes[i] for i in range(len(codes))}

    lists_of_vectors = [[vectorize(Counter(k), codes_one_hot)] * v for k, v in counter.items()]
    vectors = [v for sublist in lists_of_vectors for v in sublist]
    features = spark.sparkContext.parallelize(vectors)
    model = StandardScaler(withMean=True, withStd=True).fit(features)
    std_features = model.transform(features)

    """ go from mllib vectors to ml vectors """
    return std_features.map(lambda x: Vectors.dense(x.toArray())), codes


def PCA_model(rdd, num_comp):
    """ each row of the rdd is a dense Vector object """
    df = rdd.map(lambda x: (x,)).toDF(['features'])
    pca = PCA(k=num_comp, inputCol="features", outputCol="pca_features")
    model = pca.fit(df)
    exp_var = model.explainedVariance.toArray().tolist()
    pc_matrix = model.pc.toArray().tolist()
    """ apply this to a df with app ids """
    df_pca = model.transform(df)
    return pc_matrix, exp_var, df_pca


def vectorize(counter, codes_one_hot):
    from pyspark.mllib.linalg import Vectors
    return Vectors.dense([counter.get(codes_one_hot[i], 0) for i in range(len(codes_one_hot))])


def get_scores(pc_rdd, exp_var, reverse=False):
    total_var = len(exp_var)
    if not reverse:
        n = up_to_half_var(exp_var) + 1
        """ define weights so that sum of squares is properly normalized, but we cap the weight at 10 """
        weights = [1 / max(float(x * total_var), 0.1) for x in exp_var[:n]]
        sum_squares_rdd = pc_rdd.map(lambda x: sum_squares(x['pca_features'], weights=weights))
        scores = [log(x) for x in sorted(sum_squares_rdd.collect())]
        return scores
    if reverse:
        n = last_ten_p_var(exp_var) + 1
        exp_var = copy(exp_var)
        exp_var.reverse()
        num_zeros = len(filter(lambda x: x == 0, exp_var))

        """ weights going from least pc to the first pc that yields explained variance greater than 0.1 """
        weights = [0] * num_zeros + [1 / max(float(x * total_var), 0.1) for x in exp_var[:n]]
        sum_squares_rdd = pc_rdd.map(lambda x: sum_squares(x['pca_features'], weights=weights, reverse=reverse))
        scores = [log(x) for x in sorted(sum_squares_rdd.collect())]
        return scores


def fit_norm(data):
    """ data is a list of scores """
    mu, s = norm.fit(data)
    return mu, s



