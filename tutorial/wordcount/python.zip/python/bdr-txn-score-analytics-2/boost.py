"""
    Run to modify boost parameters that are used by score.py;
    the default boost for all algorithms and art classes is 0;
    a positive boost increases the corresponding score, while a negative boost decreases it.
"""

import os
import sys
from ConfigParser import SafeConfigParser
from lookup import USPC_CODES

config_path = '/bdr-txn-score-analytics-2.properties'
parser = SafeConfigParser()
parser.read(config_path)

env_type = parser.get("global_config", 'env_type')

if env_type == 'PROD':
    config_settings = 'boost_config_prod'
    run_prod_cmd = True
else:
    print "running dev"
    config_settings = 'boost_config_dev'
    run_prod_cmd = False

local_file = parser.get(config_settings, 'local_file')
boost_file = parser.get(config_settings, 'boost_dir') + parser.get(config_settings, 'boost_file')
boost_dir = parser.get(config_settings, 'boost_dir')

if len(sys.argv) == 1:
    new_boost_dicts = {i: {} for i in [1, 2, 3, 4]}
    for i in [1, 2, 3, 4]:
        new_boost_dicts[i] = {}

    while True:
        while True:
            num = int(raw_input('Enter the algorithm number (1-4) you would like to boost: '))
            if num not in [1, 2, 3, 4]:
                print 'Error. Invalid algorithm number. Please try again.'
            else:
                break

        while True:
            C = raw_input('Enter the art class (uspc code) you would like to update: ')
            if C not in USPC_CODES:
                print 'Error. Invalid uspc code. Please try again.'
            else:
                break
                
        boost = input('Enter any real number to boost art class {} for algorithm {}: '.format(C, num))

        new_boost_dicts[num][C] = boost
        
        s = raw_input('Would you like to enter another boost? (Y to continue) ')
        if s in ['Y', 'y']:
            continue
        else:
            try:
                with open(local_file, 'r') as f:
                    boost_dicts = eval(f.read())
            except:
                boost_dicts = {i: {C: 0 for C in USPC_CODES} for i in [1, 2, 3, 4]}
            for i in [1, 2, 3, 4]:
                boost_dicts[i].update(new_boost_dicts[i])
            with open(local_file, 'w') as f:
                f.write(str(boost_dicts))
            break

elif sys.argv[1] == 'initialize':
    boost_dicts = {i: {C: 0 for C in USPC_CODES} for i in [1, 2, 3, 4]}
    with open(local_file, 'w+') as f:
        f.write(str(boost_dicts))

if run_prod_cmd:
    os.system('hdfs dfs -mkdir {}'.format(boost_dir))
    os.system('hdfs dfs -copyFromLocal -f {} {}'.format(local_file, boost_file))
else:
    os.system('copy {} {}'.format(local_file, boost_file))
