import findspark
import pyspark
from pyspark.sql import SparkSession, HiveContext
from ConfigParser import SafeConfigParser
import palm_algorithms
import bucket_type
import lookup
import utils
import json
import hashlib
import os
from utils import clean_dict
import numpy as np
from pyspark.sql.functions import udf, format_number, unix_timestamp, from_unixtime
from pyspark.sql.types import StructType, StructField, IntegerType, StringType



config_path = 'bdr-txn-score-analytics-2.properties'

parser = SafeConfigParser()
parser.read(config_path)
env_type = parser.get("global_config", 'env_type')
if env_type == 'PROD':
    config_settings = 'score_config_prod'
    run_prod_cmd = True
else:
    print "running dev"
    config_settings = 'score_config_dev'
    run_prod_cmd = False

findspark.init(spark_home=parser.get(config_settings, 'findspark_init'))
conf = pyspark.SparkConf().setAppName(parser.get(config_settings, 'app_name'))
#conf.setMaster('local[*]')
#sc = pyspark.SparkContext(conf=conf, pyFiles=['./palm_algorithms.py','./bucket_type.py','./utils.py','./lookup.py']).getOrCreate()
spark = SparkSession.builder.appName(parser.get(config_settings, 'app_name')).enableHiveSupport().getOrCreate()
hive = HiveContext(spark)
save_dir = parser.get(config_settings, 'save_dir')

ES_nodes = parser.get(config_settings, 'ES_nodes')
HIVE_table_2 = parser.get(config_settings, 'HIVE_table')
txn_ES_index_2 = parser.get(config_settings, 'txn_ES_index')
txn_ES_type_2 = parser.get(config_settings, 'txn_ES_type')

data = spark.sparkContext.textFile(save_dir+'palm_status_paths_with_art_class/').map(lambda x: eval(x))
boost_dict = spark.sparkContext.textFile(parser.get(config_settings, 'boost_dir')+'boost.txt').map(lambda x: eval(x)).first()


def process_data():
    file1_1 = save_dir + 'transitions_counter_by_art_class'
    file1_2 = save_dir + 'transitions_counter'
    file2 = save_dir + 'palm_status_paths_mass_by_art_class'
    file3 = parser.get(config_settings, 'pca_data_dir')

    transitions_counter_by_art_class = clean_dict(spark.sparkContext.textFile(file1_1).map(lambda x: eval(x)).collectAsMap())
    transitions_counter = spark.sparkContext.textFile(file1_2).map(lambda x: eval(x)).collectAsMap()

    def make_percentiles(D, base_value=0, boost=0):
        total = float(sum(D.values()))
        factor = float(2 ** boost)
        if len(D) > 0:
            """ if factor=1 and base_value=0, this would be infrequency percentile """
            return {k: int(100 * (sum([x for x in D.values() if x > v / factor]) + base_value) / (total + base_value)) for
                    k, v in D.items()}
        else:
            return {}

    def remove_keys(D, filter_out):
        return {k: D[k] for k in D.keys() if k not in filter_out}

    def sort_dict(D, reverse=True):
        """ returns list of (key,value) sorted by value in descending order (if reverse=True) """
        return sorted(D.items(), key=lambda x: x[1], reverse=reverse)
        
    def make_percentile_dict(counter, filter_out, boost_dict_fixed_alg, scale):
        D = {}
        for C in counter:
            """ scale down number events in self.filter_out by a factor of scale """
            base_value = sum([counter[C].get(k, 0) for k in filter_out]) / float(scale)
            D[C] = make_percentiles(remove_keys(counter[C], filter_out),
                                    base_value=base_value, boost=boost_dict_fixed_alg.get(C, 0))
        return D

    filter_out = sort_dict(transitions_counter)[:34]
    score1_percentile_dict = make_percentile_dict(transitions_counter_by_art_class, filter_out=filter_out,
                                                  boost_dict_fixed_alg=boost_dict[1], scale=15)
    score1_data = [score1_percentile_dict, filter_out]

    score2_masses = clean_dict(spark.sparkContext.textFile(file2).map(lambda x: eval(x)).collectAsMap())
    score2_mass_percentiles = \
        make_percentile_dict(score2_masses, filter_out=(), boost_dict_fixed_alg=boost_dict[2], scale=1)

    score3_dict = clean_dict(spark.sparkContext.textFile(file3).map(lambda x: eval(x)).collectAsMap())
    codes_one_hot_dict = \
        {C: {i: score3_dict[C]['codes'][i] for i in range(len(score3_dict[C]['codes']))} for C in score3_dict}
    pc_matrix_dict = {C: score3_dict[C]['pc_matrix'] for C in score3_dict}
    exp_var_dict = {C: sorted(score3_dict[C]['exp_var'], reverse=True) for C in score3_dict}
    norm_params_dict = {C: score3_dict[C]['norm_params'] for C in score3_dict}
    norm_params_tail_dict = {C: score3_dict[C]['norm_params_tail'] for C in score3_dict}
    score3_data = [codes_one_hot_dict, pc_matrix_dict, exp_var_dict, norm_params_dict, norm_params_tail_dict]

    return score1_data, score2_mass_percentiles, score3_data

boost_dict_bc = spark.sparkContext.broadcast(boost_dict)
model_data = spark.sparkContext.broadcast(process_data())



scores = data.map(lambda x: (x[0][1],
                             (palm_algorithms.scores(model_data.value, boost_dict_bc.value, x[0][0], x[1])), #make_agg(x)),
                             tuple(x[1])))

def make_agg(x): #Not Used
    #scoresAgg = scores.map(lambda x: (int(x[1][0]) + int(x[1][1]) + int(x[1][3]) / 3))
    scoreAgg = ((x[1][0] + x[1][1] + x[1][3]) / 3)
    return x[0], x[1], scoreAgg


def make_row(x):
    scores = x[1]
    colors = bucket_type.colors(scores)
    return json.dumps({'patentApplicationNumber': x[0], 'score1': scores[0], 'bucketType1': colors[0], 'score2': scores[1],
                       'bucketType2': colors[1], 'score3': scores[2], 'bucketType3': colors[2], 'score4': scores[3],
                       'bucketType4': colors[3], 'history': x[2]})

output = scores.map(lambda x: make_row(x))

#Create agg scores
df = spark.read.json(output)
df = df.withColumn('score', format_number(((df['score1'] + df['score2'] + df['score4']) / 3),0).cast('integer'))


get_color_udf = udf(bucket_type.get_agg_color, StringType())
df = df.withColumn('bucketType', get_color_udf('score'))

#Change Bucket Name
def change_bucket_name(bucketType):
    if bucketType == 'green':
        return 'above_average'
    if bucketType == 'yellow':
        return 'average'
    if bucketType == 'red':
        return 'below_average'

change_bucket_name_udf = udf(change_bucket_name, StringType())
df = df.withColumn('bucketType', change_bucket_name_udf('bucketType') )

df.printSchema()
print df.take(1)

#Export to HDFS
try:
    if run_prod_cmd:
        os.system('hdfs dfs -rm -f -R ' + save_dir + 'output')
    else:
        os.system('rd /s /q ' + save_dir + 'output')

    df.write.json((save_dir + 'output'))
    print 'Exported to HDFS at ' + save_dir
except Exception:
    print 'Export to HDFS Failed'
    pass
    
#Push To Hive
try:
    hive.sql("DROP TABLE IF EXISTS " + HIVE_table_2)
    df.createOrReplaceTempView("application_txn_score_2_temp")
    hive.sql("CREATE TABLE IF NOT EXISTS " + HIVE_table_2 + " STORED AS ORC  AS SELECT * from application_txn_score_2_temp")
    print 'Exported to Hive'
except Exception:
    print 'Export to Hive Failed'
    pass

#Push to Elastic Search
try:
    #Merge transaction_score with appmdr table
    df_mdr = spark.read.table('bdr.appmdr')
    #df_trx = spark.read.table('bdr.application_txn_score')
    #df_joined = df_trx.join(df_mdr, on='patentApplicationNumber')
    df_joined = df.join(df_mdr, on='patentApplicationNumber')
    cols = ['patentApplicationNumber','groupArtUnitNumber', 'workGroup', 'techCenter', 'examinerEmployeeNumber', 
    'filingDate', 'grantDate', 'nationalClass', 'nationalSubclass', 'score', 'bucketType', 'score1', 'bucketType1', 'score2',
    'bucketType2', 'score3', 'bucketType3','score4','bucketType4','id'] 
    df_final = df_joined.select(cols)

    df_final = df_final.withColumnRenamed('workGroup', 'workGroupNumber').withColumnRenamed('techCenter', 'techCenterNumber')
    df_final = df_final.withColumn('filingDate', from_unixtime(timestamp=unix_timestamp(timestamp='filingDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))
    df_final = df_final.withColumn('grantDate', from_unixtime(timestamp=unix_timestamp(timestamp='grantDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))

    rdd_mapped = df_final.rdd.map(lambda y: y.asDict())

    def package(doc):        
        _json = json.dumps(doc)
        keys = doc.keys()
        for key in keys:
            if doc[key] == 'null' or doc[key] == 'None':
                del doc[key]
        if not doc.has_key('id'):
            id = hashlib.sha224(_json).hexdigest()
            doc['id'] = id
        else:
            id = doc['id']
        _json = json.dumps(doc)
        return (id, _json)

    exportRDD = rdd_mapped.map(package)

    ESNODES = ES_nodes

    exportRDD.saveAsNewAPIHadoopFile(
        path='-', 
        outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
        keyClass="org.apache.hadoop.io.NullWritable",  
        valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
        conf={ "es.resource" : txn_ES_index_2 + "/" + txn_ES_index_2, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user":"elastic","es.write.operation":"index",
            "es.nodes.wan.only":"false","es.net.ssl":"true","es.net.http.auth.pass":"changeme",
            "es.nodes":ESNODES, "es.port":"9200" })

    print 'Exported to Elastic Search'
except Exception:
    print 'Export to Elastic Search Failed'
    pass
