import numpy as np
from scipy.stats import norm
from math import log
from copy import copy
from collections import Counter
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# create a file handler
handler = logging.FileHandler('palm_algorithms.log')
handler.setLevel(logging.DEBUG)
# create a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
# add the handlers to the logger
logger.addHandler(handler)


def score1(percentiles_dict, filter_out, code, history):
    if code not in percentiles_dict:
            return None
    scores = []
    L = len(history)
    if L <= 1:
        logger.warn('Status code history needs more than a single code.')
        return None
    try:
        for i in range(L - 1):
            event = (history[i], history[i + 1])
            if event[0] == '' or event[1] == '':
                continue
            if event not in filter_out:
                """ return 100 if an event occurs which has not been previously encountered """
                scores.append(percentiles_dict[code].get(event, 100))
            else:
                scores.append(0)
        return max(scores)
    except:
        logger.error('Scoring of %s has failed!', history)
        logger.error("Error message", exc_info=True)
        return None


def score2(mass_percentiles, code, history):
    if code not in mass_percentiles:
            return None
    for tuple_of_paths in mass_percentiles[code]:
        if history in tuple_of_paths:
            return mass_percentiles[code][tuple_of_paths]
        """ this is the result if we are given an unseen history; 
        it's a compromise between being rare and being noise """
        return 50


def score3(score3_data, code, history, mode, boost_dict):
    from utils import sum_squares, up_to_half_var, last_ten_p_var

    def input_to_vector(code, history):
        codes_one_hot = codes_one_hot_dict[code]
        counter = Counter(history)
        vector = [counter.get(codes_one_hot[i], 0) for i in range(len(codes_one_hot))]
        return np.array(vector)

    def get_pc_vector(vector, pc_matrix, exp_var, mode='main'):  # vector is a numpy array
        d = len(pc_matrix)
        pc_matrix = np.array(pc_matrix)  # d x d matrix
        if mode == 'main':
            n = up_to_half_var(exp_var) + 1
            #   print 'shape of matrix:', pc_matrix[:d, :n].shape
            return np.dot(vector, pc_matrix[:d, :n])
        elif mode == 'tail':
            n = last_ten_p_var(exp_var) + 1
            return np.dot(vector, pc_matrix[:d, -n:])
        
    def get_score(vector, exp_var, reverse=False):  # vector has components principal scores
        total_var = len(exp_var)
        if not reverse:
            n = up_to_half_var(exp_var) + 1
            """ define weights so that sum of squares is properly normalized, but we cap the weight at 10 """
            weights = [1 / max(float(x * total_var), 0.1) for x in exp_var[:n]]
        if reverse:
            n = last_ten_p_var(exp_var) + 1
            exp_var = copy(exp_var)
            exp_var.reverse()
            num_zeros = len(filter(lambda x: x == 0, exp_var))
            """ weights going from least pc to the first pc that yields explained variance greater than 0.1 """
            weights = [0] * num_zeros + [1 / max(float(x * total_var), 0.1) for x in exp_var[:n]]
        sum_squares_score = sum_squares(vector, weights=weights, reverse=reverse)
        if sum_squares_score > 0:
            return log(sum_squares_score)
        else:
            return -10 ** 6
        
    codes_one_hot_dict = score3_data[0] 
    pc_matrix_dict = score3_data[1]
    exp_var_dict = score3_data[2]
    norm_params_dict = score3_data[3]
    norm_params_tail_dict = score3_data[4]

    if code not in codes_one_hot_dict:
        return None
    vector = input_to_vector(code, history)
    exp_var = exp_var_dict[code]
    pc_vector = get_pc_vector(vector, pc_matrix_dict[code], exp_var_dict[code], mode=mode)
    if mode == 'main':
        score = 0
        try:
            input_score = get_score(pc_vector, exp_var, reverse=False)
            mu, s = norm_params_dict[code]
            norm_main = norm(loc=mu, scale=s)
            score = int(100 * norm_main.cdf(input_score + s*boost_dict[3].get(code, 0)))
        except:
            print "Scoring has failed!"
            print str(code)
            logger.error('Scoring of %s has failed!', str(code))
            logger.error("Error message", exc_info=True)
        return score
    elif mode == 'tail':
        try:
            input_score = get_score(pc_vector, exp_var, reverse=True)
            mu_tail, s_tail = norm_params_tail_dict[code]
            norm_tail = norm(loc=mu_tail, scale=s_tail)
            score = int(100 * norm_tail.cdf(input_score + s_tail*boost_dict[4].get(code,0)))
        except:
            print "scoring has failed!"
            print str(code)
            logger.error('Scoring of %s has failed!', str(code))
            logger.error("Error message", exc_info=True)
        return score


def scores(model_data, boost_dict, code, history): #model_data = (list, dict, list of dicts)
    code = code.zfill(3)
    history = tuple(history)
    return score1(model_data[0][0], model_data[0][1], code, history), \
           score2(model_data[1], code, history), \
           score3(model_data[2], code, history, 'main', boost_dict), \
           score3(model_data[2], code, history, 'tail', boost_dict)

