# script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# 1. export HADOOP_USER_NAME=hdfs
# 2. ./model_appl_txn_score_analytics.sh data_prep
# 3. ./model_appl_txn_score_analytics.sh bucket_txns
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values
#
#########################################################################################
#
PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-txn-score-analytics/src'
#DOCCOUNT=$1
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs/bdr-txn-score-analytics'
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
export HADOOP_USER_NAME=hdfs
#
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1

echo "Starting Data_Prep: " $(date +'%Y-%m-%d:%H:%M')
#
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-txn-score-analytics' 'Data_Prep' 'started' $startdatetime
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --py-files $CODEPATH/helper.py,$CODEPATH/create_logger.py --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $EXTRAJARPATH/ojdbc6.jar $CODEPATH/data_prep.py
#
#if [ $? -ne 0 ]; then
#  echo "$Data_Prep Python script failed"
#  exit 1
#fi
echo "Completed  Data_Prep:" $(date +'%Y-%m-%d:%H:%M')
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-txn-score-analytics' 'transaction score analytics' 'completed' $startdatetime


#
#exec >$LOGPATH/$JOB.$RUNDATE.log
#exec 2>&1
echo "Starting Data_Scoring: "  $(date +'%Y-%m-%d:%H:%M')
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-txn-score-analytics' 'Data_Scoring' 'started' $startdatetime

#
#/usr/hdp/current/spark2-client/bin/spark-submit --master $SPARK_SERVER  --master yarn --packages $PACKAGE --jars $EXTRAJARPATH/ojdbc8.jar,$EXTRAJARPATH/elasticsearch-hadoop-5.6.2.jar --conf spark.executor.memory=8g --conf spark.driver.memory=16g  --conf spark.executor.instances=2 --conf spark.executor.cores=8  $CODEPATH/app.py bucket_results
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $EXTRAJARPATH/ojdbc6.jar,$EXTRAJARPATH/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar --conf spark.executor.memory=50g --conf spark.driver.memory=20g  --conf spark.executor.instances=10 --conf spark.executor.cores=10 $CODEPATH/bucket_txns.py
#if [ $? -ne 0 ]; then
#  echo "Data_Scoring Python script failed"
#  exit 1
#fi
#echo "Completed $job2:" $(date +'%Y-%m-%d:%H:%M')
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-txn-score-analytics' 'Data_Scoring' 'completed' $startdatetime
