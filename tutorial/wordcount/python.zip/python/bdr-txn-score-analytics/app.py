import sys
import os.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
#sys.path.append(os.path.join(os.path.dirname(__file__)))
sys.path.append('/data/bdr/scripts/bdr-txn-score-analytics/src/utils')
from src import bucket_txns, data_prep
import time

if __name__ == "__main__":
    if len(sys.argv) > 1:
        job_name = sys.argv[1]
        if job_name == "data_prep":
            start_time = time.time()
            data_prep.run_data_prep()
            print("--- Processing time was %s seconds ---" % (time.time() - start_time))
        elif job_name == "bucket_results":
            process_abandoned = False
            if len(sys.argv) == 3:
                user_val = sys.argv[2]
                if "true" == user_val.lower():
                    process_abandoned = True
            start_time = time.time()
            bucket_txns.run_bucket_results(process_abandoned)
            print("--- %s seconds ---" % (time.time() - start_time))
        else:
            print "Invalid job name. Valid options are 'data_prep' and 'bucket_results'"
    else:
        print "Invalid number of arguments. must specify job name. Valid options are 'data_prep' and 'bucket_results'"
