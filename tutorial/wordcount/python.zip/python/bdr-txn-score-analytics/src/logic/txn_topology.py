import networkx as nx
###import matplotlib.pyplot as plt


valid_trx = ['30', '37', '41', '71', '61', '66', '80', '83', '89', '95', '116', '120', '135', '136', '139', '144',
             '150', '160', '161', '162', '163', '164', '165', '166', '167', '168', '169']


def build_labeldict():
    # define state names
    labeldict = {}
    labeldict["30"] = "Start|RCE"
    labeldict["41"] = "Non Final Rejection"
    labeldict["71"] = "Response to Non Final Rejection"
    labeldict["61"] = "Final Rejection"
    labeldict["66"] = "Withdraw Abandonment"
    labeldict["80"] = "Response to Final Rejection"
    labeldict["89"] = "Allowed"
    labeldict["83"] = "Advisory Action"
    labeldict["95"] = "Issue Payment Verified"
    labeldict["116"] = "Appeal is Ready for Review"
    labeldict["120"] = "Notice of Appeal Action"
    labeldict["135"] = "Board of Appeals Decision Rendered"
    labeldict["136"] = "Amendment"
    labeldict["139"] = "Appeal Dismissed"
    labeldict["150"] = "Patented Case"
    labeldict["160"] = "Abandoned"

    return labeldict


def build_valid_patent_transaction_graph():
    patent_trx_graph = nx.MultiDiGraph()
    # define available states
    patent_trx_graph.add_node('30')
    patent_trx_graph.add_node('41')
    patent_trx_graph.add_node('71')
    patent_trx_graph.add_node('61')
    patent_trx_graph.add_node('80')
    patent_trx_graph.add_node('89')
    patent_trx_graph.add_node('83')
    patent_trx_graph.add_node('95')
    patent_trx_graph.add_node('116')
    patent_trx_graph.add_node('120')
    patent_trx_graph.add_node('135')
    patent_trx_graph.add_node('136')
    patent_trx_graph.add_node('139')
    patent_trx_graph.add_node('150')
    patent_trx_graph.add_node('160')

    # define valid transitions
    patent_trx_graph.add_edge('30', '41')
    patent_trx_graph.add_edge('41', '71')
    patent_trx_graph.add_edge('71', '61')
    patent_trx_graph.add_edge('61', '80')
    patent_trx_graph.add_edge('80', '83')
    patent_trx_graph.add_edge('80', '89')
    patent_trx_graph.add_edge('83', '120')
    patent_trx_graph.add_edge('120', '116')
    patent_trx_graph.add_edge('116', '160')
    patent_trx_graph.add_edge('160', '66')
    patent_trx_graph.add_edge('66', '41')
    patent_trx_graph.add_edge('66', '71')
    patent_trx_graph.add_edge('83', '80')
    patent_trx_graph.add_edge('83', '89')
    patent_trx_graph.add_edge('61', '30')
    patent_trx_graph.add_edge('61', '120')
    patent_trx_graph.add_edge('80', '30')
    patent_trx_graph.add_edge('135', '89')
    patent_trx_graph.add_edge('71', '89')
    patent_trx_graph.add_edge('71', '41')
    patent_trx_graph.add_edge('89', '150')
    patent_trx_graph.add_edge('89', '160')
    patent_trx_graph.add_edge('95', '150')
    patent_trx_graph.add_edge('136', '89')
    patent_trx_graph.add_edge('30', '89')
    patent_trx_graph.add_edge('136', '41')
    """ Per Scott, you can't do non final or final after appeal """
    # patent_trx_graph.add_edge('116', '41')
    patent_trx_graph.add_edge('120', '139')
    patent_trx_graph.add_edge('120', '135')
    patent_trx_graph.add_edge('83', '30')
    patent_trx_graph.add_edge('83', '160')
    patent_trx_graph.add_edge('66', '30')
    patent_trx_graph.add_edge('160', '95')
    patent_trx_graph.add_edge('135', '160')
    patent_trx_graph.add_edge('139', '160')
    patent_trx_graph.add_edge('135', '30')
    patent_trx_graph.add_edge('139', '30')
    patent_trx_graph.add_edge('41', '160')
    patent_trx_graph.add_edge('30', '160')
    patent_trx_graph.add_edge('120', '136')
    patent_trx_graph.add_edge('89', '95')
    patent_trx_graph.add_edge('61', '160')
    patent_trx_graph.add_edge('116', '135')

    return patent_trx_graph


def display_graph(patent_trx_graph, labeldict):
    # show the graph
    if labeldict:
        nx.draw_networkx(patent_trx_graph, labels=labeldict)
    else:
        nx.draw_networkx(patent_trx_graph)
    ###plt.show()


def filter_list(full_list):
    s = set(valid_trx)
    filtered_list = []
    for x in full_list:
        if x in s:
            if x == '37':
                filtered_list.append('30')
            elif x == '144':
                filtered_list.append('135')
            elif x in ('161', '162', '163', '164', '165', '166', '167', '168', '169'):
                filtered_list.append('160')
            else:
                filtered_list.append(x)
    return filtered_list

# graph_of_valid_patent_transaction = build_valid_patent_transaction_graph()
# labeldict = build_labeldict()
# display_graph(graph_of_valid_patent_transaction, labeldict)
