quayle_code = '51'
nfr_code = '41'
fr_code = '61'
rce_code = '30'
appeal_code = '116'
appeal_notice_code = '120'
appeal_rendered_code = '135'
appeal_decision_code = '144'


def is_abandoned(trx):
    if trx[-1] in ('161', '162', '163', '164', '165', '166', '167', '168', '169'):
        return True
    return False


def quayle_violation(trx):
    if quayle_code in trx:
        number_of_occur = trx.count(quayle_code)
        if number_of_occur > 1:
            return True
        else:
            location_of_quayle = trx.index(quayle_code)
            if nfr_code in trx:
                location_of_nfr = trx.index(nfr_code)
                if location_of_quayle < location_of_nfr:
                    return True
            if fr_code in trx:
                location_of_fr = trx.index(fr_code)
                if location_of_quayle < location_of_fr:
                    return True
            return False
    else:
        return False


def r_check(trx, limit, code):
    if nfr_code in trx:
        nfr_indices = [i for i, x in enumerate(trx) if x == code]
        rce_indices = [i for i, x in enumerate(trx) if x == rce_code]
        num_of_nfr_occur = 0
        for v, w in zip(nfr_indices, nfr_indices[1:]):
            seq_flag = True
            for rce_index in rce_indices:
                if v < rce_index < w:
                    seq_flag = False
                    break
            if seq_flag:
                num_of_nfr_occur += 1
            else:
                if num_of_nfr_occur > limit:
                    return True
                num_of_nfr_occur = 0
        if num_of_nfr_occur > limit:
            return True
    return False


def nfr_warning(trx):
    return r_check(trx, 2, nfr_code)


def nfr_violation(trx):
    return r_check(trx, 3, nfr_code)


def fr_warning(trx):
    return r_check(trx, 2, fr_code)


def fr_violation(trx):
    return r_check(trx, 3, fr_code)


def appeal_check(trx, code_check):
    for code in (appeal_code, appeal_rendered_code, appeal_decision_code):
        if code in trx:
            code_index = trx.index(code)
            if code_check in trx:
                nfr_indices = [i for i, x in enumerate(trx) if x == code_check]
                if len(nfr_indices) > 1:
                    if code_index < nfr_indices[-1]:
                        return True
                else:
                    if code_index < nfr_indices[0]:
                        return True
    return False


def appeal_warning(trx):
    return appeal_check(trx, nfr_code)


def appeal_violation(trx):
    return appeal_check(trx, fr_code)
