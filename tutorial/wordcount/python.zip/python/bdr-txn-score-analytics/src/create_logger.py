import logging


def get_logger(name='logger', log_file_name='logger.log', log_format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    # create a file handler
    handler = logging.FileHandler(log_file_name)
    handler.setLevel(logging.DEBUG)
    # create a logging format
    formatter = logging.Formatter(log_format)
    handler.setFormatter(formatter)
    # add the handlers to the logger
    logger.addHandler(handler)

    return logger

