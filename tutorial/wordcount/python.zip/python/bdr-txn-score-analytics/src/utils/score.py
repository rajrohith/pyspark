import category_type
from collections import defaultdict
from src.utils.trx_score import TrxScore
from helper import get_score_init_values


def produce_scores(trxs):
    scores = []
    green_val, yellow_val, red_val, green_val_max, yellow_val_max, red_val_max, penalty = get_score_init_values()

    for key, value in trxs.iteritems():
        penalty = penalty * len(value)
        if len(value) > 1:
            pause="here"
        class_id = value[0].class_id
        trx_history = value[0].trx_history
        red_flag = False
        category = category_type.RED
        messages = defaultdict(list)
        for trx in value:
            if trx.category == category_type.RED:
                red_flag = True
            category = trx.category
            if trx.reason:
                message = ""
                if trx.bad_path:
                    message = "check following edge: %r" % trx.bad_path
                messages[trx.reason].append(message)

        if red_flag:
            category = category_type.RED
            score = red_val

        if category == category_type.YELLOW:
            score = yellow_val

        scores.append(TrxScore(class_id=class_id, app_id=key, trx_history=trx_history, score=score+penalty,
                               category=category, messages=messages))

    return scores


# def trx_2_trx_score(class_id, app_id, trx_history, category=category_type.GREEN, reason="", bad_path=[]):
#     TrxScore(class_id=class_id, app_id=app_id, trx_history=trx_history, score=0.0, category=category,
#              messages=messages)
#     scores = []
#
#     for key, value in trxs.iteritems():
#         if len(value) > 1:
#             pause="here"
#         class_id = value[0].class_id
#         trx_history = value[0].trx_history
#         red_flag = False
#         category = category_type.RED
#         messages = defaultdict(list)
#         for trx in value:
#             if trx.category == category_type.RED:
#                 red_flag = True
#             category = trx.category
#             if trx.reason:
#                 message = ""
#                 if trx.bad_path:
#                     message = "check following edge: %r" % trx.bad_path
#                 messages[trx.reason].append(message)
#
#         if red_flag:
#             category = category_type.RED
#
#         scores.append(TrxScore(class_id=class_id, app_id=key, trx_history=trx_history, score=0.0, category=category,
#                                messages=messages))
#
#     return scores
