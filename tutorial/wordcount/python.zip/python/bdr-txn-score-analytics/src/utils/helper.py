from ConfigParser import SafeConfigParser
import os
from create_logger import get_logger
import pyspark
from pyspark.sql import SparkSession, HiveContext
from pyspark.ml.feature import StringIndexer
import findspark
import json
import hashlib
from pyspark.sql.functions import udf, lit, unix_timestamp, from_unixtime
from pyspark.sql.types import StringType, IntegerType, DoubleType, StructType, StructField
import traceback

log_relative_path = '/data/bdr/logs/bdr-txn-score-analytics/'
#log_relative_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir)) + '/logs/'
log_postfix = '_txns.log'
results_directory = 'bucketing_results'

config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)) \
    + '/bdr-txn-score-analytics.properties'
    
def get_score_init_values():
    parser = SafeConfigParser()
    parser.read(config_path)
    global_config = "global_config"
    green_val = float(parser.get(global_config, 'green_val'))
    yellow_val = float(parser.get(global_config, 'yellow_val'))
    red_val = float(parser.get(global_config, 'red_val'))
    green_val_max = float(parser.get(global_config, 'green_val_max'))
    yellow_val_max = float(parser.get(global_config, 'yellow_val_max'))
    red_val_max = float(parser.get(global_config, 'red_val_max'))
    penalty = float(parser.get(global_config, 'penalty'))

    return green_val, yellow_val, red_val, green_val_max, yellow_val_max, red_val_max, penalty

def get_configs(config_setting_name):
    parser = SafeConfigParser()
    parser.read(config_path)
    env_type = parser.get("global_config", 'env_type')
    if env_type == 'PROD':
        print "Running PROD Config"
        config_settings = config_setting_name + '_prod'
        run_prod_cmd = True
    else:
        print "Running Dev Config"
        config_settings = config_setting_name + '_dev'
        run_prod_cmd = False

    findspark.init(spark_home=parser.get(config_settings, 'findspark_init'))
    #conf = pyspark.SparkConf().setAppName(parser.get(config_settings, 'app_name'))
    #sc = pyspark.SparkContext(conf=conf).getOrCreate()

    spark = SparkSession.builder.appName(parser.get(config_settings, 'app_name')).enableHiveSupport().getOrCreate()
    hive = HiveContext(spark)

    save_dir = parser.get(config_settings, 'save_dir')

    ES_nodes = parser.get(config_settings, 'ES_nodes')
    HIVE_table = parser.get(config_settings, 'HIVE_table')
    txn_ES_index = parser.get(config_settings, 'txn_ES_index')
    txn_ES_type = parser.get(config_settings, 'txn_ES_type')

    spark.sparkContext.addPyFile('./src/utils/helper.py')

    return run_prod_cmd, save_dir, config_settings, parser, spark, hive, ES_nodes, HIVE_table, txn_ES_index, txn_ES_type

def to_unix(date):
    import time
    try:
        X = int(time.mktime(time.strptime(date, '%Y-%m-%d')))
        return X
    except Exception:
        return 978325200


def save_rdd(rdd, save_to_dir, path, run_prod_cmd=False):
    print rdd.take(1)
    path = save_to_dir + path
    if run_prod_cmd:
        print 'Saving RDD to : ' + path
        os.system('hdfs dfs -rm -f -R {}'.format(path))
    else:
        os.system('rd /s /q ' + save_to_dir)
    rdd.saveAsTextFile(path)


def log_results(trxs, log_name):
    trx_logger = get_logger(name=log_name, log_file_name=log_relative_path + log_name + log_postfix,
                            log_format='%(message)s')

    for trx in trxs:
        trx_logger.info("class: %s, app id: %s" % (trx.class_id, trx.app_id))
        trx_logger.info("transaction: %s" % trx.trx_history)
        if trx.category:
            trx_logger.info("category: %s" % trx.category)
        if trx.messages:
            for key, value in trx.messages.iteritems():
                trx_logger.info("reason: %s" % key)
                for val in value:
                    trx_logger.info("message: %s" % val)
        trx_logger.info("")


def log_stats(number_of_good, number_of_error, number_of_abandoned, number_of_abandoned_fees, skipped_abandoned,
              log_name="stats"):
    stats_logger = get_logger(name=log_name, log_file_name=log_relative_path + log_name + log_postfix,
                              log_format='%(message)s')

    stats_logger.info("Number of clean transactions:")
    stats_logger.info(len(number_of_good))
    stats_logger.info("Number of error transactions:")
    stats_logger.info(len(number_of_error))
    stats_logger.info("Number of abandoned transactions:")
    stats_logger.info(len(number_of_abandoned))
    stats_logger.info("Number of abandoned transactions after fee was paid:")
    stats_logger.info(len(number_of_abandoned_fees))
    stats_logger.info("Number of skipped abandoned:")
    stats_logger.info(skipped_abandoned)


def save_to_json(results, file_name):
    with open(file_name, 'w') as outfile:
        outfile.write(json.dumps([ob.__dict__ for ob in results]))


def create_subdirectory_win_os(directory_name):
    full_path = directory_name + results_directory
    os.system('mkdir ' + full_path)
    return full_path


def save_win_os(directory_name, file_name):
    os.system('copy ' + file_name + ' ' + directory_name + '\\' + file_name)


def create_subdirectory_hdfs_os(directory_name):
    full_path = directory_name + results_directory
    os.system('hdfs dfs -mkdir ' + full_path)
    return full_path


def save_hdfs_os(directory_name, file_name):
    os.system('hdfs dfs -copyFromLocal -f ' + file_name + ' ' + directory_name + '/' + file_name)

def etl_from_hdfs(spark, save_dir):
    schema = StructType([
        StructField("app_id", StringType(), True),
        StructField("category", StringType(), True),
        StructField("class_id", StringType(), True),
        StructField("messages", StringType(), True),
        StructField("score", DoubleType(), True),
        StructField("trx_history", StringType(), True),
    ])
    df_good = spark.read.json(save_dir + 'bucketing_results/good_bucket.json')
    df_error = spark.read.json(save_dir + 'bucketing_results/error_bucket.json', schema = schema)
    #df_aband = spark.read.json('hdfs://bdr-itwv-hue-1.dev.uspto.gov/user/ekrinker/trn/data/output/bucketing_results/abandoned_bucket.json')
    
    df_good = df_good.withColumn('messages', lit('None').cast(StringType()))

    df_good = df_good.select('app_id','class_id','category','score','trx_history','messages')
    df_error = df_error.select('app_id','class_id','category','score','trx_history','messages')

    df_union = df_good.union(df_error)
    df_union = df_union.withColumnRenamed('app_id','patentApplicationNumber')
    df_union = df_union.withColumnRenamed('category','bucketType')
    df_union = df_union.withColumnRenamed('class_id', 'classId')
    df_union = df_union.withColumnRenamed('trx_history', 'trxHistory')

    def change_bucket_name(bucketType):
        if bucketType == 'green':
            return 'above_average'
        if bucketType == 'yellow':
            return 'average'
        if bucketType == 'red':
            return 'below_average'

    change_bucket_name_udf = udf(change_bucket_name, StringType())
    df_union = df_union.withColumn('bucketType', change_bucket_name_udf('bucketType') )

    return df_union

def export_to_hive(df, hive, HIVE_table):
    print 'Exporting to Hive'
    hive.sql("DROP TABLE IF EXISTS " + HIVE_table)
    df.createOrReplaceTempView("application_txn_score_temp")
    hive.sql("CREATE TABLE IF NOT EXISTS " + HIVE_table + " STORED AS ORC  AS SELECT * from application_txn_score_temp")
    #hive.sql("INSERT INTO bdr.application_txn_score  SELECT * from application_txn_score_temp")
    print 'Exported to Hive'

def export_to_elastic(df, spark, ES_nodes, txn_ES_index, txn_ES_type):
    df_mdr = spark.read.table('bdr.appmdr')
    #df_trx = spark.read.table('bdr.application_txn_score')
    #df_joined = df_trx.join(df_mdr, on='patentApplicationNumber')
    df_joined = df.join(df_mdr, on='patentApplicationNumber')
    cols = ['patentApplicationNumber','groupArtUnitNumber', 'workGroup', 'techCenter', 'examinerEmployeeNumber', 
            'filingDate', 'grantDate', 'nationalClass', 'nationalSubclass', 'bucketType', 'score', 'messages','trxHistory','id'] 
    df_final = df_joined.select(cols)

    df_final = df_final.withColumnRenamed('workGroup', 'workGroupNumber').withColumnRenamed('techCenter', 'techCenterNumber')
    df_final = df_final.withColumn('filingDate', from_unixtime(timestamp=unix_timestamp(timestamp='filingDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))
    df_final = df_final.withColumn('grantDate', from_unixtime(timestamp=unix_timestamp(timestamp='grantDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))

    rdd_mapped = df_final.rdd.map(lambda y: y.asDict())

    def package(doc):
        _json = json.dumps(doc)
        keys = doc.keys()
        for key in keys:
            if doc[key] == 'null' or doc[key] == 'None':
                del doc[key]
        if not doc.has_key('id'):
            id = hashlib.sha224(_json).hexdigest()
            doc['id'] = id
        else:
            id = doc['id']
        _json = json.dumps(doc)
        return (id, _json)
     
    exportRDD = rdd_mapped.map(package)

    print 'Exporting to Elastic Search'
    
    try:
        exportRDD.saveAsNewAPIHadoopFile(
            path='-', 
            outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
            keyClass="org.apache.hadoop.io.NullWritable",  
            valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
            conf={ "es.resource" : txn_ES_index + "/" + txn_ES_index, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user":"elastic","es.write.operation":"index",
                "es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
                "es.nodes.wan.only":"true","es.net.http.auth.pass":"changeme","es.net.ssl":"true","es.nodes": ES_nodes, "es.port":"9200",})
        print 'Exported to Elastic Search'
    except Exception as ex:
        print traceback.format_exc()