from src.utils import category_type
from helper import get_score_init_values


def clamp(n, minn, maxn):
    return max(min(maxn, n), minn)


class TrxScore(object):
    def __init__(self, class_id, app_id, trx_history, score, category=category_type.GREEN, messages={}):
        green_val, yellow_val, red_val, green_val_max, yellow_val_max, red_val_max, penalty = get_score_init_values()

        self.class_id = class_id
        self.app_id = app_id
        self.trx_history = trx_history
        self.messages = messages
        self.category = category

        trx_history_complexity = len(trx_history) % 10
        penalty = penalty * trx_history_complexity

        if category == category_type.GREEN:
            self.score = clamp(score+penalty, green_val, green_val_max)
        elif category == category_type.YELLOW:
            self.score = clamp(score+penalty, yellow_val, yellow_val_max)
        elif category == category_type.RED:
            self.score = clamp(score+penalty, red_val, red_val_max)


