from src.utils import category_type


class Trx(object):
    def __init__(self, class_id, app_id, trx_history, category=category_type.GREEN, reason="", bad_path=[]):
        self.class_id = class_id
        self.app_id = app_id
        self.trx_history = trx_history
        self.bad_path = bad_path
        self.reason = reason
        self.category = category
