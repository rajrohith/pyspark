import sys
import os.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import json
#from src.utils.create_logger import get_logger
#from src.utils.helper import to_unix, save_rdd, get_configs, log_relative_path
from helper import to_unix, save_rdd, get_configs, log_relative_path
from create_logger import get_logger

def run_data_prep():

    """
    Set up few config objects
    """
    run_prod_cmd, save_dir, config_settings, parser, spark, hive, ES_nodes, HIVE_table, txn_ES_index, txn_ES_type, \
        ES_user, ES_pass, ES_port = get_configs("dataprep")
    logger = get_logger(log_file_name=log_relative_path+'data_prep.log')

    #spark.sparkContext.addPyFile('./src/helper.py')
    #spark.sparkContext.addPyFile('./src/create_logger.py')

    """ 
    Get Application Id, along with status and time stamp
    For example:
    {"BDR_ID":1.0000000000,"APPL_ID":"12800362","APP_STATUS_NO":19,"APP_STATUS_DT":"2003-06-24T14:20:58.000-04:00"} 
    """
    palm = spark.sparkContext.textFile(parser.get(config_settings, 'palm')).map(lambda x: eval(x))
    #palm = spark.read.json(parser.get(config_settings, 'palm')).dropna(how='any', subset = 'APPL_ID').rdd.map(lambda x: x)
    """ 
    Get only App Id, Status code and time stamp that you convert to unix format 
    Note: "path" means code history
    """
    palm_paths_with_time = \
        palm.map(lambda x: (x['APPL_ID'], [(str(x['APP_STATUS_NO']), to_unix(x['APP_STATUS_DT'][:10]))]))
    """ Contract a record that would contain a record with application id and series of statuses """
    palm_paths = \
        palm_paths_with_time.reduceByKey(lambda x, y: x+y).map(lambda x: (x[0], sorted(x[1], key=lambda u: u[1])))
    palm_status_paths = palm_paths.map(lambda x: (x[0], tuple([y[0] for y in x[1]])))

    """ 
    Get information about that app id, it would contain a lot of data 
    Example:
    {"BDR_ID":1.0000000000,"APPL_ID":"12000001","FILE_DT":"2007-12-06T00:00:00.000-05:00",
    "EFFECTIVE_FILING_DT":"0001-01-01T00:00:00.000-05:00","INV_SUBJ_MATTER_TY":"UTL","APPL_TY":"REGULAR",
    "DN_EXAMINER_NO":"83238 ","DN_DW_DN_GAU_CD":"2186  ","DN_PTO_ART_CLASS_NO":"711","DN_PTO_ART_SUBCLASS_NO":"154000",
    "CONFIRM_NO":8706,"DN_INTPPTY_CUST_NO":23400,"ATTY_DKT_NO":"01-1558","DN_NSRD_CURR_LOC_CD":"e    ",
    "DN_NSRD_CURR_LOC_DT":"0001-01-01T00:00:00.000-05:00","APP_STATUS_NO":150,
    "APP_STATUS_DT":"2011-04-06T09:38:06.000-04:00","PATENT_NO":"7934050   ",
    "PATENT_ISSUE_DT":"2011-04-26T00:00:00.000-04:00","ABANDON_DT":"0001-01-01T00:00:00.000-05:00",
    "DISPOSAL_TYPE":"ISSUED","SE_IN":"N","PCT_NO":"                 ",
    "INVN_TTL_TX":"MICROCOMPUTER FOR FLASH MEMORY REWRITING","AIA_IN":"N","CONTINUITY_TYPE":"   ",
    "FRGN_PRIORITY_CLM":"Y","USC_119_MET":"Y","FIG_QT":0,"INDP_CLAIM_QT":3,"EFCTV_CLAIMS_QT":16}
    """
    palm_apps = spark.sparkContext.textFile(parser.get(config_settings, 'palm_apps')).map(lambda x: json.loads(x))
    """
    We only interested in the class
    """
    art_class_public = palm_apps.map(lambda x: (str(x['APPL_ID']), str(x.get('DN_PTO_ART_CLASS_NO', '   '))))
    """ 
    Get the application id, its class and transaction history and save it for further processing
    Format: 
    palm_status_paths_with_art_class: ((art class, appid), history) 
    Example
    (('386', '12952630'), ('19', '17', '20', '30', '89', '90', '93', '94', '95', '150'))
    """
    palm_status_paths_with_art_class = palm_status_paths.join(art_class_public).map(lambda x: ((x[1][1], x[0]), x[1][0]))
    save_rdd(palm_status_paths_with_art_class, save_dir, 'palm_status_paths_with_art_class', run_prod_cmd)

    logger.info('Done with palm_status_paths_with_art_class')

if __name__ == "__main__":
    run_data_prep()
