import sys
import os.path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
import business_rules
from txn_topology import build_valid_patent_transaction_graph, filter_list
import category_type
from helper import get_configs, log_results, log_stats, save_to_json, create_subdirectory_win_os, \
     create_subdirectory_hdfs_os, save_win_os, save_hdfs_os, get_score_init_values, etl_from_hdfs, export_to_hive, export_to_elastic
from score import produce_scores
from trx import Trx
from trx_score import TrxScore
from collections import defaultdict


def add_to_bucket(app_id, class_id, path, message, category, abandoned_trxn, paid_trxn, number_of_error, number_of_abandoned, number_of_abandoned_fees):
    if abandoned_trxn:
        if paid_trxn:
            number_of_abandoned_fees[app_id].append(Trx(class_id=class_id, app_id=app_id,
                                                        trx_history=str(path),
                                                        category=category, reason=message))
        else:
            number_of_abandoned[app_id].append(Trx(class_id=class_id, app_id=app_id,
                                                   trx_history=str(path),
                                                   category=category, reason=message))
    else:
        number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(path),
                                           category=category, reason=message))


def run_bucket_results(process_abandoned):
    run_prod_cmd, save_dir, config_settings, parser, spark, hive, ES_nodes, HIVE_table, txn_ES_index, txn_ES_type, \
        ES_user, ES_pass, ES_port = get_configs("basket_txns")
    green_val, yellow_val, red_val, green_val_max, yellow_val_max, red_val_max, penalty = get_score_init_values()

    """
    Get the data to process
    Format: 
    palm_status_paths_with_art_class: ((art class, appid), history) 
    Example
    (('386', '12952630'), ('19', '17', '20', '30', '89', '90', '93', '94', '95', '150'))
    """

    #data = spark.sparkContext.textFile('/data/target/application_txn_score/output/palm_status_paths_with_art_class/').map(lambda x: eval(x)) 
    data = spark.sparkContext.textFile(save_dir + 'palm_status_paths_with_art_class/').map(lambda x: eval(x))
    status_paths_with_art_class = data.flatMap(lambda x: [(x[0][0], x[0][1], x[1])]).collect()


    """ 
    Get a graph representation of valid patent transactions. See screenshot for example 
    """
    graph_of_valid_patent_transaction = build_valid_patent_transaction_graph()

    number_of_error = defaultdict(list)
    number_of_abandoned = defaultdict(list)
    number_of_abandoned_fees = defaultdict(list)
    
    # number_of_good = defaultdict(list)
    number_of_good = []
    skipped_abandoned = 0

    counter = 0
    print 'Processing Applications'
    for status_path in status_paths_with_art_class:
        counter += 1
        if not run_prod_cmd:
            if counter > 500:
                break

        class_id = status_path[0]
        app_id = status_path[1]
        path = status_path[2]
        trx = list(path)

        
        #print "processing %s" % app_id

        clean_txn = True
        abandoned_trxn = False
        paid_trxn = False

        """ 
        We are only interested in certain statuses. So remove the noise like pre- or post- examination
        Also truncate certain path to just their end states, for example
        41 | MCTNF | MAIL NON-FINAL REJECTION
        40 | CTNF  | NON-FINAL REJECTION

        will be truncated to just 
        41 | MCTNF | MAIL NON-FINAL REJECTION
        since it always follows status 40
        """
        filtered_trx = filter_list(trx)

        """
        Check certain business rules
        """

        if business_rules.is_abandoned(trx):
            abandoned_trxn = True
            if not process_abandoned:
                skipped_abandoned += 1
                continue

        if '95' in filtered_trx:
            paid_trxn = True

        if business_rules.quayle_violation(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Quayle Violation", category_type.RED, abandoned_trxn, paid_trxn, number_of_error,
                          number_of_abandoned, number_of_abandoned_fees)
            # if abandoned_trxn:
            #     if '95' in filtered_trx:
            #         number_of_abandoned_fees[app_id].append(Trx(class_id=class_id, app_id=app_id,
            #                                                     trx_history=str(status_path[2]),
            #                                                    category=category_type.RED, reason="quayle violation"))
            #     else:
            #         number_of_abandoned[app_id].append(Trx(class_id=class_id, app_id=app_id,
            #                                                trx_history=str(status_path[2]),
            #                                                category=category_type.RED, reason="quayle violation"))
            # else:
            #     number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                        category=category_type.RED, reason="quayle violation"))
            # number_of_error.append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                            category=category_type.RED, reason="quayle violation"))
            # continue

        if business_rules.nfr_violation(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Multiple Non-Final Rejections", category_type.RED, abandoned_trxn, paid_trxn, number_of_error,
                          number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.RED, reason="Multiple Non-Final Rejections"))
        elif business_rules.nfr_warning(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Consequent Non-Final Rejections", category_type.YELLOW, abandoned_trxn, paid_trxn,
                          number_of_error, number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.YELLOW, reason="Consequent Non-Final Rejections"))

        if business_rules.fr_violation(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Multiple Final Rejections", category_type.RED, abandoned_trxn, paid_trxn,
                          number_of_error, number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.RED, reason="Multiple Final Rejections"))
        elif business_rules.fr_warning(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Consequent Final Rejections", category_type.YELLOW, abandoned_trxn, paid_trxn,
                          number_of_error, number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.YELLOW, reason="Consequent Final Rejections"))

        if business_rules.appeal_violation(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Final Rejection After Appeal", category_type.RED, abandoned_trxn, paid_trxn,
                          number_of_error, number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.RED, reason="Final Rejection after Appeal"))
        elif business_rules.appeal_warning(trx):
            clean_txn = False
            add_to_bucket(app_id, class_id, path, "Non Final Rejection After Appeal", category_type.YELLOW, abandoned_trxn, paid_trxn,
                          number_of_error, number_of_abandoned, number_of_abandoned_fees)
            # number_of_error[app_id].append(Trx(class_id=class_id, app_id=app_id, trx_history=str(status_path[2]),
            #                                category=category_type.YELLOW, reason="Non Final Rejection after Appeal"))

        for v, w in zip(filtered_trx, filtered_trx[1:]):
            """ 
            If it is a valid transition, add it to the list of 
            """
            #print "processing %s %s edge" % (v, w)
            if abandoned_trxn:
                """ 
                Since it was abandoned, it is not high risk 
                """
                number_of_abandoned[app_id].append(Trx(class_id=class_id, app_id=app_id,
                                                       trx_history=str(path),
                                                       category=category_type.RED, reason="Suspicious Path",
                                                       bad_path=[v, w]))
                if '95' in filtered_trx:
                    number_of_abandoned_fees[app_id].append(Trx(class_id=class_id, app_id=app_id,
                                                                trx_history=str(path),
                                                                category=category_type.RED, reason="Suspicious Path",
                                                                bad_path=[v, w]))
            else:
                if not graph_of_valid_patent_transaction.has_edge(v, w):
                    """ self loops are ok """
                    if not v == w:
                        clean_txn = False
                        if w == '61':
                            number_of_error[app_id].append(Trx(class_id=class_id,
                                                           app_id=app_id, trx_history=str(path),
                                                           category=category_type.RED, reason="First Action is FR",
                                                           bad_path=[v, w]))
                        elif v == '89' and w == '30':
                            number_of_error[app_id].append(Trx(class_id=class_id,
                                                           app_id=app_id, trx_history=str(path),
                                                           category=category_type.YELLOW, reason="RCE After Allowance",
                                                           bad_path=[v, w]))
                        elif v == '120' and w == '89':
                            number_of_error[app_id].append(Trx(class_id=class_id,
                                                           app_id=app_id, trx_history=str(path),
                                                           category=category_type.YELLOW,
                                                           reason="Allowed After Appeal Notice",
                                                           bad_path=[v, w]))
                        else:
                            number_of_error[app_id].append(Trx(class_id=class_id,
                                                           app_id=app_id, trx_history=str(path),
                                                           category=category_type.RED, reason="Suspicious Path",
                                                           bad_path=[v, w]))
                        break

        if clean_txn:
            number_of_good.append(TrxScore(class_id=class_id, app_id=app_id, trx_history=str(path), score=green_val))

    print 'Scoring Error Basket'
    scores_of_error = produce_scores(number_of_error)
    log_results(scores_of_error, "error_basket")

    if process_abandoned:
        print 'Scoring Abandoned'
        scores_of_abandoned = produce_scores(number_of_abandoned)
        log_results(scores_of_abandoned, "abandoned_basket")

        scores_of_abandoned_fees = produce_scores(number_of_abandoned_fees)
        log_results(scores_of_abandoned_fees, "abandoned_fee_basket")
    else:
        scores_of_abandoned = []
        scores_of_abandoned_fees = []

    print 'Scoring Good Basket'
    scores_of_good = number_of_good
    log_results(scores_of_good, "good_basket")

    log_stats(scores_of_good, scores_of_error, scores_of_abandoned, scores_of_abandoned_fees, skipped_abandoned)

    error_file = 'error_bucket.json'
    good_file = 'good_bucket.json'

    save_to_json(results=scores_of_error, file_name=error_file)
    save_to_json(results=scores_of_good, file_name=good_file)

    if process_abandoned:
        abandoned_file = 'abandoned_bucket.json'
        abandoned_fee_file = 'abandoned_fee_bucket.json'

        save_to_json(results=scores_of_abandoned, file_name=abandoned_file)
        save_to_json(results=scores_of_abandoned_fees, file_name=abandoned_fee_file)

    if run_prod_cmd:
        print 'Saving Files'
        full_path = create_subdirectory_hdfs_os(save_dir)
        save_hdfs_os(directory_name=full_path, file_name=error_file)
        if process_abandoned:
            save_hdfs_os(directory_name=full_path, file_name=abandoned_file)
            save_hdfs_os(directory_name=full_path, file_name=abandoned_fee_file)
        save_hdfs_os(directory_name=full_path, file_name=good_file)

        df_union = etl_from_hdfs(spark=spark, save_dir=save_dir)
        export_to_hive(df=df_union, hive=hive, HIVE_table=HIVE_table)
        export_to_elastic(df=df_union, spark=spark, ES_nodes=ES_nodes, txn_ES_index=txn_ES_index, 
            txn_ES_type=txn_ES_type, ES_user=ES_user, ES_pass=ES_pass, ES_port=ES_port)

    else:
        print 'Saving Files'
        full_path = create_subdirectory_win_os(save_dir)
        save_win_os(directory_name=full_path, file_name=error_file)
        if process_abandoned:
            save_win_os(directory_name=full_path, file_name=abandoned_file)
            save_win_os(directory_name=full_path, file_name=abandoned_fee_file)
        save_win_os(directory_name=full_path, file_name=good_file)

if __name__ == "__main__":
    run_bucket_results(False)