Please refer to README.docx file for full details

Specify corpus to process inside of config.ini file
Run bracket_txns.py file to produce 3 lists (green, yellow, and red)

to do:
sort within buckets