#!/bin/bash

export START_DATE=$1

#Locations and FileNames for Extracting download and extracting xmls
export LOCAL_TEMP_SAVE_FOLDER='/data/grant_temp'
export LOGPATH='/data/bdr/logs/bdr-grant' #'/data/wsolomon/workspace/projects/U_GRANT_Extractor/logs'
export HDFS_SAVE_FOLDER='/data/target/grant'
export HDFS_SAVE_FN=$1'-grant_text_extraction.json'
export ROOT_PATH='/data/wsolomon/workspace/projects/U_GRANT_Extractor' #'/data/bdr/scripts/bdr-claims'

#For Exporting To HIVE
export HIVE_TABLE='bdr.grant_text_u'

#For Exporting To ES
export ES_nodes='bdr-itwv-tc-2.dev.uspto.gov,bdr-itwv-tc-1.dev.uspto.gov,bdr-itwv-spark-5.dev.uspto.gov,bdr-itwv-spark-4.dev.uspto.gov' 
export grant_ES_index='grant_text_u' 
export grant_ES_type='grant_text' 
export ES_user='elastic'
export ES_pass='changeme'
export ES_port='9200'

#For BDR Job_LOG and Job_control Tables in HIVE
export JOB_NAME="grant"
export JOB_CONTROL_TABLE='bdr.job_control'
export JOB_LOG_TABLE=bdr.job_log
export CREATE_USER_ID='etl'
export LAST_MOD_USER_ID='etl'
export JOB_GROUP='bdr-grant'



RUNDATE=$(date +'%Y%m%d')
JOB=`basename $0`
ES_JAR="/usr/hdp/2.6.1.0-129/zeppelin/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar"

mkdir -p $LOGPATH
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "logs created"
mkdir -p $LOCAL_TEMP_SAVE_FOLDER #mkdir -p $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER
hdfs dfs -mkdir -p $HDFS_SAVE_FOLDER 

echo 'Determining Start Date By HIVE'
JOB_CNTL_TIMESTAMP=$(hive -S -e 'SELECT max(starttime) FROM '"$JOB_LOG_TABLE"' WHERE jobname = "grant" AND status = "completed";')
JOB_CNTL_DATE=${JOB_CNTL_TIMESTAMP:0:10}
JOB_CNTL_TIMESTAMP_FORMATTED=${JOB_CNTL_DATE//"-"/""}

echo "Last TimeStamp Pulled From HIVE bdr.job_control: " $JOB_CNTL_TIMESTAMP_FORMATTED
JOB_CNTL_TIMESTAMP_FORMATTED=$(date --date="${JOB_CNTL_TIMESTAMP_FORMATTED} -14 day" +%Y%m%d)

if (( $START_DATE > 19760000 )); then
  JOB_CNTL_TIMESTAMP_FORMATTED=$START_DATE
elif [ -z ${JOB_CNTL_TIMESTAMP_FORMATTED+x} ]; then
  JOB_CNTL_TIMESTAMP_FORMATTED=19760101
fi

echo "Using a Extraction Start Date of: " $JOB_CNTL_TIMESTAMP_FORMATTED

echo 'Pipeline Running'
#/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $ES_JAR --conf spark.executor.memory=5g --conf spark.driver.memory=5g --conf spark.executor.instances=4 --conf spark.executor.cores=4 --conf spark.yarn.executor.memoryoverhead=10g $ROOT_PATH/1.0-GRANT_Text_Extraction.py
python $ROOT_PATH/1.0-GRANT_Text_Extraction.py 
