'''
To execute:
sudo spark-submit --master yarn --jars /usr/hdp/2.6.1.0-129/spark2/jars/slf4j-log4j12-1.7.16.jar,/usr/hdp/2.6.1.0-129/spark2/jars/slf4j-api-1.7.16.jar --conf spark.executor.memory=25g  --conf spark.driver.memory=12g  --conf spark.executor.instances=4 --conf spark.executor.cores=5 --conf spark.yarn.executor.memoryoverhead=15g PGPUB_Text_Extraction.py
'''
from __future__ import print_function
import sys
import os
#sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
#sys.path.append(os.path.dirname(__file__))
sys.path.append(__file__)
#import requests
#import os
#import zipfile
#import xmltodict
#from bs4 import BeautifulSoup
from tqdm import tqdm
import traceback

import findspark
findspark.init('/usr/hdp/current/spark2-client/')
from pyspark.sql import SparkSession, HiveContext 
from helper import downloadSaveAndUnzip, extractAllXMLs, extractAllTXTs, extractFieldsXML, extractFieldsTXT, loadAppendSaveJSON, \
                    cleanUp, getConfigs, getUrls, export_to_hive, export_to_elastic, update_jobLog_table, update_jobControl_table, backup_hdfs

def main():
    try:
        #start_date, save_location, unzip_location, full_hdfs_fname, export_hive_table_name = getConfigs()

        start_date, save_location, unzip_location, full_hdfs_fname, \
        export_hive_table_name, \
        ES_nodes, grant_ES_index, grant_ES_type, ES_user, ES_pass, ES_port, \
        job_nm, create_user_id, last_mod_user_id, job_control_table, job_group, job_log_table = getConfigs()

        print('Extraction Configs: ')
        print('start_date: ', start_date)
        print('save_location: ', save_location)
        print('unzip_location: ', unzip_location)
        print('full_hdfs_fname: ', full_hdfs_fname)
        print()
        print('HIVE Configs:')
        print('export_hive_table_name :', export_hive_table_name)
        print('job_nm: ', job_nm)
        print('create_user_id: ', create_user_id)
        print('last_mod_user_id: ', last_mod_user_id)
        print('job_control_table: ', job_control_table)
        print('job_group: ', job_group)
        print('job_group: ', job_group)
        print('job_log_table: ', job_log_table)
        print()
        print('Elastic Search Configs:')
        print('ES_nodes: ', ES_nodes)
        print('grant_ES_index: ', grant_ES_index)
        print('grant_ES_type: ', grant_ES_type)
        print('ES_user: ', ES_user)
        print('ES_pass: ', ES_pass)
        print('ES_port: ', ES_port)
        print('job_log_table: ', job_log_table)

        #https://bulkdata.uspto.gov/data/patent/application/multipagepdf/2018/app_pdf_20180809.tar
        spark = SparkSession.builder.appName('GRANT_ETL_check').enableHiveSupport().getOrCreate()
        hive = HiveContext(spark)
        spark.sparkContext.setLogLevel("ERROR")

        download_urls = getUrls(start_date)


        for url in tqdm(download_urls):
            print('Processing: ', url)
            newZipName, newFileName  = downloadSaveAndUnzip(url, saveDir=save_location, unzipDir=unzip_location)

            #newXMLName = downloadSaveAndUnzip(urls[1], saveDir=saveLocation, unzipDir=unzipLocation)
            newExtractFolder =  os.path.join(unzip_location,'extract') #os.path.join(os.path.dirname(newFileName),'extract')#'/data/wsolomon/workspace/data/raw/pgpubBDSS/extract'
            print('newExtractFolder: ', newExtractFolder)
            newFileName_full = os.path.join(unzip_location, newXMLName)
            #print 'Exctracting ',newXMLName,' to: ', newExtractFolder
            if newFileName_full.lower().endswith('.xml'):
                extractAllXMLs(newFileName_full, newExtractFolder)

                #print 'Extracting Fields'
                grant_numsX, pgpubsX, appidsX, titlesX, abstractsX, specsX, claims_allX, \
                    cpcs_allX, citations_allX, uspcs_allX = extractFieldsXML(newExtractFolder)

            elif newFileName_full.lower().endswith('.txt'):
                extractAllTXTs(newFileName_full, newExtractFolder)

                #print 'Extracting Fields'
                grant_numsX, pgpubsX, appidsX, titlesX, abstractsX, specsX, claims_allX, \
                    cpcs_allX, citations_allX, uspcs_allX = extractFieldsTXT(newExtractFolder)


            #print 'Build JSON'
            #full_hdfs_fname = '/user/wsolomon/data/processed/7.4-whs-PGPUB_Text_2015+.json'
            loadAppendSaveJSON(jsonFileName=full_hdfs_fname, spark=spark,
                               grant_nums=grant_numsX, pgpubs=pgpubsX, appids=appidsX, titles=titlesX, abstracts=abstractsX, 
                               specs=specsX, claims_all=claims_allX, cpcs_all=cpcs_allX, citations_all=citations_allX, uspcs_all=uspcs_allX)

            #print('Delete Files')
            cleanUp(newFileName, newZipName, newExtractFolder)

        print('Reading From HDFS')
        df = spark.read.json(full_hdfs_fname).dropDuplicates()
        df_count = df.count()
        
        try:
            fn_backup = os.path.dirname(full_hdfs_fname)+'/*.json'
            print('fn_backup: ', fn_backup)
            df_backup = spark.read.json(fn_backup).dropDuplicates()
            df_backup_count = df_backup.count()
            print('df_backup_count: ', df_backup_count)
            df_full = df.union(df_backup).dropDuplicates()
        except:
            fn_backup = os.path.dirname(full_hdfs_fname)+'/*.json'
            print('No Files in BackUp Folder: ', fn_backup)
            print(traceback.format_exc())
            df_backup_count = 0
            df_full = df

        no_of_recs_processed = df_count
        print('no_of_recs_processed New: ', no_of_recs_processed)
        
        export_to_hive(df=df_full, hive=hive, HIVE_table=export_hive_table_name)

        export_to_elastic(df=df, spark=spark, ES_nodes=ES_nodes,   ES_index=grant_ES_index, 
            ES_type=grant_ES_type, ES_user=ES_user, ES_pass=ES_pass, ES_port=ES_port)


        update_jobLog_table(hive=hive, job_nm=job_nm, job_group=job_group, no_of_recs_processed=no_of_recs_processed, 
            job_log_table=job_log_table, status='completed')

        update_jobControl_table(hive=hive, job_nm=job_nm, create_user_id=create_user_id, 
            last_mod_user_id=last_mod_user_id, job_control_table=job_control_table)

        backup_hdfs(df_unioned=df_full, full_hdfs_fname=full_hdfs_fname)#hdfs_folder=os.path.dirname(full_hdfs_fname))

    except:
        print('#####################')
        print('Grant Pipeline Failed')
        print('#####################')
        print(traceback.format_exc())

        start_date, save_location, unzip_location, full_hdfs_fname, \
        export_hive_table_name, \
        ES_nodes, grant_ES_index, grant_ES_type, ES_user, ES_pass, ES_port, \
        job_nm, create_user_id, last_mod_user_id, job_control_table, job_group, job_log_table = getConfigs()
        
        '''
        print('Reading From HDFS')
        df = spark.read.json(full_hdfs_fname).dropDuplicates()
        df_count = df.count()
        
        try:
            fn_backup = os.path.dirname(full_hdfs_fname)+'/*.json'
            print('fn_backup: ', fn_backup)
            df_backup = spark.read.json(fn_backup).dropDuplicates()
            df_backup_count = df_backup.count()
            print('df_backup_count: ', df_backup_count)
            df_full = df.union(df_backup).dropDuplicates()
        except:
            fn_backup = os.path.dirname(full_hdfs_fname)+'/*.json'
            print('No Files in BackUp Folder: ', fn_backup)
            print(traceback.format_exc())
            df_backup_count = 0
            df_full = df

        no_of_recs_processed = df_count
        print('no_of_recs_processed New: ', no_of_recs_processed)
        
        export_to_hive(df=df_full, hive=hive, HIVE_table=export_hive_table_name)

        export_to_elastic(df=df, spark=spark, ES_nodes=ES_nodes,   ES_index=grant_ES_index, 
            ES_type=grant_ES_type, ES_user=ES_user, ES_pass=ES_pass, ES_port=ES_port)
        '''

        update_jobLog_table(hive=hive, job_nm=job_nm, job_group=job_group, no_of_recs_processed=0, 
            job_log_table=job_log_table, status='FAILED')   

if __name__ == "__main__":
	main()
