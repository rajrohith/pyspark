import requests
import os
import zipfile
import xmltodict
from bs4 import BeautifulSoup
from tqdm import tqdm
import pandas as pd
import glob
import codecs
import datetime
import traceback
import json
import hashlib

def downloadSaveAndUnzip(url, saveDir, unzipDir):
    '''
    Downloads and extracts files from url
    Input: a downloadable url, directory to save the file, and directory to unzip the file to
    
    Output: An unzipped xml file (not returned), and the xml and zip filenames
    '''
    r = requests.get(url)
    downloadFileName = url[-13:]
    saveFileName = os.path.join(saveDir,downloadFileName)

    open(saveFileName, 'wb').write(r.content)

    #unzipDir = '/data/wsolomon/workspace/data/raw/pgpubBDSS'

    zip_ref = zipfile.ZipFile(saveFileName, 'r')
    unzipped_fn = zip_ref.namelist()[0]
    zip_ref.extractall(unzipDir)
    zip_ref.close()
    
    return str(saveFileName), os.path.join(unzipDir, unzipped_fn)

def extractAllXMLs(fileName, newFolder):
    '''
    Extracts each xml doc to its own file from the large unzipped single file
    '''
    os.system('mkdir -p '+ newFolder)
    print 'folder created?: ', os.path.isdir(newFolder)
    
    with codecs.open(fileName, 'r+',  encoding='utf-8') as oldFileName:
        i = 1
        for line in oldFileName:
            new = os.path.join(newFolder, (str(i) +'.xml'))
            with codecs.open(new, 'w',  encoding='utf-8') as newFileName:
                #for line in oldFileName:
                #    if line.strip().startswith('<?xml'):
                #        break
                newFileName.seek(0)
                newFileName.write('<?xml version="1.0" encoding="UTF-8"?>')

                for line in oldFileName:
                    if line.startswith('<!DOCTYPE'):
                        pass

                    if line.startswith('<?xml'):
                        i += 1
                        break
                    newFileName.write(line)
    #os.system('sudo chmod 777 -R '+ newFolder)

def extractAllTXTs(fileName, newFolder):
    '''
    Extracts each txt doc to its own file from the large unzipped single file
    '''
    os.system('mkdir -p '+ newFolder)
    print 'folder created?: ', os.path.isdir(newFolder)
    
    with codecs.open(fileName, 'r+',  encoding='utf-8') as oldFileName:
        i = 1
        for index, line in enumerate(oldFileName):
            new = os.path.join(newFolder, (str(i) +'.txt'))
            with codecs.open(new, 'a',  encoding='utf-8') as newFileName:
                if line.startswith('PATN') & (index > 2):
                    i += 1
                    continue
                newFileName.write(line)
    #os.system('sudo chmod 777 -R '+ newFolder)
    
def extractFieldsXML(folder):
    '''
    Extracts the following fields from each extracted xml doc in the input folder:
    pgpub #, appId #, abstract text, specification text, and claim text
    '''
    grant_nums = []
    titles = []
    pgpubs = []
    appids = []
    abstracts = []
    specs = []
    claims_all = []
    cpcs_all = []
    citations_all = []
    uspcs_all = []

    #new = '/data/wsolomon/workspace/data/raw/pgpubBDSS/new/10.xml'
    for filename in glob.iglob(os.path.join(folder,'*.xml')):
        #print filename
        with open(filename, 'r') as newFile:
            soup = BeautifulSoup(newFile, 'xml')
            
            try:
                desc = soup.find_all('description')  
                specs.append(desc[0].get_text())
            except(Exception):
                desc = 'NA'
                specs.append(desc)
            
            try:
                doc_nums = soup.find_all('doc-number')
                grant_nums.append(doc_nums[0].get_text())
            except(Exception):
                grant_nums.append('NA')
                
            try:
                doc_nums = soup.find_all('doc-number')
                pgpubs.append(doc_nums[1].get_text())
            except(Exception):
                pgpubs.append('NA')
                
            try:
                doc_nums = soup.find_all('doc-number')
                appids.append(doc_nums[2].get_text())
            except(Exception):
                appids.append('NA')
            
            try:
                claims = soup.find_all('claims')
                claims_text = claims[-1].get_text()
                claims_text = claims_text.replace('\n\n\n','XXX').replace('\n','').replace('XXX','\n ')
                claims_all.append(claims_text)
            except(Exception):
                claims_all.append('NA')
                
            try:
                title = soup.find_all('invention-title')
                titles.append(title[0].get_text())
            except:
                titles.append('NA')
            
            try:
                abstract = soup.find_all('abstract')
                abstracts.append(str(abstract[0].get_text()))
            except(Exception):
                abstracts.append('NA')
                
            try:
                cpcs = soup.find('us-field-of-classification-search').find_all_next('classification-cpc-text')
                cpcs = [X.get_text() for X in cpcs]
                cpcs_all.append(cpcs)
            except(Exception):
                cpcs_all.append('NA')
                
            try:
                citations = soup.find('us-references-cited').find_all_next('doc-number')
                #cpcs = cpcs_tag.find_next_all('classification-cpc-text')
                citations = [X.get_text() for X in citations]
                citations_all.append(citations)
            except(Exception):
                citations_all.append('NA')
                
            try:
                uspcs = soup.find('us-field-of-classification-search').find('classification-national').find_all_next('main-classification')
                uspcs = [X.get_text() for X in uspcs]
                uspcs_all.append(uspcs)
            except(Exception):
                uspcs_all.append('NA')

    #os.system('chmod 777 -R ' + folder) 
    return grant_nums, pgpubs, appids, titles, abstracts, specs, claims_all, cpcs_all, citations_all, uspcs_all

def extractFieldsTXT(folder):
    '''
    Extracts the following fields from each extracted txt doc in the input folder:
    grant_nums, pgpubs, app_nums, titles_all, abstracts, specs, claims_all, cpcs_all, citations_all, uspcs_all
    '''
    grant_nums = []
    titles_all = []
    pgpubs = []
    app_nums = []
    abstracts = []
    specs = []
    claims_all = []
    cpcs_all = []
    citations_all = []
    uspcs_all = []

    #new = '/data/wsolomon/workspace/data/raw/pgpubBDSS/new/10.xml'
    for filename in glob.iglob(os.path.join(folder,'*.txt')):
        with open(filename, 'r') as newFile:
            data = newFile.read()
            #if index == 0:
                #print 'here'
            

            try:
                ab_start = 'ABST'
                ab_end = 'BSUM'
                abstract = data[data.index(ab_start):data.index(ab_end)] \
                    .split('PAL  ')[-1].replace('\r', ' ').replace('\n', ' ').replace('  ','')
            except(Exception):
                abstract = 'NA'
            
            try:
                spec_start = 'BSUM'
                spec_end = 'CLMS'
                spec = data[data.index(spec_start):data.index(spec_end)] \
                    .replace('\r', ' ').replace('PAR',' ').replace('PAC', ' ').replace('  ','')#.replace('\n', ' ')
            except(Exception):
                spec='NA'
                
            try:
                clm_start = 'CLMS'
                clm_end = 'PATN'
                claims = data[data.index(clm_start):] \
                    .replace('\r', ' ').replace('PA1',' ').replace('CLMS',' ').replace('PAR', ' ').replace('  ','')#.replace('\n', ' ')
            except(Exception):
                claims='NA'

            try:
                grant_start = 'APN'
                grant_end = 'APT'
                grant_num = data[data.index(grant_start):data.index(grant_end)] \
                    .replace('\r', ' ').replace('APN',' ').replace('\n', ' ').strip()
            except(Exception):
                grant_num='NA'
                
            try:
                app_start = 'WKU'
                app_end = 'SRC'
                app_num = data[data.index(app_start):data.index(app_end)] \
                    .replace('\r', ' ').replace('WKU',' ').replace('\n', ' ').strip()
            except(Exception):
                app_num='NA'  
                
            try:
                title_start = 'TTL'
                title_end = 'ISD'
                title = data[data.index(title_start):data.index(title_end)] \
                    .replace('\r', ' ').replace('TTL',' ').replace('\n', ' ').strip()
            except(Exception):
                title='NA'

            try:
                uspc_start = 'OCL'
                uspc_end = 'XCL'
                uspc = data[data.index(uspc_start):data.index(uspc_end)] \
                    .replace('\r', ' ').replace('OCL',' ').replace('\n', ' ').strip()
            except(Exception):
                uspc='NA'  
            
            try:
                cit_start = 'UREF'
                cit_end = 'ABST'
                citation_extract = data[data.index(cit_start):data.index(cit_end)].split('UREF')
                citations = []
                for cit in citation_extract:
                    try:
                        cit_extract = cit[cit.index('PNO'):cit.index('ISD')].replace('\r', ' ').replace('PNO',' ').replace('\n', ' ').strip()
                        citations.append(cit_extract)
                    except:
                        pass
            except(Exception):
                citations='NA'  
        
        
        
        abstracts.append(abstract)  
        specs.append(spec)
        claims_all.append(claims)
        grant_nums.append(grant_num)
        app_nums.append(app_num)
        titles_all.append(title)
        pgpubs.append('NA') #No PGPUB Num in this data
        cpcs_all.append('NA') #No CPCs in this data
        citations_all.append(citations)
        uspcs_all.append(uspc)
        #os.system('chmod 777 -R ' + folder) 
        
    return grant_nums, pgpubs, app_nums, titles_all, abstracts, specs, claims_all, cpcs_all, citations_all, uspcs_all

def loadAppendSaveJSON(jsonFileName, spark, grant_nums, pgpubs, appids, titles, abstracts, specs, claims_all, cpcs_all, citations_all, uspcs_all):
    '''
    Loads and appends the JSON file with the input extracted data and then pushes the concatinated JSON to hdfs
    '''
    if os.path.isfile(jsonFileName):
        #df_load = pd.read_json(jsonFileName)
        #df_load = spark.read.json(jsonFileName)
        overwrite = True
    else:
        #print 'Creating First JSON'
        #df_load = pd.DataFrame()
        overwrite = False
    def convert_list(input_list):
        if type(input_list[0]) == list:
            ouput_list = [list(X) for X in input_list]
        elif type(input_list[0]) == str:
            ouput_list = [[str(X)] for X in input_list]
        return ouput_list

    df_new = pd.DataFrame()
    df_new['grant'] = grant_nums
    df_new['pgpub'] = pgpubs
    df_new['appId'] = appids
    df_new['title'] = titles
    df_new['abstract'] = abstracts
    df_new['spec'] = specs
    df_new['claims'] = claims_all
    df_new['cpcs'] = convert_list(cpcs_all)
    df_new['citations'] = convert_list(citations_all)
    df_new['uspcs'] = convert_list(uspcs_all)

    #df_spark_new = spark.createDataFrame(df_new)



    try:
        mySchema = StructType([StructField('grant', StringType(), True), StructField('pgpub', StringType(), True), \
            StructField('appId', StringType(), True), StructField('title', StringType(), True), StructField('abstract', StringType(), True), \
            StructField('spec', StringType(), True), StructField('claims', StringType(), True), \
            StructField('cpcs', ArrayType(StringType()), True), StructField('citations', ArrayType(StringType()), True), StructField('uspcs', ArrayType(StringType()), True)
        ])
        df_spark_new = spark.createDataFrame(df_new, schema=mySchema)
    except:
        df_spark_new = spark.createDataFrame(df_new)
    #df_spark_new.printSchema()
    #df_spark_new.show()
    
    #df_concat = pd.concat([df_load, df_new])
    #df_concat.to_json(jsonFileName, orient='records')
    #os.system('hdfs dfs -put -f '+ jsonFileName + ' ' + hdfsLocation)
    #df_concat = df_load.union(df_spark_new)
    
    try:
        df_spark_new.write.json(jsonFileName, mode = 'append')
    except(Exception):
        print 'Createing New JSON in HDFS'
        df_spark_new.write.json(jsonFileName)

def cleanUp(zipFileName, xmlFileName, newExtractFolder):
    #os.system('chmod 777 -R /data/wsolomon/workspace/data/raw/pgpubBDSS')
    os.system('rm '+ zipFileName)
    os.system('rm '+ xmlFileName)
    os.system('rm -rf '+ newExtractFolder)

def getConfigs():
    start_date = os.environ['START_DATE'] #20100801
    save_location = os.path.join(os.environ['ROOT_PATH'], os.environ['LOCAL_TEMP_SAVE_FOLDER'])#'/data/wsolomon/workspace/projects/U_PGPUB_Extractor/data/pgpubBDSS'
    unzip_location = os.path.join(os.environ['ROOT_PATH'], os.environ['LOCAL_TEMP_SAVE_FOLDER'])
    full_hdfs_fname = str(os.path.join(os.environ['HDFS_SAVE_FOLDER'], os.environ['HDFS_SAVE_FN'])) #'/data/target/pgpub/7.4-whs-PGPUB_Text_2015+_TEST.json'
    
    export_hive_table_name = os.environ['HIVE_TABLE']

    ES_nodes = os.environ['ES_nodes']
    grant_ES_index = os.environ['grant_ES_index']
    grant_ES_type = os.environ['grant_ES_type']
    ES_user = os.environ['ES_user']
    ES_pass = os.environ['ES_pass']
    ES_port = os.environ['ES_port']

    job_nm = os.environ['JOB_NAME']
    create_user_id = os.environ['CREATE_USER_ID']
    last_mod_user_id = os.environ['LAST_MOD_USER_ID']
    job_control_table = os.environ['JOB_CONTROL_TABLE']
    job_group = os.environ['JOB_GROUP']
    job_log_table = os.environ['JOB_LOG_TABLE']

    return start_date, save_location, unzip_location, full_hdfs_fname, \
            export_hive_table_name, \
            ES_nodes, grant_ES_index, grant_ES_type, ES_user, ES_pass, ES_port, \
            job_nm, create_user_id, last_mod_user_id, job_control_table, job_group, job_log_table


def getUrls(start_date):
    start_year = int(str(start_date)[0:4])
    stop_year = int(datetime.datetime.now().year)+1
    years = [str(X)+'/' for X in range(start_year, stop_year)]
    urls = []
    for year in years:
        url = 'https://bulkdata.uspto.gov/data/patent/grant/redbook/fulltext/'+year
        data = requests.get(url, allow_redirects=True)
        data.content
        soup = BeautifulSoup(data.content, 'lxml')
        for link in soup.find_all('a', href=True):
            if (link['href'].startswith('ip')) | (link['href'].startswith('pa')) | (link['href'].startswith('pft')):
                try:
                    if int(str(20)+link['href'][3:9]) > int(str(start_date)[-8:]):
                        urls.append(url+link['href'])
                except:
                    if int(link['href'][-17:-9]) > int(str(start_date)[-8:]): #Fro Post 2000 dates

                        urls.append(url+link['href'])
    return urls

def export_to_hive(df, hive, HIVE_table):
    print 'Exporting to Hive'
    hive.sql("DROP TABLE IF EXISTS " + HIVE_table)
    df.createOrReplaceTempView("grant_U_temp")
    hive.sql("CREATE TABLE IF NOT EXISTS " + HIVE_table + " STORED AS ORC  AS SELECT * from grant_U_temp")
    #hive.sql("INSERT INTO bdr.application_txn_score  SELECT * from application_txn_score_temp")
    print 'Exported {} Records to Hive'.format(df.count())

def export_to_elastic(df, spark, ES_nodes, ES_index, ES_type, ES_user, ES_pass, ES_port):
    #df_mdr = spark.read.table('bdr.appmdr')
    #df_trx = spark.read.table('bdr.application_txn_score')
    #df_joined = df_trx.join(df_mdr, on='patentApplicationNumber')
    #df_joined = df.join(df_mdr, on='patentApplicationNumber')
    #cols = ['patentApplicationNumber','groupArtUnitNumber', 'workGroup', 'techCenter', 'examinerEmployeeNumber', 
    #        'filingDate', 'grantDate', 'nationalClass', 'nationalSubclass', 'bucketType', 'score', 'messages','trxHistory','id'] 
    #df_final = df_joined.select(cols)

    #df_final = df_final.withColumnRenamed('workGroup', 'workGroupNumber').withColumnRenamed('techCenter', 'techCenterNumber')
    #df_final = df_final.withColumn('filingDate', from_unixtime(timestamp=unix_timestamp(timestamp='filingDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))
    #df_final = df_final.withColumn('grantDate', from_unixtime(timestamp=unix_timestamp(timestamp='grantDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))

    rdd_mapped = df.rdd.map(lambda y: y.asDict())

    def package(doc):
        _json = json.dumps(doc)
        keys = doc.keys()
        for key in keys:
            if doc[key] == 'null' or doc[key] == 'None':
                del doc[key]
        if not doc.has_key('id'):
            id = hashlib.sha224(_json).hexdigest()
            doc['id'] = id
        else:
            id = doc['id']
        _json = json.dumps(doc)
        return (id, _json)
     
    exportRDD = rdd_mapped.map(package)

    print 'Exporting to Elastic Search'
    
    try:
        exportRDD.saveAsNewAPIHadoopFile(
            path='-', 
            outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
            keyClass="org.apache.hadoop.io.NullWritable",  
            valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
            conf={ "es.resource" : ES_index + "/" + ES_index, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
                "es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
                "es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port": ES_port, "es.net.ssl":"true"})
        print 'Exported {} Records to Elastic Search'.format(df.count())
    except Exception as ex:
        print traceback.format_exc()

def update_jobLog_table(hive, job_nm, job_group, no_of_recs_processed, job_log_table, status):
    
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    '''
    Modify Job Log table: 
    root
     |-- jobgroup: string (nullable = true)
     |-- jobname: string (nullable = true)
     |-- starttime: timestamp (nullable = true)
     |-- endtime: timestamp (nullable = true)
     |-- status: string (nullable = true)
     |-- comments: string (nullable = true)
     |-- no_of_recs_processed: integer (nullable = true)
     '''
    insert_values = (job_group, job_nm, 
                start_time, end_time,
                status, 'No. of New GRANT documents pushed to elastic', 
                no_of_recs_processed)
    print('Values to Insert into bdr.job_log Table: ', insert_values)
    hive.sql("INSERT INTO TABLE " + str(job_log_table) + " VALUES " + str(insert_values))

def update_jobControl_table(hive, job_nm, create_user_id, last_mod_user_id, job_control_table):
    '''
    Modify Job Control Table
    root
     |-- job_nm: string (nullable = true)
     |-- loaded_dt: timestamp (nullable = true)
     |-- create_ts: timestamp (nullable = true)
     |-- create_user_id: string (nullable = true)
     |-- last_mod_ts: timestamp (nullable = true)
     |-- last_mod_user_id: string (nullable = true)
    '''
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    insert_values = (job_nm, start_time,
                end_time, create_user_id,
                end_time, last_mod_user_id)
    print('Values to Insert into bdr.job_control Table: ', insert_values)
    hive.sql("INSERT INTO TABLE " + str(job_control_table) + " VALUES " + str(insert_values))

def backup_hdfs(df_unioned, full_hdfs_fname):#hdfs_folder):
    #Move Current HDFS Folder to _bak
    hdfs_folder=os.path.dirname(full_hdfs_fname)
    os.system('hdfs dfs -mkdir -p ' + hdfs_folder + '_bak')
    fn_write = os.path.join(os.path.dirname(full_hdfs_fname)+'_bak/', full_hdfs_fname.split('/')[-1])
    print('fn_write: ', fn_write)
    try:
        df_unioned.write.json(fn_write)#hdfs_folder + '_bak')
    except:
        df_unioned.write.json(fn_write)#hdfs_folder + '_bak', mode='append')
    #df_bak = spark.read.json(hdfs_folder+_'bak/*.json')
    #df_bak_full = df.join(df_bak, on='appId', how='outer')dropDuplicates()
    #df_bak_full.spark.write(hdfs_folder+'_bak')
    #os.system('hdfs dfs -cp -f ' + hdfs_folder + '/* ' + hdfs_folder + '_bak')
    os.system('hdfs dfs -rm -r -f ' + hdfs_folder)
    #os.system('hdfs dfs -mv ' + hdfs_folder+'_bak '+ hdfs_folder)
    print('Backed-Up ', hdfs_folder, ' to ', hdfs_folder+'_bak')