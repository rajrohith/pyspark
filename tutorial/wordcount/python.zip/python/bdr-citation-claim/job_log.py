 
from pyspark.sql import SparkSession
import sys
job_group = sys.argv[1]
job_name = sys.argv[2]
status = sys.argv[3]
date = sys.argv[4]
date_new = date.replace("$"," ")

spark = SparkSession.builder.appName("Job Log").enableHiveSupport().getOrCreate()
print(job_name + " " + status + " " + date_new )
if status=='completed' and job_name=='palm-private':
 privatedf=spark.sql("select 1 AS Numberofprivateappids from bdr.application_private where apptype='private'")
 
 sqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of private appids',"+str(privatedf.count()) 
 
else:
 sqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"',NULL,0 " 
 
spark.sql(sqlstring)

spark.stop()