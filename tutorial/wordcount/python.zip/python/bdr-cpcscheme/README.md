# CPC Definition Pipeline!

## Overview

This pipeline goes through the following steps for the date range(s) specified. 

1. `cpcscheme.sh` exports enviornmental varibales and manages the process
2. `cpcscheme.py` is run with file input argument as defined in properties`.
3. The `.csv` or `.json` is pushed to Hadoop (Folder specified as vairable in data/input)
7. `3-es_push.py` reads all csvs from hdfs, chen pushes the final dataframe to elastic search

NOTE that all logs are saved in a log folder location variable specified in the `cpcscheme.sh` 

## To Run:
1. Download the Full Code From the Source Control Repository
2. Confirm the correct permissions for this folder (sudo chmod 777 -R /root)
3. Enter and confirm the hard coded variables in `cpcscheme.properties`


Example 1: "sh cpcscheme.sh" 
E

**NOTE To do a full data import, **

## Requirements To Install:

### Server

### Python Packages
mechanize
cookielib
bs4