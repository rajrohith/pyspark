from __future__ import print_function
from pyspark.sql import SparkSession, HiveContext, SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import datetime
import csv
import hashlib
import traceback
import os
import sys
import ConfigParser
import json


spark = SparkSession \
    .builder \
    .appName("cpcscheme") \
    .enableHiveSupport()\
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

hive = HiveContext(spark)

start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')



config_path = os.environ['ROOT_SCRIPT_PATH']

config = ConfigParser.RawConfigParser()
config.read(os.path.join(config_path,'cpcscheme.properties'))

ES_nodes = config.get('elastic','ES_nodes')
ES_index = config.get('elastic','ES_index')
ES_type = config.get('elastic','ES_type')
ES_user = config.get('elastic','ES_user')
ES_pass = config.get('elastic','ES_pass')
#local_folder = os.environ['dropLocation']#config.get('elastic','local_folder')
hdfs_folder = os.environ['hdfsDropLocation']#config.get('elastic','hdfs_folder')
ES_port = config.get('elastic','ES_port')


#Load df
df = spark.read.csv(hdfs_folder + '/*.csv', header=True)
fn_json = hdfs_folder + '/*.json'
df_json = spark.read.json(fn_json)

df_clean = df.filter(col('CPC') != '"')


#Format for ES Push
cpcRDD = df_clean.rdd.map(lambda y: y.asDict())

def package(doc):
	_json = json.dumps(doc )
        '''
        Creates an rdd of tuples from a dataframe:
        (hash_id, dictionary_of_rdd)
        '''
	keys = doc.keys()
        for key in keys:
		if doc[key] == 'null' or doc[key] == 'None':
			del doc[key]
	if not doc.has_key('id'):
		id = hashlib.sha224(_json).hexdigest()
		doc['id'] = id
	else:
		id = doc['id']
	_json = json.dumps(doc)
	return (id, _json)
     
exportRDD = cpcRDD.map(package)

try:
	exportRDD.saveAsNewAPIHadoopFile(
		path='-', 
		outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
		keyClass="org.apache.hadoop.io.NullWritable",  
		valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
		conf={ "es.resource" : ES_index + '/' + ES_type, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
			"es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
			"es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port": ES_port, "es.net.ssl":"true"})
except Exception as ex:
	print(traceback.format_exc())
	pass

