#!/usr/bin/env python
"""
Generates a shell script that downloads PATFT files from bulkdata.uspto.gov. The
generated shell script uses wget to download the files.
"""
from cookielib import LWPCookieJar
from mechanize import Browser
from re import compile as re_compile
import sys
from sys import stdout
from time import sleep
import os
from datetime import datetime

cj = LWPCookieJar()
temp_dl_folder = os.path.join(os.environ['ROOT_PATH'], 
                        os.environ['LOCAL_TEMP_SAVE_FOLDER'])
dl_fn = os.path.join(temp_dl_folder, os.environ['TEMP_DL_FN'])
print 'Folder to Donwload To: ', dl_fn

if int(str(sys.argv[1])[0:4]) > 1900:
    dl_start_year = int(str(sys.argv[1])[0:4])
else:
    print 'Start Date Argument Not Accepted. Correct Format is: YYYYMMDD'
    dl_start_year = 2000
dl_stop_year = int(datetime.now().year) + 1

print 'Data To Be Scraped From {} to {}'.format(dl_start_year, dl_stop_year)

def remove_dl_file():
    os.system('sudo rm -f ' + dl_fn)

def get_browser():
    # global cj
    cj = LWPCookieJar()
    br = Browser()
    br.set_cookiejar(cj)
    br.set_handle_robots(False)
    br.addheaders = [('User-agent', 'Mozilla/5.0 (X11; U; Linux i686; en-US; '
                      'rv:1.9.0.1 Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox'
                      '/3.0.1')]
    return br


def main():
    """Main program."""
    remove_dl_file()
    re_patft = re_compile(r'(i?pg\d{6}|pftaps\d{8}_wk\d\d)\.zip')
    browser = get_browser()
    out = stdout
    print >> out, '#!/bin/bash'
    lines = ['#!/bin/bash']
    patft_url_tpl = 'https://bulkdata.uspto.gov/data/patent/grant/redbook/fulltext/%s/'
    for year in range(dl_start_year, 2019):
        print 'Defining Download Links for year:', year
        sleep(2)
        patft_url = patft_url_tpl % (year,)
        response = browser.open(patft_url)
        links = list(browser.links(text_regex=re_patft))
        for link in links:
            lines.append('[ -f %s ] || (sleep 2; wget -P %s -nc "%s%s")' % (
                link.text, temp_dl_folder, patft_url, link.url))
    lines.sort()
    for line in lines:
        print >> out, line
        with open(dl_fn, 'a') as fn:
            fn.write(line + '\n')

    return
if __name__ == "__main__":
    main()
