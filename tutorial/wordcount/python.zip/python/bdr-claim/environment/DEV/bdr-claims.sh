#!/bin/bash


export TEMP_DL_FN='links_to_dl.sh'
export LOCAL_TEMP_SAVE_FOLDER='data'
export LOGPATH='/data/bdr/logs/bdr-claims'
export HDFS_SAVE_FOLDER='/data/target/claims'
export ROOT_PATH='/data/bdr/scripts/bdr-claims'
export JOB_NAME="claims"
export JOB_CONTROL_TABLE='bdr.job_control'
export JOB_LOG_TABLE=bdr.job_log

START_DATE=$1
RUNDATE=$(date +'%Y%m%d')
JOB=`basename $0`
ES_JAR="/usr/hdp/2.6.1.0-129/zeppelin/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar"

mkdir -p $LOGPATH
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "logs created"
mkdir -p $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER
hdfs dfs -mkdir -p $HDFS_SAVE_FOLDER 

echo '1. Get Download List'
python $ROOT_PATH/1-dl_patft.py $START_DATE

echo '2. Download to LOCAL_TEMP_SAVE_FOLDER'
sh $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/$TEMP_DL_FN

echo '3. Generate CSVs by extracting Claims'
for fn in $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/*.zip; do
    echo 'Processing ' $fn
    python $ROOT_PATH/2-extract_patft_claims.py $fn
done

echo '4. Unzip and Push to HDFS'

for fn in $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/*claims.csv.gz; do
	STEM=$(basename "${fn}" .gz)
	echo $STEM
	gunzip -c "$fn" > $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/"${STEM}"

    echo 'Moving ' $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/"${STEM}" 'to HDFS: ' $HDFS_SAVE_FOLDER
    hdfs dfs -put $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/"${STEM}" $HDFS_SAVE_FOLDER
    #rm $ROOT_PATH/$LOCAL_TEMP_SAVE_FOLDER/"${STEM}"
done

echo '5. Push CSVs to HDFS, concatinate, and Push to Elastic Search'
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $ES_JAR --conf spark.executor.memory=5g --conf spark.driver.memory=5g --conf spark.executor.instances=4 --conf spark.executor.cores=4  $ROOT_PATH/3-es_push.py
#--conf spark.yarn.executor.memoryoverhead=10g
#5. Delete Slop