from __future__ import print_function
from pyspark.sql import SparkSession, HiveContext, SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import datetime
import json
import hashlib
import traceback
import os
import sys
import ConfigParser

def package(doc):
	'''
	Creates an rdd of tuples from a dataframe:
	(hash_id, dictionary_of_rdd)
	'''
	_json = json.dumps(doc )
	keys = doc.keys()
	for key in keys:
		if doc[key] == 'null' or doc[key] == 'None':
			del doc[key]
	if not doc.has_key('id'):
		id = str(doc['appl_id']) + str(doc['claim_no'])
		doc['id'] = id
	else:
		id = doc['id']
	_json = json.dumps(doc)
	return (id, _json)

def main():
	try:
		spark = SparkSession \
		    .builder \
		    .appName("Claims_ETL_automation ") \
		    .enableHiveSupport()\
		    .getOrCreate()

		spark.sparkContext.setLogLevel("ERROR")

		hive = HiveContext(spark)

		start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		config_path = os.environ['ROOT_PATH']

		config = ConfigParser.RawConfigParser()
		config.read(os.path.join(config_path,'bdr-claims.properties'))

		ES_nodes = config.get('elastic','ES_nodes')
		ES_index = config.get('elastic','ES_index')
		ES_type = config.get('elastic','ES_type')
		ES_user = config.get('elastic','ES_user')
		ES_pass = config.get('elastic','ES_pass')
		#local_folder = os.environ['dropLocation']#config.get('elastic','local_folder')
		hdfs_folder = os.environ['HDFS_SAVE_FOLDER']#config.get('elastic','hdfs_folder')
		ES_port = config.get('elastic','ES_port')

		job_name = os.environ['JOB_NAME'] #config.get('elastic','jobControl-job_name')
		create_job_id = config.get('elastic','jobControl-create_job_id')
		create_user_id = config.get('elastic','jobControl-create_user_id')
		last_mod_user_id = config.get('elastic','jobControl-last_mod_user_id')
		job_control_table = os.environ['JOB_CONTROL_TABLE']
		job_group = config.get('elastic', 'jobLog-jobGroup')
		job_log_table = os.environ['JOB_LOG_TABLE']

		#Put Extracted JSON into HDFS:
		#os.system('sudo hdfs dfs -put ' + local_folder   + ' ' + hdfs_folder )

		#Load df
		df_new = spark.read.csv(hdfs_folder + '/*.csv', header=True).dropDuplicates()

		no_of_recs_processed = df_new.count()

		#Format for ES Push
		#df_new = df_new.toDF(*([c.title().replace('_', '') for c in df.columns]))
		#df_new = df_new.toDF(*([(c[0].lower()+c[1:]) for c in df_new.columns]))
		claimsCsvRDD = df_new.rdd.map(lambda y: y.asDict())

		exportRDD = claimsCsvRDD.map(package)

		print('# of records being pushed to ES: ', no_of_recs_processed)

		try:
			exportRDD.saveAsNewAPIHadoopFile(
				path='-', 
				outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
				keyClass="org.apache.hadoop.io.NullWritable",  
				valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
				conf={ "es.resource" : ES_index + '/' + ES_type, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
					"es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
					"es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port": ES_port, "es.net.ssl":"true"})
			print('Exported ', df_new.count(), ' records to Elastic Search Index: ', ES_index, '/', ES_type)
		except Exception as ex:
			print(traceback.format_exc())
			pass

		#Move Current HDFS Folder to _bak
		os.system('hdfs dfs -rm -r -f ' + hdfs_folder + '_bak')
		os.system('hdfs dfs -mv ' + hdfs_folder + ' ' + hdfs_folder + '_bak')

		print('Backed-Up ', hdfs_folder, ' to ', hdfs_folder, '_bak')
		
		end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		'''
		Modify Job Log table: 
		root
		 |-- jobgroup: string (nullable = true)
		 |-- jobname: string (nullable = true)
		 |-- starttime: timestamp (nullable = true)
		 |-- endtime: timestamp (nullable = true)
		 |-- status: string (nullable = true)
		 |-- comments: string (nullable = true)
		 |-- no_of_recs_processed: integer (nullable = true)
		 '''
		insert_values = (job_group, job_name, 
					start_time, end_time,
					'completed', 'No.of CLAIMS documents pushed to elastic', 
					no_of_recs_processed)
		print('Values to Insert into bdr.job_log Table: ', insert_values)
		hive.sql("INSERT INTO TABLE " + str(job_log_table) + " VALUES " + str(insert_values))


		'''
		Modify Job Control Table
		root
		 |-- job_nm: string (nullable = true)
		 |-- loaded_dt: timestamp (nullable = true)
		 |-- create_ts: timestamp (nullable = true)
		 |-- create_user_id: string (nullable = true)
		 |-- last_mod_ts: timestamp (nullable = true)
		 |-- last_mod_user_id: string (nullable = true)
		'''

		insert_values = (job_name,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
					datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),create_user_id,
					datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),last_mod_user_id)
		print('Values to Insert into bdr.job_control Table: ', insert_values)
		hive.sql("INSERT INTO TABLE " + str(job_control_table) + " VALUES " + str(insert_values))

	except Exception:
		print('##########################')
		print('##Claims Pipeline Failed##')
		print('##########################')

		start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

		config_path = os.environ['ROOT_PATH']

		config = ConfigParser.RawConfigParser()
		config.read(os.path.join(config_path,'bdr-claims.properties'))

		ES_nodes = config.get('elastic','ES_nodes')
		ES_index = config.get('elastic','ES_index')
		ES_type = config.get('elastic','ES_type')
		ES_user = config.get('elastic','ES_user')
		ES_pass = config.get('elastic','ES_pass')
		#local_folder = os.environ['dropLocation']#config.get('elastic','local_folder')
		hdfs_folder = os.environ['HDFS_SAVE_FOLDER']#config.get('elastic','hdfs_folder')
		ES_port = config.get('elastic','ES_port')

		job_name = os.environ['JOB_NAME'] #config.get('elastic','jobControl-job_name')
		create_job_id = config.get('elastic','jobControl-create_job_id')
		create_user_id = config.get('elastic','jobControl-create_user_id')
		last_mod_user_id = config.get('elastic','jobControl-last_mod_user_id')
		job_control_table = os.environ['JOB_CONTROL_TABLE']
		job_group = config.get('elastic', 'jobLog-jobGroup')
		job_log_table = os.environ['JOB_LOG_TABLE']

		no_of_recs_processed = 0

		insert_values = (job_group, job_name, 
					start_time, end_time,
					'failed', 'No.of CLAIMS documents pushed to elastic', 
					no_of_recs_processed)
		print('Values to Insert into bdr.job_log Table: ', insert_values)
		hive.sql("INSERT INTO TABLE " + str(job_log_table) + " VALUES " + str(insert_values))
		print(traceback.format_exc())

	

if __name__ == '__main__':
	main()