# Claims Extraction Pipeline!

## Overview

This pipeline goes through the following steps for the date range(s) specified. 

1. `bdr-claims.sh` exports enviornmental varibales and manages the process
2. `1-dl_patft.py` is run with any start_date argument passed through.
3. A `links_to_dl.sh` script is created with the wget commands and links
4. `links_to_dl.sh` downloads to a exported variable folder location (default is root/data)
5. Each downloaded zip file is parsed by `2-extract_patft_claims.py` and the following output files are saved:
- zipFileName_meta.log
- zipFileName_meta.csv.gz
- zipFileName_claims.log
- zipFileName_claims.csv.gz
6. The `zipFileName_claims.csv.gz` is unzipped and pushed to Hadoop (Folder specified as vairable in bdr-claims)
7. `3-es_push.py` reads all csvs from hdfs, concatinates together, and then pushes the final dataframe to elastic search

NOTE that all logs are saved in a log folder location variable specified in the `bdr-claims.sh` 

## To Run:
1. Download the Full Code From the Source Control Repository
2. Confirm the correct permissions for this folder (sudo chmod 777 -R /root)
3. Enter and confirm the hard coded variables in `config.properties`
4. Enter and confirm the hard coded variables in `bdr-ptab.sh`
5. Run script with `sh bdr-claims.sh *ARG*` If you wish to extract from a certain date range, you can specify it as an argument (YYYYMMDD). Otherwise, the extraction date range will start with the most recent timestamp in the bdr.job_control table in HIVE.

Example 1: "sh bdr-claims.sh 20180101" scrapes all PTAB pdfs from 01-01-2018 to Today
Example 2: "sh bdr-claims.sh" scrapes all PTAB pdfs from the most recent date in `bdr.job_control` Hive table to Today

**NOTE To do a full data import, use start date: 19760101 or earlier**

## Requirements To Install:

### Server

### Python Packages
mechanize
cookielib
bs4