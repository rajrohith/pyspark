#!/usr/bin/env python
"""Extracts claims from PATFT "pftaps," "pg" and/or "ipg" zip archives."""

__author__ = 'rkimble'

from argparse import ArgumentParser
from collections import defaultdict
from csv import DictWriter, field_size_limit
from datetime import datetime
from glob import glob
from gzip import GzipFile
from os import remove
from os.path import basename, isfile, splitext
from re import compile as re_compile
from string import whitespace
from sys import stdout
from zipfile import is_zipfile, ZipFile
from bs4 import BeautifulSoup
import pprint

from claims_common import format_number, time_stamp_message, get_deps
from claims_common import safe_decode, safe_encode, standardize_whitespace
from claims_common import pat8to7


field_size_limit(64 * 1024 * 1024)


def get_args():
    """
    Parses the command line arguments.
    :return: args
    """
    parser = ArgumentParser(description='Extract claims from APPFT PA zip files.')
    parser.add_argument('zip_files', metavar='zipfn', type=str, nargs='+',
                        help='a zip file name')
    parser.add_argument('-f', '--force', dest='force', action='store_true',
                        default=False, help='force overwrite of existing output files')
    args = parser.parse_args()
    return args


def split_into_docs_pftaps(file_ptr):
    """
    Reads the data from the file referenced by the argument and generates
    individual XML documents parsed by BeautifulSoup.
    :param file_ptr: a file opened for reading
    :return: an XML document
    """
    global xml_ct
    global claims_log_fp
    xml_ct = 0
    lines = []
    no_patn_so_far = True
    for line in file_ptr:
        line = line.rstrip()
        if line == 'PATN':
            no_patn_so_far = False
            xml_ct += 1
            if lines:
                yield lines
            lines = [line]
        elif no_patn_so_far:
            continue
        else:
            lines.append(line)
    if lines:
        yield lines


def split_into_docs_pg(file_ptr):
    """
    Reads the data from the file referenced by the argument and generates
    individual XML documents parsed by BeautifulSoup.
    :param file_ptr: a file opened for reading
    :return: an XML document
    """
    global xml_ct
    global claims_log_fp
    xml_ct = 0
    lines = []
    for line in file_ptr:
        if str == type(line):
            line = safe_decode(line)
        if line.strip().startswith(u'<?xml'):
            xml_ct += 1
            if lines:
                if u'</PATDOC>' == lines[-1].strip():
                    # Only process patent applications. Ignore sequences.
                    yield u''.join(lines)
                else:
                    for line2 in lines:
                        claims_log_fp.write(line2)
            lines = []
        if line.strip():
            lines.append(line)
    if lines:
        if u'</PATDOC>' == lines[-1].strip():
            # Only process patent applications. Ignore sequences.
            yield u''.join(lines)
        else:
            for line2 in lines:
                claims_log_fp.write(line2)


def split_into_docs_ipg(file_ptr):
    """
    Reads the data from the file referenced by the argument and generates
    individual XML documents to be parsed by BeautifulSoup.
    :param file_ptr: a file opened for reading
    :return: an XML document
    """
    global xml_ct
    global claims_log_fp
    xml_ct = 0
    lines = []
    for line in file_ptr:
        if type(line) == type(''):
            line = safe_decode(line)
        if line.strip().startswith(u'<?xml'):
            xml_ct += 1
            if lines:
                if u'</us-patent-grant>' == lines[-1].strip():
                    # Only process patent applications. Ignore sequences.
                    yield u''.join(lines)
                elif u'</sequence-cwu>' == lines[-1].strip():
                    # Only process patent applications. Ignore sequences.
                    pass
                else:
                    for line2 in lines:
                        claims_log_fp.write(line2)
            lines = []
        if line.strip():
            lines.append(line)
    if lines:
        if u'</us-patent-grant>' == lines[-1].strip():
            # Only process patent applications. Ignore sequences.
            yield u''.join(lines)
        elif u'</sequence-cwu>' == lines[-1].strip():
            # Only process patent applications. Ignore sequences.
            pass
        else:
            for line2 in lines:
                claims_log_fp.write(line2)


def split_into_sections(file_ptr):
    """
    Reads the data from the file referenced by the argument and generates
    individual XML documents parsed by BeautifulSoup.
    :param file_ptr: a file opened for reading
    :return: a BeautifulSoup instance
    """
    for doc in split_into_docs_pftaps(file_ptr):
        sections = defaultdict(list)
        pat_no = ''
        iss_dt = ''
        series_cd = ''
        appl_no = ''
        appl_id = ''
        file_dt = ''
        no_clms = 0
        appl_ty = ''
        pub_lvl = ''
        section = None
        for line in doc:
            line = line.rstrip()
            sections['doc'].append(line)
            if 4 == len(line) and not ' ' in line:
                section = line
            elif None == section:
                continue
            else:
                sections[section].append(line)
                if 'PATN' == section:
                    if line.startswith('WKU  '):
                        pat_no = line[5:13]
                    elif line.startswith('ISD  '):
                        iss_dt = line[5:13]
                        try:
                            iss_dt = datetime.strptime(iss_dt, '%Y%m%d'
                                ).isoformat()[:10]
                        except:
                            iss_dt = ''
                    elif line.startswith('SRC  '):
                        series_cd = line[5]
                    elif line.startswith('APN  '):
                        appl_no = line[5:11]
                    elif line.startswith('APT  '):
                        appl_ty = line[5]
                    elif line.startswith('APD  '):
                        file_dt = line[5:13]
                        try:
                            file_dt = datetime.strptime(file_dt, '%Y%m%d'
                                ).isoformat()[:10]
                        except:
                            file_dt = ''
                    elif line.startswith(('PBL  ')):
                        pub_lvl = line[5]
                    elif line.startswith('NCL  '):
                        try:
                            no_clms = int(line[5:].strip())
                        except:
                            pass
        if sections:
            sections['pat_no'] = pat8to7(pat_no)
            sections['iss_dt'] = iss_dt
            sections['appl_ty'] = appl_ty
            sections['pub_lvl'] = pub_lvl
            if series_cd and appl_no:
                appl_id = '%s%s' % (('0%s' % (series_cd,))[-2:], appl_no)
            sections['appl_id'] = appl_id
            sections['file_dt'] = file_dt
            sections['no_clms'] = no_clms
            yield sections


def split_into_soups(file_ptr, split_into_docs):
    """
    Reads the data from the file referenced by the argument and generates
    individual XML documents parsed by BeautifulSoup.
    :param file_ptr: a file opened for reading
    :return: a BeautifulSoup instance
    """
    for doc in split_into_docs(file_ptr):
        soup = BeautifulSoup(doc, 'xml')
        yield soup


def get_file_ptr(filename):
    """
    Checks the file referred to by filename. If it's a zip file, opens the
    contained XML files for reading. Otherwise just opens the file for reading.
    :param filename: file name
    :return: file pointer, name of file
    """
    if is_zipfile(filename):
        zip_file = ZipFile(filename, 'r')
        for name in sorted(set(zip_file.namelist())):
            if name.lower().endswith('.sgm'):
                continue
            file_ptr = zip_file.open(name, 'r')
            yield file_ptr, '%s(%s)' % (filename, name)
    else:
        file_ptr = open(filename, 'rb')
        yield file_ptr, filename


def get_uspc_code_pg(soup):
    pass


def get_cpc_code_pg(soup):
    pass


def get_pat_no_and_kind_and_date_pg(soup):
    """
    Finds the publication number of the application represented by the soup.
    :param soup:
    :return: publication number
    """
    pat_no= ''
    kind = ''
    iss_dt = ''
    sdobi = soup(u'SDOBI')
    if sdobi:
        # Get the document identification:
        b100 = sdobi[0](u'B100')
        if b100:
            # Get the publication number (patent number)
            b110 = b100[0](u'B110')
            if b110:
                dnum = b110[0](u'DNUM')
                if dnum:
                    pat_no = safe_encode(dnum[0].text.strip())
                    pat_no = pat8to7(pat_no)
            # Get the kind of document:
            b130 = b100[0](u'B130')
            if b130:
                kind = safe_encode(b130[0].text.strip())
            # Get the issue date:
            b140 = b100[0](u'B140')
            if b140:
                iss_dt = safe_encode(b140[0].text.strip())
    return pat_no, kind, iss_dt


def get_uspc_code_ipg(soup):
    global process_filename

    uspc_code = u''
    try:
        classification_search = soup.find_all(u'classification-national')[0]
        try:
            uspc_code_raw = classification_search.find_all(u'main-classification')[0].text
            uspc_code = uspc_code_raw.strip()
        except:
            pass
    except:
        pass

    return uspc_code


def get_cpc_code_ipg(soup):
    """
    Finds CPC classification of the application represented by the soup.
    :param soup:
    :return: CPC code
    """
    cpc_code = u''
    try:
        classification_search = soup.find_all(u'us-field-of-classification-search')[0]
        try:
            cpc_code_raw = classification_search.find_all(u'classification-cpc-text')[0].text
            cpc_code = cpc_code_raw.strip().split()[0]
        except:
            pass
    except:
        pass

    return cpc_code


def get_pat_no_and_kind_and_date_ipg(soup):
    """
    Finds the publication number of the application represented by the soup.
    :param soup:
    :return: publication number
    """
    pat_no = u''
    kind = u''
    iss_dt = u''
    try:
        pub_ref = soup.find_all(u'publication-reference')[0]
        try:
            doc_id = pub_ref.find_all(u'document-id')[0]
            try:
                pat_no = u''.join(doc_id.find_all(u'doc-number')[0].strings).strip()
                pat_no = pat8to7()
            except:
                pass
            try:
                kind = u''.join(doc_id.find_all(u'kind')[0].strings).strip()
            except:
                pass
            try:
                iss_dt = doc_id.find_all(u'date')[0].text.strip()
            except:
                pass
        except:
            pass
    except:
        pass
    return pat_no, kind, iss_dt


def get_appl_id_and_file_dt_pg(soup):
    """
    Finds the publication number of the application represented by the soup.
    :param soup:
    :return: publication number
    """
    appl_id = ''
    file_dt = ''
    sdobi = soup(u'SDOBI')
    if sdobi:
        # Get the domestic filing data:
        b200 = sdobi[0](u'B200')
        if b200:
            # Get the publication number (patent number)
            b210 = b200[0](u'B210')
            if b210:
                dnum = b210[0](u'DNUM')
                if dnum:
                    appl_id = safe_encode(dnum[0].text.strip())
            # Get the filing date:
            b220 = b200[0](u'B220')
            if b220:
                file_dt = safe_encode(b220[0].text.strip())
    return appl_id, file_dt


""" Additional scrapping """


def get_us_application_series_code_ipg(soup):
    us_application_series_code = u''
    try:
        us_application_series_code = soup.find_all(u'us-application-series-code')[0].text
    except:
        pass
    return us_application_series_code


def get_classifications_ipcr_ipg(soup):
    parts = []
    try:
        classifications_ipcr = soup.find(u'classifications-ipcr')
        ipcrs = classifications_ipcr.find_all(u'classification-ipcr')
        for classification_ipcr in ipcrs:
            part = defaultdict(list)
            part['classification-level'] = classification_ipcr.find(u'classification-level').text
            part['section'] = classification_ipcr.find(u'section').text
            part['class'] = classification_ipcr.find(u'class').text
            part['subclass'] = classification_ipcr.find(u'subclass').text
            part['main-group'] = classification_ipcr.find(u'main-group').text
            part['subgroup'] = classification_ipcr.find(u'subgroup').text
            part['symbol-position'] = classification_ipcr.find(u'symbol-position').text
            part['classification-value'] = classification_ipcr.find(u'classification-value').text
            part['action-date'] = classification_ipcr.find(u'action-date').find(u'date').text
            part['generating-office'] = classification_ipcr.find(u'generating-office').text
            part['classification-status'] = classification_ipcr.find(u'classification-status').text
            part['classification-data-source'] = classification_ipcr.find(u'classification-data-source').text
            parts.append(part)
    except:
        pass
    return parts


def get_classifications_cpc_ipg(soup):
    main_cpc_part = defaultdict(list)
    further_cpc_parts = []
    try:
        classifications_cpc = soup.find(u'classifications-cpc')
        main_cpc = classifications_cpc.find(u'main-cpc').find(u'classification-cpc')

        main_cpc_part['section'] = main_cpc.find(u'section').text
        main_cpc_part['class'] = main_cpc.find(u'class').text
        main_cpc_part['subclass'] = main_cpc.find(u'subclass').text
        main_cpc_part['main-group'] = main_cpc.find(u'main-group').text
        main_cpc_part['subgroup'] = main_cpc.find(u'subgroup').text
        main_cpc_part['symbol-position'] = main_cpc.find(u'symbol-position').text
        main_cpc_part['classification-value'] = main_cpc.find(u'classification-value').text
        main_cpc_part['action-date'] = main_cpc.find(u'action-date').find(u'date').text
        main_cpc_part['generating-office'] = main_cpc.find(u'generating-office').text
        main_cpc_part['classification-status'] = main_cpc.find(u'classification-status').text
        main_cpc_part['classification-data-source'] = main_cpc.find(u'classification-data-source').text
        main_cpc_part['scheme-origination-code'] = main_cpc.find(u'scheme-origination-code').text

        further_cpcs = classifications_cpc.find(u'further-cpc').find_all(u'classification-cpc')
        for further_cpc in further_cpcs:
            further_cpc_part = defaultdict(list)
            further_cpc_part['section'] = further_cpc.find(u'section').text
            further_cpc_part['class'] = further_cpc.find(u'class').text
            further_cpc_part['subclass'] = further_cpc.find(u'subclass').text
            further_cpc_part['main-group'] = further_cpc.find(u'main-group').text
            further_cpc_part['subgroup'] = further_cpc.find(u'subgroup').text
            further_cpc_part['symbol-position'] = further_cpc.find(u'symbol-position').text
            further_cpc_part['classification-value'] = further_cpc.find(u'classification-value').text
            further_cpc_part['action-date'] = further_cpc.find(u'action-date').find(u'date').text
            further_cpc_part['generating-office'] = further_cpc.find(u'generating-office').text
            further_cpc_part['classification-status'] = further_cpc.find(u'classification-status').text
            further_cpc_part['classification-data-source'] = further_cpc.find(u'classification-data-source').text
            further_cpc_part['scheme-origination-code'] = further_cpc.find(u'scheme-origination-code').text
            further_cpc_parts.append(further_cpc_part)
    except:
        pass
    return main_cpc_part, further_cpc_parts


def get_invention_title_ipg(soup):
    invention_title = u''
    try:
        invention_title = soup.find(u'invention-title').text
    except:
        pass
    return invention_title


def get_num_of_claims_ipg(soup):
    num_of_claims = soup.find(u'number-of-claims').text
    return num_of_claims


def get_us_exemplary_claim_ipg(soup):
    exemplary_claim_no = soup.find(u'us-exemplary-claim').text
    claims = soup.find(u'claims').find_all(u'claim')
    exemplary_claim = claims[int(exemplary_claim_no)-1]

    return exemplary_claim


def get_us_field_of_classification_search_ipg(soup):
    uspcs = []

    try:
        us_field_of_classification_search = soup.find(u'us-field-of-classification-search')
        uspc_codes = us_field_of_classification_search.find_all(u'classification-national')
        for uspc_code in uspc_codes:
            uspcs.append(uspc_code.find(u'main-classification').text)
    except:
        us_field_of_classification_search = soup.find(u'field-of-search')
        uspc_codes = us_field_of_classification_search.find_all(u'classification-national')
        for uspc_code in uspc_codes:
            uspcs.append(uspc_code.find(u'main-classification').text)

    cpcs = []
    try:
        us_field_of_classification_search = soup.find(u'us-field-of-classification-search')
        cpc_codes = us_field_of_classification_search.find_all(u'classification-cpc-text')
        for cpc_code in cpc_codes:
            cpcs.append(cpc_code.text)
    except:
        us_field_of_classification_search = soup.find(u'field-of-search')
        cpc_codes = us_field_of_classification_search.find_all(u'classification-cpc-text')
        for cpc_code in cpc_codes:
            cpcs.append(cpc_code.text)

    return uspcs, cpcs


def get_us_parties_ipg(soup):

    applicants = []
    inventor_parts = []
    agents_info = []

    try:
        us_parties = soup.find(u'us-parties')
        us_applicants = us_parties.find(u'us-applicants').find_all(u'us-applicant')
        for us_applicant in us_applicants:
            try:
                applicants.append(us_applicant.find(u'addressbook').find(u'orgname').text)
            except:
                applicant_part = defaultdict(list)
                applicant_part['last-name'] = us_applicant.find(u'last-name').text
                applicant_part['first-name'] = us_applicant.find(u'first-name').text
                applicants.append(applicant_part)
    except:
        us_parties = soup.find(u'parties')
        us_applicants = us_parties.find(u'applicants').find_all(u'applicant')
        for us_applicant in us_applicants:
            try:
                applicants.append(us_applicant.find(u'addressbook').find(u'orgname').text)
            except:
                applicant_part = defaultdict(list)
                applicant_part['last-name'] = us_applicant.find(u'last-name').text
                applicant_part['first-name'] = us_applicant.find(u'first-name').text
                applicants.append(applicant_part)

    try:
        us_parties = soup.find(u'us-parties')
        inventors = us_parties.find(u'inventors').find_all(u'inventor')
        for inventor in inventors:
            inventor_part = defaultdict(list)
            inventor_part['last-name'] = inventor.find(u'last-name').text
            inventor_part['first-name'] = inventor.find(u'first-name').text
            inventor_parts.append(inventor_part)
    except:
        try:
            us_parties = soup.find(u'parties')
            inventors = us_parties.find(u'inventors').find_all(u'inventor')
            for inventor in inventors:
                inventor_part = defaultdict(list)
                inventor_part['last-name'] = inventor.find(u'last-name').text
                inventor_part['first-name'] = inventor.find(u'first-name').text
                inventor_parts.append(inventor_part)
        except:
            pass

    try:
        us_parties = soup.find(u'us-parties')
        agents = us_parties.find(u'agents').find_all(u'agent')
        for agent in agents:
            try:
                agents_info.append(agent.find(u'addressbook').find(u'orgname').text)
            except:
                agent_part = defaultdict(list)
                agent_part['last-name'] = agent.find(u'last-name').text
                agent_part['first-name'] = agent.find(u'first-name').text
                agents_info.append(agent_part)
    except:
        try:
            us_parties = soup.find(u'parties')
            agents = us_parties.find(u'agents').find_all(u'agent')
            for agent in agents:
                try:
                    agents_info.append(agent.find(u'addressbook').find(u'orgname').text)
                except:
                    agent_part = defaultdict(list)
                    agent_part['last-name'] = agent.find(u'last-name').text
                    agent_part['first-name'] = agent.find(u'first-name').text
                    agents_info.append(agent_part)
        except:
            pass

    return applicants, inventor_parts, agents_info


def get_examiners_ipg(soup):
    examiners = soup.find(u'examiners').find_all(u'primary-examiner')
    examiner_parts = []
    for examiner in examiners:
        examiner_part = defaultdict(list)
        examiner_part['last-name'] = examiner.find(u'last-name').text
        examiner_part['first-name'] = examiner.find(u'first-name').text
        examiner_part['department'] = examiner.find(u'department').text
        examiner_parts.append(examiner_part)

    return examiner_parts


def get_abstract_ipg(soup):
    abstract = u''
    try:
        abstract = soup.find(u'abstract').text
    except:
        pass
    return abstract


def get_patent_description_ipg(soup):
    description = soup.find(u'description')
    children = description.findChildren()
    key = u''
    text = u''
    omit = False
    patent_description = defaultdict(list)
    for child in children:
        # print child
        # print child.name
        # print child.text
        if child.name == u'heading':
            if child.text.upper() == u'BRIEF DESCRIPTIONS OF THE DRAWINGS':
                omit = True
                continue
            else:
                omit = False
            patent_description[key] = text
            key = child.text
            text = u''
        if omit:
            continue
        if child.name == u'p':
            text += child.text
        if child.name == u'description-of-drawings':
            key = u'DESCRIPTIONS OF THE DRAWINGS'
            text = u''
            drawings = child.findChildren()
            for drawing in drawings:
                if drawing.name == u'heading':
                    continue
                if drawing.name == u'figref':
                    continue
                descr = drawing.text
                # print descr
                try:
                    figref = drawing.find(u'figref').text
                except AttributeError:
                    figref = u''
                clean_descr = descr.replace(figref, '')
                # print clean_descr
                text += clean_descr
            patent_description[key] = text
            key = u''
            text = u''

    return patent_description


def get_appl_id_and_file_dt_ipg(soup):
    """
    Finds the publication number of the application represented by the soup.
    :param soup:
    :return: publication number
    """
    appl_id = u''
    file_dt = u''
    try:
        app_ref = soup.find_all(u'application-reference')[0]
        try:
            doc_id = app_ref.find_all(u'document-id')[0]
            try:
                appl_id = u''.join(doc_id.find_all(u'doc-number')[0].strings).strip()
            except:
                pass
            try:
                file_dt = doc_id.find_all(u'date')[0].text.strip()
            except:
                pass
        except:
            pass
    except:
        pass
    return appl_id, file_dt


_lstrip_chars = unicode(whitespace + '0')


def get_claims_pg(soup):
    """
    Finds the claims and returns the claim index, ID, number, text, and references.
    :param soup:
    :return:
    """
    global _lstrip_chars
    clm_idx = 0
    for claims in soup(u'CL'):
        for claim in claims(u'CLM'):
            clm_idx += 1
            clm_ref_ids = []
            clm_ref_nos = []
            clm_id = claim.attrs.get('ID', u'')
            clm_no = clm_id[4:].lstrip(_lstrip_chars)
            clm_txt = claim.text
            clm_txt = standardize_whitespace(clm_txt, remove_leading_number=True)
            for claim_ref in claim.find_all(u'CLREF'):
                clm_ref_ids.append(claim_ref.attrs.get('ID', u'').strip())
                clm_ref_nos.append(standardize_whitespace(
                    claim_ref.text))
            clm_chr_ct = len(clm_txt)
            clm_wrd_ct = len(clm_txt.split())
            clm_ind_flg = 1
            clm_deps = get_deps(clm_txt)
            if clm_deps:
                clm_ind_flg = 0
            yield (clm_idx, clm_id, clm_no, clm_ind_flg, clm_txt, clm_wrd_ct,
                clm_chr_ct, u','.join(clm_deps), u','.join(clm_ref_ids),
                u','.join(clm_ref_nos))


# ----------------------------------------------------------------------


def get_raw_claims_pftaps(sections):
    """
    Finds the claims and returns the claim index, ID, number, text, and references.
    :param soup:
    :return:
    """
    clm_idx = 0
    claims = []
    if 'DCLM' in sections:
        claims.append('NUM  1.')
        claims.extend(sections['DCLM'])
    if 'CLMS' in sections:
        claims.extend(sections['CLMS'])
    claim_no = 0
    claim_txt = []

    for line in claims:
        if line.startswith('NUM  '):
            if claim_no and claim_txt:
                yield claim_no, standardize_whitespace(' '.join(claim_txt))
            try:
                claim_no = int(float(line[5:].strip().split()[0]))
            except:
                claim_no = 0
            claim_txt = []
        else:
            claim_txt.append(line[5:])

    if claim_no and claim_txt:
        yield claim_no, standardize_whitespace(' '.join(claim_txt))


def contains_added_text(claim_text):
    if not '.Iadd.' in claim_text:
        return False
    if not '.Iaddend.' in claim_text:
        return False
    if not claim_text.find('.Iadd.') < claim_text.find('.Iaddend.'):
        return False
    return True


def expand_claim(claim, no_clms):
    claim_no, claim_txt = claim
    claim_txt = replace_brackets(claim_txt)
    if not contains_added_text(claim_txt):
        # print 'Does not contain added text.'
        yield claim_no, claim_txt
        return
    if claim_no >= no_clms:
        # print 'Claim number is greater than or equal to number of claims.'
        yield claim_no, claim_txt
        return
    re_iadd_num = re_compile(r'''\.Iadd\.\s*''' + str(1 + claim_no) + r'''\.?\s+''')
    m = re_iadd_num.search(claim_txt)
    if not m:
        # print 'No match for first added claim.'
        # print claim_txt
        yield claim_no, claim_txt
        return
    yield claim_no, claim_txt[:m.start()]
    claim_txt = claim_txt[m.start():]
    for claim_no in range(1 + claim_no, 1 + no_clms):
        re_clm_no = re_compile(r'''\.Iadd\.\s*''' + str(claim_no) + r'''[ .].*?\.Iaddend\.''')
        m = re_clm_no.search(claim_txt)
        if m:
            yield claim_no, claim_txt[m.start():m.end()]


def remove_claim_no(claim_text, claim_no):
    re_clm_no = re_compile(r'^' + str(claim_no) + r'\s*\.\s*')
    m = re_clm_no.search(claim_text)
    if not m:
        return claim_text
    return claim_text[m.end():]


def get_claims_pftaps(sections):
    """
    Processes the output of get_raw_claims_pftaps to remove markers for additions.
    :param sections:
    :return:
    """
    global _DEBUG
    claims = list(get_raw_claims_pftaps(sections))

    try:
        no_clms = int(sections['no_clms'])
    except:
        no_clms = 0

    if no_clms > len(claims) and sections['pat_no'].startswith('RE'):
        # print 'Expanding claims.'
        # print 'no_claims:'
        # pprint(no_clms)
        # print 'claims:'
        # pprint(claims)
        # print 'len(claims):'
        # pprint(len(claims))
        # print 'claims[-1]'
        # pprint(claims[-1])
        claims[-1:] = expand_claim(claims[-1], no_clms)
        # print 'SUCCESS!!!'

    for claim_no, claim_txt in claims:
        yield claim_no, remove_claim_no(fix_claim_text(claim_txt), claim_no)


def fix_claim_text(claim_text):
    """
    Replaces the "added text" markers with whitespace.
    :param claim_text:
    :return:
    """
    return standardize_whitespace(claim_text.replace('.[.', ' ').replace(
        '.].', ' ').replace('.Iadd.', ' ').replace('.Iaddend.', ' '))


def replace_brackets(claim_text):
    """
    Replaces the .[. and .]. markers with .Iadd. and .Iaddend. markers.
    :param claim_text:
    :return:
    """
    return standardize_whitespace(claim_text.replace('.[.', '.Iadd.').replace(
        '.].', '.Iaddend.'))

#-------------------------------------------------------------------------------


def get_claims_ipg(soup):
    """
    Finds the claims and returns the claim index, ID, number, text, and references.
    :param soup:
    :return:
    """
    clm_idx = 0
    for claims in soup.find_all(u'claims'):
        for claim in claims.find_all(u'claim'):
            clm_idx += 1
            clm_ref_ids = []
            clm_ref_nos = []
            clm_id = claim.attrs.get('id', u'')
            clm_no = claim.attrs.get('num', u'')
            clm_txt = claim.text
            clm_txt = standardize_whitespace(clm_txt, remove_leading_number=True)
            for claim_ref in claim.find_all(u'claim-ref'):
                clm_ref_ids.append(claim_ref.attrs.get('idref', u'').strip())
                clm_ref_nos.append(standardize_whitespace(claim_ref.text))
            clm_chr_ct = len(clm_txt)
            clm_wrd_ct = len(clm_txt.split())
            clm_ind_flg = 1
            clm_deps = get_deps(clm_txt)
            if clm_deps:
                clm_ind_flg = 0
            yield (clm_idx, clm_id, clm_no, clm_ind_flg, clm_txt, clm_wrd_ct,
                   clm_chr_ct, u','.join(clm_deps), u','.join(clm_ref_ids),
                   u','.join(clm_ref_nos))


def main():
    """Main routine."""
    global xml_ct
    global claims_log_fp
    args = get_args()
    filenames = set()
    for filename in args.zip_files:
        filenames.update(glob(filename))
    filenames = list(sorted(filenames))
    meta_fields = 'filename,doc_idx,pat_no,kind,iss_dt,appl_id,file_dt'.split(',')
    claim_fields = 'pat_no,appl_id,uspc_code,cpc_code,claim_idx,claim_id,claim_no,ind_flg,deps,ref_ids,ref_nos,wrd_ct,chr_ct,claim_txt'.split(',')
    err_fields = ('filename,doc_idx,pat_no,kind,iss_dt,appl_id,file_dt,error'.split(','))
    for filename in filenames:
        global process_filename
        process_filename = filename
        is_pftaps = False
        if basename(filename).lower().startswith('pg'):
            split_into_docs = split_into_docs_pg
            get_uspc_code = get_uspc_code_pg
            get_cpc_code = get_cpc_code_pg
            get_pat_no_and_kind_and_date = get_pat_no_and_kind_and_date_pg
            get_appl_id_and_file_dt = get_appl_id_and_file_dt_pg
            get_claims = get_claims_pg
        elif basename(filename).lower().startswith('ipg'):
            split_into_docs = split_into_docs_ipg
            get_uspc_code = get_uspc_code_ipg

            """ NEW STUFF START """
            get_us_application_series_code = get_us_application_series_code_ipg
            get_classifications_ipcr = get_classifications_ipcr_ipg
            get_classifications_cpc = get_classifications_cpc_ipg
            get_invention_title = get_invention_title_ipg
            get_num_of_claims = get_num_of_claims_ipg
            get_us_exemplary_claim = get_us_exemplary_claim_ipg
            get_us_field_of_classification_search = get_us_field_of_classification_search_ipg
            get_us_parties = get_us_parties_ipg
            get_examiners = get_examiners_ipg
            get_abstract = get_abstract_ipg
            get_patent_description = get_patent_description_ipg
            """ NEW STUFF END """

            get_cpc_code = get_cpc_code_ipg
            get_pat_no_and_kind_and_date = get_pat_no_and_kind_and_date_ipg
            get_appl_id_and_file_dt = get_appl_id_and_file_dt_ipg
            get_claims = get_claims_ipg
        elif basename(filename).lower().startswith('pftaps'):
            is_pftaps = True
        else:
            # Log some kind of error.
            pass
        for file_ptr, name in get_file_ptr(filename):
            claims_out_fn = '%s_claims.%s' % (splitext(filename)[0], 'csv.gz')
            claims_err_fn = '%s_claims.%s' % (splitext(filename)[0], 'err.gz')
            claims_log_fn = '%s_claims.%s' % (splitext(filename)[0], 'log')
            meta_out_fn = '%s_meta.%s' % (splitext(filename)[0], 'csv.gz')
            meta_err_fn = '%s_meta.%s' % (splitext(filename)[0], 'err.gz')
            meta_log_fn = '%s_meta.%s' % (splitext(filename)[0], 'log')
            time_stamp_message('Processing %s:' % (name,))
            if isfile(claims_out_fn) and not args.force:
                time_stamp_message('-- output file exists - skipping.')
                continue
            if isfile(claims_err_fn):
                remove(claims_err_fn)
            claims_out_fp = GzipFile(claims_out_fn, 'w')
            claims_log_fp = open(claims_log_fn, 'wb')
            claims_writer = DictWriter(claims_out_fp, claim_fields)
            try:
                claims_writer.writeheader()
            except:
                claims_writer.writerow(dict(zip(claim_fields, claim_fields)))
            meta_out_fp = GzipFile(meta_out_fn, 'w')
            meta_log_fp = open(meta_log_fn, 'wb')
            meta_writer = DictWriter(meta_out_fp, meta_fields)
            try:
                meta_writer.writeheader()
            except:
                meta_writer.writerow(dict(zip(meta_fields, meta_fields)))
            claim_row = {}
            meta_row = {'filename': basename(name).split('(')[0]}
            err_row_template = {'filename': basename(name).split('(')[0]}
            err_rows = []
            if is_pftaps:
                doc_idx = 0
                for doc_no, sections in enumerate(split_into_sections(file_ptr)):
                    doc_idx += 1
                    meta_row['doc_idx'] = doc_idx
                    pat_no = sections['pat_no']
                    kind = ''
                    # iss_dt = sections['iss_dt']
                    appl_id = sections['appl_id']
                    # file_dt = sections['file_dt']
                    for field in 'pat_no,iss_dt,appl_id,file_dt'.split(','):
                        meta_row[field] = sections[field]
                    meta_row['kind'] = kind
                    meta_writer.writerow(meta_row)
                    claim_row['pat_no'], claim_row['appl_id'] = pat_no, appl_id
                    err_row = dict(err_row_template)
                    for field in 'doc_idx,pat_no,kind,iss_dt,appl_id,file_dt'.split(','):
                        err_row[field] = meta_row[field]
                    claim_ct = 0
                    clm_idx = 0
                    try:
                        for clm_no, clm_txt in get_claims_pftaps(sections):
                            clm_idx += 1
                            claim_row['claim_idx'] = clm_idx
                            claim_row['claim_id'] = ''
                            claim_row['claim_no'] = clm_no
                            claim_row['claim_txt'] = clm_txt
                            clm_chr_ct = len(clm_txt)
                            clm_wrd_ct = len(clm_txt.split())
                            clm_ind_flg = 1
                            clm_deps = get_deps(clm_txt)
                            if clm_deps:
                                clm_ind_flg = 0
                            claim_row['ind_flg'] = clm_ind_flg
                            claim_row['deps'] = ','.join(clm_deps)
                            claim_row['ref_ids'] = ''
                            claim_row['ref_nos'] = ''
                            claim_row['wrd_ct'] = clm_wrd_ct
                            claim_row['chr_ct'] = clm_chr_ct
                            claims_writer.writerow(claim_row)
                    except:
                        pass
                    if not claim_ct:
                        err_row['error'] = ('No claims found for doc %d, pat no'
                                            ' %s.') % (doc_idx, claim_row['pat_no'])
                        err_rows.append(err_row)
                claims_out_fp.close()
                if err_rows:
                    err_fp = GzipFile(claims_err_fn, 'w')
                    err_writer = DictWriter(err_fp, err_fields)
                    try:
                        err_writer.writeheader()
                    except:
                        err_writer.writerow(dict(zip(err_fields, err_fields)))
                    err_writer.writerows(err_rows)
                    err_fp.close()
                time_stamp_message('-- %s PFTAPS documents processed.' % (
                    format_number(doc_idx),))
                time_stamp_message('-- %s PFTAPS documents found.' % (format_number(
                    xml_ct),))
                print >> claims_log_fp, '%s PFTAPS documents processed.' % (format_number(
                    doc_idx),)
                print >> claims_log_fp, '%s PFTAPS documents found.' % (format_number(
                    xml_ct),)
                claims_log_fp.close()
            else:
                max_soup_no = 0
                for soup_no, soup in enumerate(split_into_soups(file_ptr, split_into_docs)):
                    meta_row['doc_idx'] = 1 + soup_no
                    max_soup_no = 1 + soup_no
                    uspc_code = get_uspc_code(soup)
                    cpc_code = get_cpc_code(soup)
                    """ NEW STUFF START """
                    get_patent_description(soup)
                    get_us_application_series_code(soup)
                    get_classifications_ipcr(soup)
                    get_classifications_cpc(soup)
                    get_invention_title(soup)
                    get_num_of_claims(soup)
                    get_us_exemplary_claim(soup)
                    get_us_field_of_classification_search(soup)
                    get_us_parties(soup)
                    get_examiners(soup)
                    get_abstract(soup)
                    """ NEW STUFF END """
                    pat_no, kind, iss_dt = get_pat_no_and_kind_and_date(soup)
                    appl_id, file_dt = get_appl_id_and_file_dt(soup)
                    # if not pat_no or not appl_id:
                    #     print str(soup)[:1000]
                    #     exit()
                    meta_row['pat_no'], meta_row['kind'], meta_row['iss_dt'] = (
                        pat_no, kind, iss_dt
                    )
                    meta_row['appl_id'], meta_row['file_dt'] = appl_id, file_dt
                    meta_writer.writerow(meta_row)
                    claim_row['pat_no'], claim_row['appl_id'] = pat_no, appl_id
                    claim_row['uspc_code'] = uspc_code
                    claim_row['cpc_code'] = cpc_code
                    err_row = dict(err_row_template)
                    for field in 'doc_idx,pat_no,kind,iss_dt,appl_id,file_dt'.split(','):
                        err_row[field] = meta_row[field]
                    claim_ct = 0
                    for (clm_idx, clm_id, clm_no, clm_ind_flg, clm_txt, clm_wrd_ct,
                        clm_chr_ct, clm_deps, clm_ref_ids, clm_ref_nos) in (
                        get_claims(soup)):
                        claim_ct += 1
                        claim_row.update({
                            'claim_idx': clm_idx,
                            'claim_id': safe_encode(clm_id),
                            'claim_no': safe_encode(clm_no),
                            'ind_flg': clm_ind_flg,
                            'deps': safe_encode(clm_deps),
                            'ref_ids': safe_encode(clm_ref_ids),
                            'ref_nos': safe_encode(clm_ref_nos),
                            'wrd_ct':clm_wrd_ct,
                            'chr_ct':clm_chr_ct,
                            'claim_txt': safe_encode(clm_txt),
                        })
                        claims_writer.writerow(claim_row)
                    if not claim_ct:
                        err_row['error'] = 'No claims found for doc %d, pub no %s.' % (1
                            + soup_no, claim_row['pat_no'])
                        err_rows.append(err_row)
                if err_rows:
                    err_fp = GzipFile(claims_err_fn, 'w')
                    err_writer = DictWriter(err_fp, err_fields)
                    try:
                        err_writer.writeheader()
                    except:
                        err_writer.writerow(dict(zip(err_fields, err_fields)))
                    err_writer.writerows(err_rows)
                    err_fp.close()
                claims_out_fp.close()
                time_stamp_message('-- %s XML documents processed.' % (
                    format_number(max_soup_no),))
                time_stamp_message('-- %s XML documents found.' % (format_number(
                    xml_ct),))
                print >> claims_log_fp, '%s XML documents processed.' % (format_number(
                    max_soup_no),)
                print >> claims_log_fp, '%s XML documents found.' % (format_number(
                    xml_ct),)
                claims_log_fp.close()
    stdout.flush()
    return


if '__main__' == __name__:
    main()
