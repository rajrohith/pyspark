"""Common routines for patent claims code."""

__author__ = 'rkimble'

from argparse import ArgumentParser
from csv import field_size_limit
from locale import format, LC_ALL, setlocale
from re import compile as re_compile, IGNORECASE
from sys import stderr, stdout
from time import asctime

field_size_limit(64 * 1024 * 1024)

_TYPE_TO_SPACE = {str: ' ', unicode: u' '}


class summary_row(object):
    """
    Used for compiling summary statistics.
    """

    uni_type = type(u'')

    def __init__(self):
        """
        Populates summary column attributes.
        :return: None
        """
        self.ind_ct = 0  # Independent claim count.
        self.dep_ct = 0  # Dependent claim count.
        self.ind_word_ct = 0  # Independent claims word count.
        self.dep_word_ct = 0  # Dependent claims word count.
        self.ind_word_ct_min = None  # Independent claims word count (min).
        self.dep_word_ct_min = None  # Dependent claims word count (min).
        self.ind_char_ct = 0  # Independent claims character count.
        self.dep_char_ct = 0  # Dependent claims character count.
        self.ind_char_ct_min = None  # Independent claims character count (min).
        self.dep_char_ct_min = None  # Dependent claims character count (min).
        self.ind_or_ct = 0  # Independent claims "or" count.
        self.dep_or_ct = 0  # Dependent claims "or" count.
        self.ind_sf_ct = 0  # Independent claims "selected from" count.
        self.dep_sf_ct = 0  # Dependent claims "selected from" count.
        self.ind_cns_ct = 0  # Independent claims "consisting" count.
        self.dep_cns_ct = 0  # Dependent claims "consisting" count.
        self.cnx_ct = 0  # Canceled claims count.
        self.first_clm_word_ct = None # Word count of first claim.
        self.first_clm_char_ct = None  # Character count of first claim.

    def add_claim(self, claim_row):
        """
        Adds the data from a claim row to the patent record.
        :param claim_row: Row from ipg????????.csv.
        :return: self
        """
        # This code assumes that the supplied claim text has had the claim
        # number removed and the whitespace standardized.
        claim_txt = claim_row['claim_txt']
        if summary_row.uni_type == type(claim_txt):
            claim_txt = safe_encode(claim_txt)
        claim_txt_plus = ' %s ' % (claim_txt.lower(),)
        or_ct = len(claim_txt_plus.split(' or ')) - 1
        sf_ct = len(claim_txt_plus.split(' selected from ')) - 1
        cns_ct = len(claim_txt_plus.split(' consisting ')) - 1
        ind_flg = int(claim_row['ind_flg'])
        try:
            word_ct = int(claim_row['wrd_ct'])
        except:
            word_ct = None
        try:
            char_ct = int(claim_row['chr_ct'])
        except:
            char_ct = None

        cnx_flg = 0
        if 100 >= len(claim_txt):
            if '(canceled)' in claim_txt_plus:
                self.cnx_ct += 1
                cnx_flg = 1
            elif '(cancelled)' in claim_txt_plus:
                self.cnx_ct += 1
                cnx_flg = 1

        if cnx_flg:
            word_ct = None
            char_ct = None
            or_ct = None
            sf_ct = None
            cns_ct = None
        else:
            if not self.first_clm_word_ct:
                self.first_clm_word_ct = word_ct
                self.first_clm_char_ct = char_ct
            if ind_flg:
                self.ind_ct += 1
                self.ind_word_ct += word_ct
                self.ind_word_ct_min = new_min(self.ind_word_ct_min, word_ct)
                self.ind_char_ct += char_ct
                self.ind_char_ct_min = new_min(self.ind_char_ct_min, char_ct)
                self.ind_or_ct += or_ct
                self.ind_sf_ct += sf_ct
                self.ind_cns_ct += cns_ct
            else:
                self.dep_ct += 1
                self.dep_word_ct += word_ct
                self.dep_word_ct_min = new_min(self.dep_word_ct_min, word_ct)
                self.dep_char_ct += char_ct
                self.dep_char_ct_min = new_min(self.dep_char_ct_min, char_ct)
                self.dep_or_ct += or_ct
                self.dep_sf_ct += sf_ct
                self.dep_cns_ct += cns_ct

        return {
            'word_ct': word_ct,
            'char_ct': char_ct,
            'or_ct': or_ct,
            'sf_ct': sf_ct,
            'cns_ct': cns_ct,
            'cnx_flg': cnx_flg,
        }

    def as_row(self):
        """
        Returns a dictionary of attribute name/value pairs.
        :return:
        """
        row = {
            'ind_ct': self.ind_ct,
            'ind_word_ct': self.ind_word_ct,
            'ind_word_ct_min': self.ind_word_ct_min,
            'ind_char_ct': self.ind_char_ct,
            'ind_char_ct_min': self.ind_char_ct_min,
            'ind_or_ct': self.ind_or_ct,
            'ind_sf_ct': self.ind_sf_ct,
            'ind_cns_ct': self.ind_cns_ct,
            'dep_ct': self.dep_ct,
            'dep_word_ct': self.dep_word_ct,
            'dep_word_ct_min': self.dep_word_ct_min,
            'dep_char_ct': self.dep_char_ct,
            'dep_char_ct_min': self.dep_char_ct_min,
            'dep_or_ct': self.dep_or_ct,
            'dep_sf_ct': self.dep_sf_ct,
            'dep_cns_ct': self.dep_cns_ct,
            'cnx_ct': self.cnx_ct,
            'first_clm_word_ct':self.first_clm_word_ct,
            'first_clm_char_ct':self.first_clm_char_ct,
            # 'appl_id':self.appl_id,
            # 'kind':self.kind,
        }
        return row


def get_args():
    """
    Parses the command line arguments.
    :return: args
    """
    parser = ArgumentParser(description='Extract claims from PGPubs zip files.')
    parser.add_argument('zip_files', metavar='zipfn', type=str, nargs='+',
                        help='a zip file name')
    parser.add_argument('-f', '--force', dest='force', action='store_true',
                        default=False, help='force overwrite of existing output files')
    args = parser.parse_args()
    return args


setlocale(LC_ALL, '')


def format_number(n):
    """
    Formats n with commas.
    :param n:
    :return: string
    """
    return format('%d', n, grouping=True)


def time_stamp_message(msg, out=stdout):
    """Prints a timestamped message."""
    print >> out, asctime() + ': ' + msg
    out.flush()


def standardize_whitespace(s, remove_leading_number=False):
    """
    Returns a string equivalent to the input with all whitespace sequences
    replaced by a single space. Also removes leading claim number if present.
    :param s: the input string
    :return: the output string
    """
    tokens = s.split()
    if remove_leading_number and tokens and is_number(tokens[0]):
        tokens = tokens[1:]
    return _TYPE_TO_SPACE[type(s)].join(tokens)


def safe_encode(unicode_str):
    """
    Encodes input unicode string into ASCII, replacing bad characters with
    a question mark (?).
    """
    if str == type(unicode_str):
        return unicode_str
    try:
        ascii_str = unicode_str.encode('ascii', 'replace')
        return ascii_str
    except:
        ascii_buffer = []
        for ch in unicode_str:
            try:
                ascii_buffer.append(ch.encode('ascii', 'replace'))
            except:
                ascii_buffer.append('?')
        return ''.join(ascii_buffer)


def safe_decode(ascii_str):
    """
    Decodes input ASCII string into unicode, replacing bad characters with
    a question mark (?).
    """
    if unicode == type(ascii_str):
        return ascii_str
    try:
        unicode_str = ascii_str.decode('ascii', 'replace')
        return unicode_str
    except:
        unicode_buffer = []
        for ch in ascii_str:
            try:
                unicode_buffer.append(ch.encode('ascii', 'replace'))
            except:
                unicode_buffer.append(u'?')
        return u''.join(unicode_buffer)


_re_claims = re_compile(r'(claims?( \d+(-\d+)?,?)+(( (or|and))? \d+)?)',
                        IGNORECASE)
_re_range = re_compile(r'\d+-\d+')
_re_range2 = re_compile(r'\d+ to \d+')
_re_range3 = re_compile(r'\d+ - \d+')
_re_pct = re_compile(r' \d+(\.\d+)?(-\d+(\.\d+)?)?%')
_re_num = re_compile(r'\d+')


def get_deps(claim_text):
    global _re_claims, _re_range, _re_range2, _re_range3, _re_num
    result = set()
    deps = ' '.join([x[0] for x in _re_claims.findall(claim_text)])
    for n1_n2 in _re_range.findall(deps):
        n1, n2 = n1_n2.split('-')
        n1 = int(n1)
        n2 = int(n2)
        if n1 <= n2:
            result.update(range(n1, n2 + 1))
    for n1_n2 in _re_range2.findall(deps):
        n1, n2 = n1_n2.split(' to ')
        n1 = int(n1)
        n2 = int(n2)
        if n1 <= n2:
            result.update(range(n1, n2 + 1))
    for n1_n2 in _re_range3.findall(deps):
        n1, n2 = n1_n2.split(' - ')
        n1 = int(n1)
        n2 = int(n2)
        if n1 <= n2:
            result.update(range(n1, n2 + 1))
    for n1 in _re_num.findall(deps):
        result.add(int(n1))
    return map(str, list(sorted(result)))


def is_number(s):
    """
    Returns True if s is a string representation of a numeric value, False
    otherwise.
    :param s: a string.
    :return: True or False
    """
    try:
        float(s)
        return True
    except:
        return False


_punctuation = set(r'!"#$&()*+,/:;?@[\]{|}')


def blank_punctuation(text):
    """
    Replaces each punctuation character in text with a space.
    :param text: Text potentionally containing punctuation.
    :return: Punctuation free text:
    """
    for punct in set(text).intersection(_punctuation):
        text = text.replace(punct, ' ')
    return ' '.join(text.split())


def drop_punctuation(text):
    """
    Replaces each punctuation character in text with an empty string.
    :param text: Text potentionally containing punctuation.
    :return: Punctuation free text:
    """
    for punct in set(text).intersection(_punctuation):
        text = text.replace(punct, '')
    return ' '.join(text.split())


def new_min(old, new):
    """
    Computes the new minimum of two numbers with special handling if the old
    one is None
    :param old:
    :param new:
    :return: the new minimum value.
    """
    if old is None:
        return new
    elif new is None:
        return old
    return min(old, new)


def pat8to7(patno8):
    """
    Computes the 7 digit version of an 8 digit patent number.
    :param patno8: A string containing the 8 digit patent number.
    :return: A string containing the 7 digit version.
    """
    if 8 <= len(patno8):
        return patno8.replace('0', '', 1)[:7]
    return patno8


def main():
    """Main routine."""
    print >> stderr, ('This module is not designed to be run in a standalone '
                      'fashion.')
    return


if '__main__' == __name__:
    main()
