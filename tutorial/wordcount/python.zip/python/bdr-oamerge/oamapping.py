import sys,os
import json
import base64
import datetime
from operator import add

from pyspark.sql import SparkSession
from pyspark.sql import HiveContext
from pyspark.context import SparkContext

from pyspark.sql import Row

import os
import smtplib, traceback, hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import ConfigParser
config_path=sys.argv[1]

spark = SparkSession.builder.appName("OAMapping").enableHiveSupport().getOrCreate()
    
hive = HiveContext(spark)
sc = SparkContext.getOrCreate()


started = str(datetime.datetime.now())

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-oamerge.properties')
BDRMDRHIVETABLE     = config.get('bdr','BDRMDRHIVETABLE') 
MDRPROPERTIESFILE   = config.get('bdr','MDRPROPERTIESFILE') 
ESNODES	            = config.get('bdr','ESNODES')     
OAINDEX             = config.get('bdr','OAINDEX') 
OATYPE              = config.get('bdr','OATYPE') 
MAPPING_FILE        = config.get('bdr','MAPPING_FILE') 
OAMDRHDFSPARQUET    = config.get('bdr','OAMDRHDFSPARQUET') 

oa_mapping = {
    "source": "OA",
    "filter": "unmapped",
    "validate": "false",
    "version": "0.0.1",
    "inherits":"none",
    "values": {             
      "type":"oa"  
    }
}

oa_mappings = [
        {"techcenternumber": {
            "alias":"techcenternumber",
            "jsonname":"techCenter",
            "source":"BDR",
            "definition":"Tech Center",
            "businessName":"Tech Center",
            "action": "remap",
            "required":"true",
            "field": "techCenter"
            
        }},
        {"workgroupnumber": {
            "alias":"workgroupnumber",
            "definition":"Work Group",
            "jsonname":"workGroup",
            "source":"BDR",
            "businessName":"Work Group",
            "action": "remap",
            "required":"true",
            "field": "workGroup"
        }},
        {"text": {
          "alias":"Text",
          "field":"bodyText",
          "action":"remap",
          "element":"text",
          "source":"BDR",
          "required":"true",
          "definition":"The body of the office action text.",
          "businessName":"Body Text",
          "jsonname":"bodyText"
        }},
        {"documentIdentifier": {
            "key":"true",
            "required":"true"
        }},
        {"appl_id": {
            "key":"true",
            "required":"true"
        }}]
        
oa_mapping['fields'] = oa_mappings


'''
Remove old files
'''
import os
print "Removing MDR mappings file..."
os.system("hdfs dfs -rm -r -skipTrash /data/mappings.jsonl")
print "Removing BDR properties file..."
os.system("hdfs dfs -rm -r -skipTrash /data/bdr_mappings_en.properties")

'''
Import EDAD spreadsheet
'''
import pandas as pd, xlrd
import pyspark.sql.functions as F

# Load BDR Spreadsheet from URL
os.system("wget -O bdr-mapping.xlsx https://prod-cicm.uspto.gov/scm/svn/DSDA-BDR-DEV/documentation/DEV/MDR/BDR%20Data%20Element%20Mapping.xlsx 2> /dev/null")

# Select only the needed column numbers
mapping = pd.read_excel('bdr-mapping.xlsx',parse_cols=[0,4,10,12,13,14,15])

# Replace any NaN's
mapping = mapping.fillna("")

# Convert to Spark DataFrame
sdf = spark.createDataFrame(mapping)

sdf.printSchema()
# Create SQL view
sdf.createOrReplaceTempView("bdr_spreadsheet")

bdr_mapping = spark.sql("select `Source Name ` as source, `Source Data Element Name` as element, `Data Element Definition` as definition, `Business Name` as businessname, `BDR Name (JSON Standard)` as jsonname, `BDR Name (DB Standard)` as dbname, `Authoritative Source for BDR Names that are the same` as authority  from bdr_spreadsheet")

bdr_mapping.printSchema()

bdr_mapping.createOrReplaceTempView("bdr_mapping")

'''
Select only valid mappings
'''
import json

bdr_map = bdr_mapping.rdd.map(lambda y: y.asDict()).filter(lambda x: x['element'] is not None)


def merge_bdr_mdr(mappings):
    import traceback 
    
    bdr_mapping = mappings[0]
    mdr_mapping = mappings[1]
    fields = mdr_mapping['fields']
    
    mdr_field = None
    
    if bdr_mapping.has_key('jsonname'):
        bdr_target_field = bdr_mapping['jsonname'].strip()
    if bdr_mapping.has_key('element'):
        bdr_field = bdr_mapping['element']
        
    # Do we have a mapping to BDR data element?
    if bdr_field is not None:
        
        # If we have locally defined mappings that override EDAD mappings
        for field in fields:
            field_name = field.keys()[0]
            
            has_auth = True
            authority = bdr_mapping['authority']
            if authority is None or len(authority) == 0:
                has_auth = False
                
            print "FIELD NAME:",field_name
            # If we have a locally defined mapping rule, merge the spreadsheet values into our local rule
            # so we can include any extra logic defined in our mapping language
            if field_name.lower() == bdr_field.lower():
                
                try:
                    mdr_field = field
                    if bdr_target_field is not None:
                        if has_auth:
                            mdr_field[field_name]['authority'] = authority
                        
                        mdr_field[field_name]['source'] = bdr_mapping['source']
                        
                        mdr_field[field_name]['note'] = 'Changed target field from '+mdr_field[field_name]['field']+' to '+bdr_target_field
                        mdr_field[field_name]['field'] = bdr_target_field
                        mdr_field[field_name]['definition'] = bdr_mapping['definition']
                        mdr_field[field_name]['businessName'] = bdr_mapping['businessname']
                        mdr_field[field_name]['alias'] = bdr_mapping['businessname'].replace(' ','')
                except:
                    print traceback.format_exc()
                    mdr_field = None
        
    # There are no locally pre-defined mappings, use the EDAD ones
    if mdr_field is None:
        print "BDR_FIELD: ",bdr_field
        mdr_field = {}
        mdr_field[bdr_field] = {}
        mdr_field[bdr_field]['source'] = bdr_mapping['source']
        if has_auth:
            #if authority != mdr_field[bdr_field]['source']:
            #    return None
                
            mdr_field[bdr_field]['authority'] = authority
        
        mdr_field[bdr_field]['note'] = 'Changed target field from '+bdr_field+' to '+bdr_target_field
        mdr_field[bdr_field]['field'] = bdr_target_field
        mdr_field[bdr_field]['definition'] = bdr_mapping['definition']
        mdr_field[bdr_field]['businessName'] = bdr_mapping['businessname']
        mdr_field[bdr_field]['action'] = 'remap'
        mdr_field[bdr_field]['alias'] = bdr_mapping['businessname'].replace(' ','')
        
        for field in fields:
            field_name = field.keys()[0]
            if field_name.lower() == bdr_field.lower():
                mdr_field[bdr_field].update(field[field.keys()[0]])
                
    #return (bdr_mapping,bdr_field,mdr_field)
    return mdr_field
    
bdr_mdr_fields = bdr_map.map(lambda x: (x,oa_mapping)).map(merge_bdr_mdr).filter(lambda x: x is not None).collect() 

def update_oa_fields(mapping,bdrfields):
    
    newfields = []
    updates = []
    seen_fields = []
    for field in mapping['fields']:
        bdr_exists = False
        for bdr_field in bdrfields:
            if bdr_field.keys()[0] not in seen_fields:
                if bdr_field.keys()[0].lower() == field.keys()[0].lower():
                    newfields += [bdr_field]
                    updates += [bdr_field]
                    seen_fields += [bdr_field.keys()[0]]
                    bdr_exists = True
        if bdr_exists == False and field.keys()[0] not in seen_fields:
            newfields += [field]
            seen_fields += [field.keys()[0]]
            
    return newfields, updates
    

oa_mapping['fields'] = [mapping for mapping in oa_mappings + bdr_mdr_fields if 'field' in mapping[mapping.keys()[0]]]

'''
Create MDR dataframes and tables
'''
mdrFieldsRDD = sc.parallelize(oa_mapping['fields'])
mdrFieldsDF = mdrFieldsRDD.map(lambda x: x[x.keys()[0]]).toDF()
mdrFieldsDF.createOrReplaceTempView("mdrmapping")
mdrFieldsDF.printSchema()

'''
Store in Hive
'''
try:
   hive.sql("drop table bdr.mdr")
except:
   pass

hive.sql("CREATE TABLE "+BDRMDRHIVETABLE+" STORED AS ORC AS SELECT * from mdrmapping")

'''
Generate Java/Universal properties file
'''
def generate_properties(mapping):
    
    BDR = "bdr"
    bdr_properties_en_file = ""
    for _field in mapping['fields']:
        #print _field
        field = _field[_field.keys()[0]]
        if field.has_key('alias'):
            if len(field['alias']) == 0:
                continue
            bdr_properties_en_file += BDR+".jsonname."+field['alias']+" = \""+field['field']+"\"\n"
            if field.has_key('businessName'):
                bdr_properties_en_file += BDR+".businessname."+field['alias']+" = \""+field['businessName']+"\"\n"
        
    return bdr_properties_en_file
    
bdr_properties_en_file = generate_properties(oa_mapping)
print bdr_properties_en_file
bdr_properties = sc.parallelize([bdr_properties_en_file])

bdr_properties.saveAsTextFile(MDRPROPERTIESFILE)


'''
Save out mapping file
'''
import base64, json

oa_mapping_str = json.dumps(oa_mapping)
encoded = base64.b64encode(oa_mapping_str)
mappingRDD = sc.parallelize([encoded])
mappingRDD.saveAsTextFile(MAPPING_FILE)

'''
Create Elastic Mapping File
'''
import json 

def update_es_mapping(oamapping):
    
    es_mapping = {}
    es_mapping['properties'] = {}
    
    for field in oamapping:
        if field['jsonname'].find('Date') > -1:
            es_mapping['properties'][field['jsonname']] = {"type":"date","format":"yyyy-MM-dd"}

    return es_mapping
    
es_mapping = update_es_mapping(bdr_map.collect())
print json.dumps(es_mapping,indent=4)

f=open('/tmp/oa_index_mapping.json','w')
f.write(json.dumps(es_mapping,indent=4))
f.close()


'''
Update Elastic OA Index
'''
import os

os.system("curl -XPOST http://"+ESNODES+"/"+OAINDEX+"/_close")
os.system("curl -XPUT http://"+ESNODES+"/"+OAINDEX+"/_mapping/"+OATYPE+" -d @/tmp/oa_index_mapping.json")
os.system("curl -XPOST http://"+ESNODES+"/"+OAINDEX+"/_open")


'''
Send notify email
'''
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


templ_str = '<html><head/><body><h2>BDR/MDR Mapping Merge Complete</h2>NOTE: Missing fields highlighted in <span style="color:red">RED</span><hr> \
<p><b>Source Spreadsheet:</b> <a href="https://prod-cicm.uspto.gov/scm/svn/DSDA-BDR-DEV/documentation/DEV/MDR/BDR%20Data%20Element%20Mapping.xlsx">here</a></p> \
<p><b>Mapping File:</b> hdfs://bdr-itwv-hue-1.dev.uspto.gov/data/mappings.jsonl</p> \
<p><b>Updated Fields:</b></p> \
FIELDS \
<hr> \
<p><b>Total Fields: </b> <h2>TOTAL</h2> \
</body></html>'


class Notify(object):

    def render_template(self, rv, data):
        for key in data:
            rv = rv.replace(key,data[key])
        return rv

    def get_messages(self, templ, data):
        rich = self.render_template(templ, data)

        return {'html': rich}

    def compose_email(self, template, subj, to, data):
        content = self.get_messages(template, data)

        from_addr = 'BDR_Tech@uspto.gov'

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subj
        msg['From'] = from_addr
        msg['To'] = to

        part2 = MIMEText(content['html'], 'html')

        msg.attach(part2)

        return msg

    def send_mail(self, msg):
        #s = smtplib.SMTP("smtpedge1.uspto.gov")
        s = smtplib.SMTP("mailer.uspto.gov")
        s.sendmail(msg['From'], msg['To'], msg.as_string())
        s.quit()

    def notify(self, template, subj, to, data):

        msg = self.compose_email(template, subj, to, data)
        self.send_mail(msg)



parms = {}
parms['TOTAL'] = str(len(oa_mapping['fields']))
fieldstr = ""
for field in oa_mapping['fields']:
    fieldstr += "FIELD: <b>"+field.keys()[0]+"</b><hr>"
    ufield = field[field.keys()[0]]
    for key in ufield:
        if ufield[key] is None:
            ufield[key] = ""
        if len(ufield[key]) == 0:
            fieldstr += "<b><span style=\"color:red\">"+key+"</span>:</b>  "+ufield[key]+"<br>"
        else:
            fieldstr += "<b>"+key+":</b> "+ufield[key]+"<br>"
    fieldstr += "<br>"
    
parms['FIELDS'] = fieldstr.encode('utf8')
notify = Notify()
msg = notify.compose_email( templ_str.encode('utf8'), 'BDR: MDR/EDAD Mapping Merge Completed', 'BDR_tech@uspto.gov', parms)
notify.send_mail(msg)
print "Email sent"
