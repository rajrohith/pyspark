
import sys,os
import json
import base64
import datetime
from operator import add

from pyspark.sql import SparkSession
from pyspark.sql import HiveContext
from pyspark.sql import Row

import os,itertools
import smtplib, traceback, hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import ConfigParser
config_path=sys.argv[1]

spark = SparkSession.builder.appName("OAMerge").enableHiveSupport().getOrCreate()
    
started = str(datetime.datetime.now())

if os.path.exists(config_path+'/bdr-oamerge.properties'):
    config = ConfigParser.RawConfigParser()
    config.read(config_path+'/bdr-oamerge.properties')
    OAMDRHIVETABLE      = config.get('bdr','OAMDRHIVETABLE')
    APPMDRHIVETABLE     = config.get('bdr','APPMDRHIVETABLE')
    OAMDRERRORDATA      = config.get('bdr','OAMDRERRORDATA')
    ESNODES             = config.get('bdr','ESNODES')
    OAINDEX             = config.get('bdr','OAINDEX')
    OATYPE              = config.get('bdr','OATYPE')
    MAPPING_FILE        = config.get('bdr','MAPPING_FILE')
    OAMDRHDFSPARQUET    = config.get('bdr','OAMDRHDFSPARQUET')
    ESUSER	            = config.get('bdr','ESUSER')
    ESPASSWORD	        = config.get('bdr','ESPASSWORD')
'''
Email template string
'''
templ_str = '<html><head/><body><h2>OA/CMS/Palm Merged Data Set Complete</h2><hr> \
<p><b>OA Merged Data Set (parquet) HDFS URL:</b><br> '+OAMDRHDFSPARQUET+OAMDRHIVETABLE+'<br> \
<p><b>OA Merged Data Set Hive table:</b><br> '+OAMDRHIVETABLE+'<br> \
<p><b>APP Merged Data Set Hive table:</b><br> '+APPMDRHIVETABLE+'<br> \
<p><b>OA MDR Mapping (JSON) HDFS URL:</b><br> '+MAPPING_FILE+'<br> \
<hr> \
<p><b>Total Documents Merged: </b> <h2>COUNT</h2> \
<p><b>Total Documents Indexed: </b> <h2>INDEXED</h2> \
<hr> \
<p><b>Started: </b> <h2>STARTED</h2> \
<p><b>Completed: </b> <h2>COMPLETED</h2> \
<p><b>   Error: </b> <h2>EXCEPTION</h2> \
</body></html>'

print("Using ES Nodes: "+ESNODES)

def group(x,y):
    r = []
    if type(x) is dict:
        r+=[x]
    elif type(x) is list:
        r+=x

    if type(y) is dict:
        r+=[y]
    elif type(y) is list:
        r+=y

    return r

def get_rejections(row):
    import hashlib
    
    keys = row['patentApplicationNumber']
    keys += row['obsoleteDocumentIdentifier']
    _id = hashlib.sha224(keys).hexdigest()

    return (_id,{'position':row['position'],'type':row['rejectionType'],'paragraph':row['paragraph'],'label':row['rejectionType']+'('+row['paragraph']+')'})

class Notify(object):

    def render_template(self, rv, data):
        for key in data:
            rv = rv.replace(key,data[key])
        return rv

    def get_messages(self, templ, data):
        rich = self.render_template(templ, data)

        return {'html': rich}

    def compose_email(self, template, subj, to, data):
        content = self.get_messages(template, data)

        from_addr = 'BDR_Tech@uspto.gov'

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subj
        msg['From'] = from_addr
        msg['To'] = to

        part2 = MIMEText(content['html'], 'html')

        msg.attach(part2)

        return msg

    def send_mail(self, msg):
        #s = smtplib.SMTP("smtpedge1.uspto.gov")
        s = smtplib.SMTP("mailer.uspto.gov")
        s.sendmail(msg['From'], msg['To'], msg.as_string())
        s.quit()

    def notify(self, template, subj, to, data):

        msg = self.compose_email(template, subj, to, data)
        self.send_mail(msg)

def package(doc,pkeys=[]):
    """
  
    """
    import json
    import hashlib
    
    if type(doc) is tuple:
        doc = doc[1]
    _json = json.dumps(doc)
    keys = doc.keys()
    for key in keys:
        if doc[key] == 'null' or doc[key] == 'None':
            del doc[key]
        else:
            # If we have a datetime, strip off the time
            if key[-4:] == 'Date' and doc[key].find('T') > -1:
                doc[key] = doc[key].split('T')[0]
    if not doc.has_key('id'):
        key = ""
        #key += doc['obsoleteDocumentIdentifier']
        #key += doc['patentApplicationNumber']
        if len(pkeys) == 0:
           id = hashlib.sha224(_json).hexdigest()
           doc['id'] = id
        else: 
           for _key in pkeys:
              if type(doc[_key]) is int:
                key += str(doc[_key])
              
              if type(doc[_key]) is str or type(doc[_key]) is unicode:
                key += str(doc[_key].encode('utf-8').decode('string_escape'))
            
           id = hashlib.sha224(key).hexdigest()
           doc['id'] = id
    else:
        id = doc['id']

    _json = json.dumps(doc)
    return (id, _json)


try:

    import json, traceback, datetime, hashlib, sys
    from functools import partial
    from pyspark.sql import HiveContext

    #################################################################################################################
    # SUPPORT FUNCTIONS
    #################################################################################################################
    def get_oamdr(row):
        import hashlib

	keys = row['patentApplicationNumber']
        keys += row['obsoleteDocumentIdentifier']
        _id = hashlib.sha224(keys).hexdigest()

        return (_id, row)

    def get_sections(row):
        import hashlib

        keys = row['patentApplicationNumber']
        keys += row['obsoleteDocumentIdentifier']
        _id = hashlib.sha224(keys).hexdigest()

        return (_id, row)

    def get_rejections(row):
        import hashlib

        keys = row['patentApplicationNumber']
        keys += row['obsoleteDocumentIdentifier']
        _id = hashlib.sha224(keys).hexdigest()

        return (_id, {'position': row['position'], 'type': row['rejectionType'], 'paragraph': row['paragraph'],
                      'label': row['rejectionType'] + '(' + row['paragraph'] + ')'})

    def group(x, y):
        import hashlib
        r = []
        if type(x) is dict:
            r += [x]
        elif type(x) is list:
            r += x

        if type(y) is dict:
            r += [y]
        elif type(y) is list:
            r += y

        return r


    #################################################################################################################
    # HIVE CONTEXT
    #################################################################################################################
    hive = HiveContext(spark)

    print(spark.version)

    #################################################################################################################
    # SELECT OAMDR DOCUMENTS THAT MATCH ANY REJECTIONS AND SECTION DATA
    #################################################################################################################

    print("--SELECTING OAMDR DOCS--------------------------------------------------------------------------------")
    oamdr = hive.sql(
        "select distinct oa.* from bdr.oamdr_delta as oa") 
    oamdr.createOrReplaceTempView("oamdrtiny")
    oamdr.persist()
    oamdr_count = oamdr.count()

    if oamdr_count == 0:
        print
        "No documents to merge. Exiting"
        sys.exit(0)

    #################################################################################################################
    # COUNT OAMDR DOCUMENTS
    #################################################################################################################
    mdrMappedRDD1 = spark.sql("select * from oamdrtiny")
    mdrMappedRDD = mdrMappedRDD1.rdd.map(lambda y: y.asDict()).map(get_oamdr)

    mdrMappedRDDCount = mdrMappedRDD.count()
    mdrMappedRDDCount, " OAMDR documents found."


    def package(doc, pkeys=[]):
        """

        """
        import json
        import hashlib

        if type(doc) is tuple:
            doc = doc[1]
        _json = json.dumps(doc)
        keys = doc.keys()
        for key in keys:
            if doc[key] == 'null' or doc[key] == 'None':
                del doc[key]
            else:
                # If we have a datetime, strip off the time
                if key[-4:] == 'Date' and doc[key].find('T') > -1:
                    doc[key] = doc[key].split('T')[0]
        if not doc.has_key('id'):
            key = ""
            if len(pkeys) == 0:
                id = hashlib.sha224(_json).hexdigest()
                doc['id'] = id
            else:
                for _key in pkeys:
                    if type(doc[_key]) is int:
                        key += str(doc[_key])

                    if type(doc[_key]) is str or type(doc[_key]) is unicode:
                        key += str(doc[_key].encode('utf-8').decode('string_escape'))

                id = hashlib.sha224(key).hexdigest()
                doc['id'] = id
        else:
            id = doc['id']

        _json = json.dumps(doc)
        return (id, _json)

    from elasticsearch import Elasticsearch, RequestsHttpConnection, serializer, compat, exceptions
    class JSONSerializerPython2(serializer.JSONSerializer):
        """Override elasticsearch library serializer to ensure it encodes utf characters during json dump.
        See original at: https://github.com/elastic/elasticsearch-py/blob/master/elasticsearch/serializer.py#L42
        A description of how ensure_ascii encodes unicode characters to ensure they can be sent across the wire
        as ascii can be found here: https://docs.python.org/2/library/json.html#basic-usage
        """

        def dumps(self, data):
            # don't serialize strings
            if isinstance(data, compat.string_types):
                return data
            try:
                return json.dumps(data, default=self.default, ensure_ascii=True)
            except (ValueError, TypeError) as e:
                raise exceptions.SerializationError(data, e)


    package_call = partial(package, pkeys=['patentApplicationNumber', 'obsoleteDocumentIdentifier'])
    mergeRejMDR = mdrMappedRDD.map(package_call)

    #################################################################################################################
    # PUSH TO ELASTIC
    #################################################################################################################
    mergeRejMDR.saveAsNewAPIHadoopFile(
        path='-',
        outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
        keyClass="org.apache.hadoop.io.NullWritable",
        valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",
        conf={"es.resource": OAINDEX + "/" + OATYPE, "es.mapping.id": "id", "es.input.json": "true",
              "es.batch.write.retry.count": "10", "es.batch.size.bytes": "10mb", "es.batch.write.refresh": "false",
              "es.net.http.auth.user": ESUSER, "es.batch.size.entries": "1000", "es.write.operation": "index",
              "es.nodes.wan.only": "true", "es.net.http.auth.pass": ESPASSWORD, "es.net.ssl": "true",
              "es.nodes": ESNODES, "es.port": "9200"})
    numdocs = mergeRejMDR.count()
    print(str(numdocs) + " rejection merged docs pushed to elastic successfully.")
    spark.sql(
        "insert into bdr.job_log select  'bdr-oamerge','oamergerej',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP ,'completed','No.of rejection merged docs pushed to elastic'," + str(
            numdocs))

except:
    print(traceback.format_exc())
    error = {}
    error['date'] = str(datetime.datetime.now())
    error['trace'] = traceback.format_exc()
    error['unit'] = 'oamerge'
    key = hashlib.sha224(error['date']).hexdigest()
    error['key'] = key
    print(json.dumps(error,indent=4))
    errorRDD = spark.sparkContext.parallelize([error])
    errorRDD.saveAsTextFile('/data/errors/'+key)
    sys.exit(1)
