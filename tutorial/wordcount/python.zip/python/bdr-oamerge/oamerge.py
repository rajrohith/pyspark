import sys,os
import json
import base64
import datetime
from operator import add

from pyspark.sql import SparkSession
from pyspark.sql import HiveContext

from pyspark.sql import Row

import os,itertools
import smtplib, traceback, hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import ConfigParser
config_path=sys.argv[1]

spark = SparkSession.builder.appName("OAMerge").enableHiveSupport().getOrCreate()
    
hive = HiveContext(spark)

started = str(datetime.datetime.now())

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-oamerge.properties')
OAMDRHIVETABLE      = config.get('bdr','OAMDRHIVETABLE') 
APPMDRHIVETABLE     = config.get('bdr','APPMDRHIVETABLE') 
OAMDRERRORDATA      = config.get('bdr','OAMDRERRORDATA') 
ESNODES	            = config.get('bdr','ESNODES')     
OAINDEX             = config.get('bdr','OAINDEX') 
OATYPE              = config.get('bdr','OATYPE') 
ESUSER	            = config.get('bdr','ESUSER') 
ESPASSWORD	        = config.get('bdr','ESPASSWORD') 
MAPPING_FILE        = config.get('bdr','MAPPING_FILE') 
OAMDRHDFSPARQUET    = config.get('bdr','OAMDRHDFSPARQUET') 


'''
Email template string
'''
templ_str = '<html><head/><body><h2>OA/CMS/Palm Merged Data Set Complete</h2><hr> \
<p><b>OA Merged Data Set (parquet) HDFS URL:</b><br> '+OAMDRHDFSPARQUET+OAMDRHIVETABLE+'<br> \
<p><b>OA Merged Data Set Hive table:</b><br> '+OAMDRHIVETABLE+'<br> \
<p><b>APP Merged Data Set Hive table:</b><br> '+APPMDRHIVETABLE+'<br> \
<p><b>OA MDR Mapping (JSON) HDFS URL:</b><br> '+MAPPING_FILE+'<br> \
<hr> \
<p><b>Total Documents Merged: </b> <h2>COUNT</h2> \
<p><b>Total Documents Indexed: </b> <h2>INDEXED</h2> \
<hr> \
<p><b>Started: </b> <h2>STARTED</h2> \
<p><b>Completed: </b> <h2>COMPLETED</h2> \
<p><b>   Error: </b> <h2>EXCEPTION</h2> \
</body></html>'

print("Using ES Nodes: "+ESNODES)

def group(x,y):
    r = []
    if type(x) is dict:
        r+=[x]
    elif type(x) is list:
        r+=x

    if type(y) is dict:
        r+=[y]
    elif type(y) is list:
        r+=y

    return r

def get_rejections(row):
    import hashlib
    
    keys = row['patentApplicationNumber']
    keys += row['obsoleteDocumentIdentifier']
    _id = hashlib.sha224(keys).hexdigest()

    return (_id,{'position':row['position'],'type':row['rejectionType'],'paragraph':row['paragraph'],'label':row['rejectionType']+'('+row['paragraph']+')'})

class Notify(object):

    def render_template(self, rv, data):
        for key in data:
            rv = rv.replace(key,data[key])
        return rv

    def get_messages(self, templ, data):
        rich = self.render_template(templ, data)

        return {'html': rich}

    def compose_email(self, template, subj, to, data):
        content = self.get_messages(template, data)

        from_addr = 'BDR_Tech@uspto.gov'

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subj
        msg['From'] = from_addr
        msg['To'] = to

        part2 = MIMEText(content['html'], 'html')

        msg.attach(part2)

        return msg

    def send_mail(self, msg):
        #s = smtplib.SMTP("smtpedge1.uspto.gov")
        s = smtplib.SMTP("mailer.uspto.gov")
        s.sendmail(msg['From'], msg['To'], msg.as_string())
        s.quit()

    def notify(self, template, subj, to, data):

        msg = self.compose_email(template, subj, to, data)
        self.send_mail(msg)


def package(doc,pkeys=[]):
    """
  
    """
    import json
    import hashlib
    
    if type(doc) is tuple:
        doc = doc[1]
    _json = json.dumps(doc)
    keys = doc.keys()
    for key in keys:
        if doc[key] == 'null' or doc[key] == 'None':
            del doc[key]
        else:
            # If we have a datetime, strip off the time
            if key[-4:] == 'Date' and doc[key].find('T') > -1:
                doc[key] = doc[key].split('T')[0]
    if not doc.has_key('id'):
        key = ""
        #key += doc['obsoleteDocumentIdentifier']
        #key += doc['patentApplicationNumber']
        if len(pkeys) == 0:
           id = hashlib.sha224(_json).hexdigest()
           doc['id'] = id
        else: 
           for _key in pkeys:
              if type(doc[_key]) is int:
                key += str(doc[_key])
              
              if type(doc[_key]) is str or type(doc[_key]) is unicode:
                key += str(doc[_key].encode('utf-8').decode('string_escape'))
            
           id = hashlib.sha224(key).hexdigest()
           doc['id'] = id
    else:
        id = doc['id']

    _json = json.dumps(doc,ensure_ascii=False)
    return (id, _json)


def convert_utc_to_text(timestamp, fmt='%Y-%m-%d'):
    """

    """
    from datetime import datetime, timedelta  
    
    if timestamp < 0:
        #dt = datetime.utcfromtimestamp(float(timestamp)/1000)
        dt = datetime.strptime('20010101', "%Y%m%d").date()
    else:
        dt = datetime.utcfromtimestamp(timestamp)

    txt = dt.strftime(fmt)
    return txt.split('T')[0]


def transform_fields(document,mapping={}):
    """

    """
    import json, time, re, hashlib
    import datetime, traceback
    document = dict((k.lower(), v) for k,v in document.iteritems())

    def get_authority_mapping(transform):
        try:
            for mapping in mapping['fields']:
                if mapping['field'] == transform['field'] and mapping.has_key('authority') and mapping['source'] == transform['authority']:
                    return mapping
        except:
            # If there's a problem doing this, fall back onto the current mapping 
            pass
        
        return None
    
    
    try:
        validate = mapping['validate'] == 'true'
        if type(document) is not dict:
            return str(type(document))
        values = mapping['values']
        fields = {}
        _document = {} #document.copy()
        for mapping in mapping['fields']:
            _sourcekey = mapping.keys()[0]
            __key = _sourcekey.lower() #.strip()
            if not fields.has_key(__key):
                fields[__key] = []
            fields[__key] += [mapping[_sourcekey]]
            
        if mapping.has_key('filter'):
            filter = mapping['filter']
        else:
            filter = 'unmapped'
            
        idkeys = []
        
        for key in fields:
            if key[0] == '_': continue
        
            transforms = fields[key]
            
            for transform in transforms:
                if validate and required and len(transform['field']) == 0:
                    raise Exception('Validation Exception: transofmr field for key: '+key+' is missing.')
                elif len(transform['field']) == 0:
                    continue
                    
                if transform.has_key('authority'):
                    # If this field is governed by an authority, try to find it in the mappings list
                    # and replace this current transform with the authoritative one, otherwise
                    # use the current one.
                    _transform = get_authority_mapping(transform)
                    if _transform is not None:
                        transform = _transform
                        
                required = transform.has_key('required') and transform['required'] == 'true' and validate
                if validate and required:
                    if not document.has_key(key):
                        raise Exception('Validation Exception: Field '+key+' not present in source document.')
                elif not document.has_key(key):
                    
                    continue
                            
                if transform.has_key("if"):
                    if_clause = transform['if']
                    condition = if_clause['condition']
                    if condition == "value":
                        conditional_value = if_clause['value']
                        if not document.has_key(if_clause['field']):
                            if validate and required:
                                raise Exception('Validation Exception: Field '+if_clause['field']+' not present in source document.')
                            continue
                        else:
                            if not document[if_clause['field']] == if_clause['value']:
                                if validate and required:
                                    raise Exception('Validation Exception: Field '+if_clause['field']+' not equal to '+if_clause['value']+'.')
                                continue
                            
                    if condition == "exist":
                        # If the conditional field does not exist in the source document
                        # then we abort this transform
                        if not document.has_key(condition['field']):
                            if validate and required:
                                raise Exception('Validation Exception: Conditional field '+condition['field']+' not present in source document.')
                            continue

                if transform.has_key('key'):
                    if document.has_key(key):
                        idkeys += [document[key]]            
                    
                if transform['action'] == 'retype':
                    newtype = transform['type']
                    if newtype == 'str':
                        try:
                            _document[transform['field']] = str(document[key])
                        except Exception as ex:
                            if validate and required:
                                raise Exception('Validation Exception: '+ex.message)
                    
                    if newtype == 'number':
                        try:
                            _document[transform['field']] = long(document[key])
                        except Exception as ex:
                            if validate and required:
                                raise Exception('Validation Exception: '+ex.message)
                        
                if transform['action'] == 'copy':
                    _document[transform['field']] = document[key]
                    
                    
                if transform['action'] == 'remap':
                    if validate and not required:
                        if not document.has_key(key):
                            # Ignore that this key is not present because it is not labeled required
                            continue
                    if transform.has_key('type'):
                        data_type = transform['type']
                        if data_type == 'utc':
                            _document[transform['field']] = convert_utc_to_text(float(document[key]),'%Y-%m-%d').split('T')[0]
                        if data_type == 'date':
                            try:
                                format = transform['format']
                                
                                if type(document[key]) is not str and type(document[key]) is not unicode:
                                    continue
                                # Transform date text
                                dt = datetime.datetime.strptime(document[key], format)
                                timest = time.mktime(dt.timetuple())
                                _document[transform['field']] = timest
                            except Exception as ex:
                                if validate and required:
                                    raise Exception('Validation Exception: '+ex.message)
                                
                    else:
                        _document[transform['field']] = document[key]
                    
                if transform.has_key('regex'):
                    regex = transform['regex']
                    try:
                        if document.has_key(key) and document[key] is not None and len(document[key]) > 0:
                            newvalue = re.findall(regex,document[key])[0]
                            _document[transform['field']] = newvalue
                    except:
                        raise Exception('Validation Exception: '+ex.message)

        if _document.has_key('_corrupt_record'):
            del _document['_corrupt_record']
            
        for key in _document:
            if _document[key] is None:
                _document[key] = "null"
            if type(_document[key]) is str or type(_document[key]) is unicode:
                _document[key] = _document[key].strip()
                if len(_document[key]) == 0:
                    _document[key] = "null"
                
        if len(idkeys) > 0:
            _document['id'] = hashlib.sha224(''.join(idkeys)).hexdigest()
            
        return _document
    except:
        return traceback.format_exc()


def get_metadata(cms):
    """

    """
    from lxml import etree
    from io import StringIO, BytesIO
    import traceback

    try:
        xml = cms['xml'].encode('utf-8')
        parser = etree.XMLParser(ns_clean=True, recover=True, encoding='utf-8')
        root = etree.fromstring(xml, parser=parser)
        ns = {'xsi':'urn:us:gov:doc:uspto:patent','uspat':'urn:us:gov:doc:uspto:patent','uscom':'urn:us:gov:doc:uspto:common"'}
        metadata = root.xpath("//uspat:OutgoingDocument//uspat:DocumentMetadata",namespaces=ns)
        _metadata = {}
        _metadata['documentIdentifier'] = cms['documentIdentifier']
        fields = ['PartyIdentifier','DocumentSourceIdentifier','GroupArtUnitNumber','ApplicationNumberText']
        for field in metadata[0].getchildren():
            fieldname = field.tag.split("}")[1]
            if field.text is not None:
                _metadata[fieldname] = field.text
            else:
                _metadata[fieldname] = "None"
                
        for field in fields:
            if not _metadata.has_key(field):
                _metadata[field] = "None"
        return _metadata
    except:
        return None
        
        
from elasticsearch import Elasticsearch, RequestsHttpConnection, serializer, compat, exceptions

class JSONSerializerPython2(serializer.JSONSerializer):
    """Override elasticsearch library serializer to ensure it encodes utf characters during json dump.
    See original at: https://github.com/elastic/elasticsearch-py/blob/master/elasticsearch/serializer.py#L42
    A description of how ensure_ascii encodes unicode characters to ensure they can be sent across the wire
    as ascii can be found here: https://docs.python.org/2/library/json.html#basic-usage
    """
    def dumps(self, data):
        # don't serialize strings
        if isinstance(data, compat.string_types):
            return data
        try:
            return json.dumps(data, default=self.default, ensure_ascii=True)
        except (ValueError, TypeError) as e:
            raise exceptions.SerializationError(data, e)        
        
def get_text(cms):
    """
    
    """
    from lxml import etree
    from io import StringIO, BytesIO
    import traceback, hashlib, re
    steps = ""
    
    USPTO_COM = '{urn:us:gov:doc:uspto:common}'
    USPTO_PAT = '{urn:us:gov:doc:uspto:patent}'
    XML_COM = '{http://www.wipo.int/standards/XMLSchema/ST96/Common}'
    PARA = USPTO_COM + 'P'

    try:
        
        xml = cms['xml'].encode('latin1')
        _xml = re.sub(r"\<\?PageStart number=.*?\>","",xml)

        parser = etree.XMLParser(ns_clean=True, recover=True, encoding='utf-8')
        root = etree.fromstring(xml, parser=parser)
        ns = {'xsi':'urn:us:gov:doc:uspto:patent','com':'http://www.wipo.int/standards/XMLSchema/ST96/Common','uspat':'urn:us:gov:doc:uspto:patent','uscom':'urn:us:gov:doc:uspto:common'}
        metadata = root.xpath("//uspat:OutgoingDocument//uspat:DocumentMetadata",namespaces=ns)
        _metadata = {}
        for field in metadata[0].getchildren():
            fieldname = field.tag.split("}")[1]
            if field.text is not None:
                _metadata[fieldname] = field.text
            else:
                _metadata[fieldname] = "None"
        
        paragraphs = []
        
        etree.strip_tags(root,USPTO_COM+"GeneralText")
        etree.strip_tags(root,USPTO_COM+"BoundaryDataReference")
        for paragraph in root.getiterator(PARA):
            if paragraph.text is not None:
                texts = [node.text
                 for node in paragraph.getiterator()
                 if node.text]
                if texts:
                    paragraphs.append(''.join(texts))
               #paragraphs += [paragraph.text]

        text = '\n\n'.join(paragraphs)
        etree.strip_elements(root,XML_COM+"S")
        etree.strip_elements(root,USPTO_COM+"FormParagraphNumber")
        etree.strip_elements(root,USPTO_COM+"BoundaryDataReference")
        etree.strip_elements(root, USPTO_COM + "ExaminationProgramCode")
        etree.strip_elements(root, USPTO_PAT + "DocumentMetadata")
        etree.strip_elements(root, USPTO_COM + "SpannedBoundaryData")
        text = ''.join(root.itertext())
        text = re.sub(r"number='.'",' ',text)
        text = re.sub(r"AIA",'AIA ',text)
        uniq_id = hashlib.sha224(xml).hexdigest()
        cms['text'] = text
        del cms['xml']
        return {'appid':cms['appid'],'docid':cms['docid'],'text':cms['text']}
    except Exception as ex:
        cms['text'] = None
        cms['error'] = traceback.format_exc()
        return cms 




try:
    
    hive = HiveContext(spark)

    print(spark.version)
    '''
    Load Palm data
    '''
    palm_data = spark.read.json('/data/source/palm/PALM_PUBLIC/*.json')
    print(palm_data.count()," PALM records.")
    palm_data.createOrReplaceTempView("palm")
    
    '''
    Load CMS Metadata
    '''
    cms_metadata = hive.read.json("/data/source/cms/cms_metadata/")
    cms_metadata.createOrReplaceTempView("cmsMeta")
    print(cms_metadata.count()," metadata records.")
    
    '''
    Remove error data
    '''
    os.system("hdfs dfs -rmr -skipTrash /data/errors/cms 2> /dev/null")
    
    
    '''
    Load CMS OA XML data from Hive. Only completed status
    '''
    cms_xml = spark.read.json("/data/source/cms/cms_oaxml")
    cms_xml.createOrReplaceTempView("cms_oaxml")
    
    bdroamdr = hive.table(OAMDRHIVETABLE)
    bdroamdr.registerTempTable("oamdr")

    oamdr = spark.sql("select oamdr.obsoleteDocumentIdentifier as docid from oamdr")

    
    '''
    Create cms dataframe view
    '''
    cms_xml_docs = spark.sql("SELECT * FROM cms_oaxml ")

    '''
    Perform left_anti join to obtain only new cms_oaxml records
    '''
    delta = cms_xml_docs.join(oamdr, "docid", "left_anti")

    '''
    Assign the delta to our cms_xml rdd
    '''
    cms_xml_docs = delta
    deltaCount = cms_xml_docs.count()
    if deltaCount == 0:
       print "No delta documents found. Returning."
       sys.exit(0)

    print deltaCount," CMS OA XML documents retrieved." 
    cms_xml_rdd = cms_xml_docs.rdd
    cms_xml_text_rdd_text = cms_xml_rdd.map(lambda y: y.asDict()).map(get_text).map(lambda l: Row(**dict(l)))
    cms_xml_text_rdd = cms_xml_text_rdd_text.filter(lambda l: l['text'] is not None)
    cms_xml_text_rdd_errors = cms_xml_text_rdd_text.filter(lambda l: l['text'] is  None)
    CMSERRORS = cms_xml_text_rdd_errors.count()
    print CMSERRORS," XML or other parse errors."
    print "------------------------------------------"
    if CMSERRORS > 0:
        try:
            cms_xml_text_rdd_errors.saveAsTextFile("/data/errors/cms")
            print "Saved error data: /data/errors/cms"
        except:
            pass
        
    cms_df = cms_xml_text_rdd.toDF()
    cms_df.createOrReplaceTempView("cms")
    
    cmsDocCount = cms_df.count()
    print cmsDocCount, " valid CMS OA XML documents."
    
    
    '''
    Load tech center data 
    ''' 
    techcenter = hive.table("bdr.tech_center_mapping")
    techcenter.createOrReplaceTempView("tech")
    print techcenter.count()," tech center records."

    '''
    Perform OA Merge. Have not run through MDR engine yet.
    '''
    mergedCMSDF = spark.sql('SELECT palm.*,cms.*, cmsMeta.*,tech.* from palm, cms, cmsMeta,tech where cms.appid = palm.appl_id and palm.appl_id = cmsMeta.businessIdentifier and cms.docid = cmsMeta.documentIdentifier  and trim(palm.DN_DW_DN_GAU_CD) = trim(tech.groupartunitnumber)')
    mergedCMSDF.createOrReplaceTempView("cmsMerged")
    mergeCount = mergedCMSDF.count()
    print mergeCount," PALM/CMS/META/APP merged documents."
    if mergeCount == 0:
       print "No merged documents. Exiting"
       sys.exit(1) 
    
    
    '''
    Write base OA merged data to parquet
    '''
    #mergedCMSDF.write.mode("overwrite").parquet("hdfs://bdr-itwv-hue-1.dev.uspto.gov/data/parquet/cmsmerged")
    
    
    '''
    Load OA Mapping file
    '''
    oa_mapping_encoded = spark.read.json(MAPPING_FILE)
    oa_dict = oa_mapping_encoded.collect()[0].asDict()
    oa_mapping_json = base64.b64decode(oa_dict['_corrupt_record'])
    oa_mapping = json.loads(oa_mapping_json)
    
    #print json.dumps(oa_mapping,indent=4)
    
    
    '''
    Run mergedCMSDF data set through MDR transformer function. Only works with RDD and python dictionaries at the moment.
    '''
    from functools import partial
    
    transformer = partial(transform_fields,mapping=oa_mapping)
    #one = mergedCMSDF.rdd.map(lambda y: y.asDict()).take(1)
    #print json.dumps(one,indent=4)
    #result = transform_fields(one[0],mapping=oa_mapping)
    #print json.dumps(result,indent=4)
    
    """ 
    Build appmdr table
    """ 
    palmTechDF = spark.sql('SELECT palm.*, tech.* from palm, tech where  trim(palm.DN_DW_DN_GAU_CD) = trim(tech.groupartunitnumber)')
    palmTechDF.createOrReplaceTempView("palmTech")
    palmTechMappedDF = palmTechDF.rdd.map(lambda y: y.asDict()).map(transformer).map(lambda l: Row(**dict(l))).toDF()
    palmTechMappedDF.createOrReplaceTempView("appMdr")

    appMDRCount = palmTechMappedDF.count()
    print "Writing ",appMDRCount," appmdr ocuments to hive."
    palmTechMappedDF.write.insertInto(APPMDRHIVETABLE,overwrite = True)

    
    """
    Push appmdr to elastic
    """
    print("Pushing appmdr table to elastic....")
    try:
       package_call = partial(package, pkeys=['patentApplicationNumber','obsoleteDocumentIdentifier'])
       addMdrRDD = palmTechMappedDF.rdd.map(lambda y: y.asDict()).map(package_call)
       print(addMdrRDD.take(1))
       addMdrRDD.saveAsNewAPIHadoopFile(
        path='-', 
        outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
        keyClass="org.apache.hadoop.io.NullWritable",  
        valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
        conf={ "es.resource" : "app/app", "es.mapping.id":"id", "es.input.json": "true","es.batch.write.retry.count":"10","es.batch.size.bytes":"10mb","es.batch.write.refresh":"false","es.net.http.auth.user":ESUSER,"es.batch.size.entries":"5000","es.write.operation":"index","es.nodes.wan.only":"true","es.net.http.auth.pass":ESPASSWORD,"es.net.ssl":"true","es.nodes":ESNODES, "es.port":"9200" })
       print("appmdr pushed to elastic successfully.")
    except Exception as ex:
       print traceback.format_exc()
       sys.exit(1)

    """
    Run the MDR transformer. Separate error data from clean data
    """
    mdrMappedRDD = mergedCMSDF.rdd.map(lambda y: y.asDict()).map(transformer).filter(lambda l: not l.has_key('error'))
    mdrMappedErrorsRDD = mergedCMSDF.rdd.map(lambda y: y.asDict()).map(transformer).filter(lambda l: l.has_key('error'))
    errorCount = mdrMappedErrorsRDD.count()
    print errorCount," MDR errors." 
    """
    Write MDR error documents to parquet
    """
    try:
       mdrMappedErrorsRDD.map(lambda l: Row(**dict(l))).toDF().write.mode("overwrite").parquet(OAMDRHDFSPARQUET+OAMDRERRORDATA)
       print("Wrote "+str(errorCount)+" errored MDR Documnents to "+OAMDRHDFSPARQUET+OAMDRERRORDATA)
    except:
       #print traceback.format_exc()
       pass # If we can't write error data then proceed
    
    
    mdrMappedRDDCount = mdrMappedRDD.count()
    print(str(mdrMappedRDDCount)+" documents passed MDR validation.")
    
    '''
    Convert mdr mapped RDD back to dataframe for storage.
    '''
    mdrMappedDF = mdrMappedRDD.map(lambda l: Row(**dict(l))).toDF()
    
    '''
    Create OAMDR table
    '''
    mdrMappedDF.createOrReplaceTempView("oamdr_table")
    
    #Export OA MDR mapped dataset to hive table
    #try:
    #   hive.sql("drop table "+OAMDRHIVETABLE)
    #except:
    #   pass
    
    #hive.sql("CREATE TABLE "+OAMDRHIVETABLE+" STORED AS ORC  AS SELECT * from oamdr_table")
    
    #mdrMappedDF.write.mode("append").saveAsTable(OAMDRHIVETABLE);
    mdrMappedDF.write.insertInto(OAMDRHIVETABLE, overwrite = False)


    print "Storing oamdr_delta data set..."
    mdrMappedDF.registerTempTable("oamdr_delta")
    try:
      hive.sql("drop table bdr.oamdr_delta")
    except:
      pass

    hive.sql("CREATE TABLE bdr.oamdr_delta STORED AS ORC AS SELECT * from oamdr_delta")

    '''
    Write OA documents to elastic. Rejection merge step will update any documents that are found to contain rejections from this push.
    '''
    try:
       package_call = partial(package, pkeys=['patentApplicationNumber','obsoleteDocumentIdentifier'])
       mdrMappedRDDES = mdrMappedRDD.map(package_call)
       mdrMappedRDDES.saveAsNewAPIHadoopFile(
        path='-',
        outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
        keyClass="org.apache.hadoop.io.NullWritable",
        valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable",
        conf={ "es.resource" : OAINDEX+"/"+OATYPE, "es.mapping.id":"id", "es.input.json": "true","es.batch.write.retry.count":"10","es.batch.size.bytes":"10mb","es.batch.write.refresh":"false","es.net.http.auth.user":ESUSER,"es.batch.size.entries":"5000","es.write.operation":"index","es.nodes.wan.only":"true","es.net.http.auth.pass":ESPASSWORD,"es.net.ssl":"true","es.nodes":ESNODES, "es.port":"9200" })
       numdocs = mdrMappedRDDES.count()
       print(str(numdocs)+" OA documents pushed to elastic successfully.")
       spark.sql("insert into bdr.job_log select  'bdr-oamerge','oamerge',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP ,'completed','No.of OA documents pushed to elastic',"+str(numdocs))
    except Exception as ex:
       print traceback.format_exc()
       sys.exit(1)
	   
except:
    print traceback.format_exc()
    error = {}
    error['date'] = str(datetime.datetime.now())
    error['trace'] = traceback.format_exc()
    error['unit'] = 'oamerge'
    key = hashlib.sha224(error['date']).hexdigest()
    error['key'] = key
    print json.dumps(error,indent=4)
    errorRDD = spark.sparkContext.parallelize([error])
    errorRDD.saveAsTextFile('/data/errors/'+key)
    sys.exit(1)

