# script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# export HADOOP_USER_NAME=hdfs
# ./oamerge.sh <doc count>
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values

#########################################################################################

PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-oamerge'
DOCCOUNT=$1
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs/bdr-oamerge'
RUNDATE=$(date +'%Y%m%d')
export HADOOP_USER_NAME=hdfs
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "Starting $JOB:" $(date +'%Y-%m-%d:%H:%M')
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-oamerge' 'oamerge' 'started' $startdatetime

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $EXTRAJARPATH/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar --conf spark.executor.memory=60g --conf spark.driver.memory=25g --conf spark.executor.cores=15 --conf spark.executor.instances=5  --conf spark.yarn.executor.memoryoverhead=40g  $CODEPATH/oamerge.py $CODEPATH
if [ $? -ne 0 ]; then
  echo "oamerge script failed"
  /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-oamerge' 'oamerge' 'error' $startdatetime
 
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')

