#!/bin/bash

########################################################################################

# This script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# export HADOOP_USER_NAME=hdfs
# ./oamapping.sh
# 
# Please change the CODEPATH, EXTRAJARPATH, LOGPATH, READFROMHDFS & WRITETOHDFS  to appropriate values

#########################################################################################

PATH=/usr/lib64/qt-3.3/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-oamerge'
DOCCOUNT=$1
EXTRAJARPATH='/usr/hdp/current/spark2-client/jars'
LOGPATH='/data/bdr/logs/bdr-oamerge'
RUNDATE=$(date +'%Y%m%d')
export HADOOP_USER_NAME=hdfs

#exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
echo "Starting $JOB:" $(date +'%Y-%m-%d:%H:%M')

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn  --conf spark.executor.memory=4g --conf spark.driver.memory=8g  $CODEPATH/oamapping.py $CODEPATH

if [ $? -ne 0 ]; then
  echo "Spark-submit Python script failed"
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
