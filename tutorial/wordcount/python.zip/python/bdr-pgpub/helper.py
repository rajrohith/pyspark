from __future__ import print_function
import requests
import os
import zipfile
import xmltodict
from bs4 import BeautifulSoup
from tqdm import tqdm
import pandas as pd
import glob
import codecs
import datetime
import traceback
import json
import hashlib

def downloadSaveAndUnzip(url, saveDir, unzipDir):
    '''
    Downloads and extracts files from url
    Input: a downloadable url, directory to save the file, and directory to unzip the file to
    
    Output: An unzipped xml file (not returned), and the xml and zip filenames
    '''
    r = requests.get(url)
    downloadFileName = url[-13:]
    saveFileName = os.path.join(saveDir,downloadFileName)

    open(saveFileName, 'wb').write(r.content)

    #unzipDir = '/data/wsolomon/workspace/data/raw/pgpubBDSS'

    zip_ref = zipfile.ZipFile(saveFileName, 'r')
    zip_ref.extractall(unzipDir)
    unzipped_fn = zip_ref.namelist()[0]
    zip_ref.close()
    
    return str(saveFileName), os.path.join(unzipDir, unzipped_fn) #os.path.join(unzipDir, str(saveFileName[:-4]+'.xml'))

def extractAllXMLs(fileName, newFolder):
    '''
    Extracts each xml doc to its own file from the large unzipped single file
    '''
    os.system('mkdir -p '+ newFolder)
    #print('folder created?: ', os.path.isdir(newFolder))
    #print('old extracted file: ', fileName)

    with codecs.open(fileName, 'r+',  encoding='utf-8') as oldFileName:
        i = 1
        for line in oldFileName:
            new = os.path.join(newFolder, (str(i) +'.xml'))
            with codecs.open(new, 'w',  encoding='utf-8') as newFileName:
                #for line in oldFileName:
                #    if line.strip().startswith('<?xml'):
                #        break
                newFileName.seek(0)
                newFileName.write('<?xml version="1.0" encoding="UTF-8"?>')

                for line in oldFileName:
                    if line.startswith('<!DOCTYPE'):
                        pass

                    if line.startswith('<?xml'):
                        i += 1
                        break
                    newFileName.write(line)
    os.system('sudo chmod 777 -R '+ newFolder) #os.system('sudo chmod 777 -R '+ newFolder)
    
def extractFields(folder):
    '''
    Extracts the following fields from each extracted xml doc in the input folder:
    pgpub #, appId #, abstract text, specification text, and claim text
    '''
    
    pgpubs = []
    appids = []
    titles = []
    abstracts = []
    specs = []
    claims_all = []

    #new = '/data/wsolomon/workspace/data/raw/pgpubBDSS/new/10.xml'
    for filename in glob.iglob(os.path.join(folder,'*.xml')):
        #print filename
        with open(filename, 'r') as newFile:
            soup = BeautifulSoup(newFile, 'html.parser')
            try:
                doc_nums = soup.find_all('doc-number')
                #print(doc_nums)
                pgpubs.append(doc_nums[0].get_text())
            except(Exception):
                pgpubs.append('NA')
                
            try:
                desc = soup.find_all('description')  
                if len(desc) > 0:
                    specs.append(desc[0].get_text())
                else:
                    desc = soup.find_all('subdoc-description')
                    specs.append(desc[0].get_text())
            except(Exception):
                desc = 'NA'
                specs.append(desc)



            try:
                doc_nums = soup.find_all('doc-number')
                appids.append(doc_nums[1].get_text())
            except(Exception):
                appids.append('NA')

            try:
                claims = soup.find_all('claims')
                if len(claims) > 0:
                    claims_text = claims[-1].get_text()
                    claims_text = claims_text.replace('\n\n\n','XXX').replace('\n','').replace('XXX','\n ')
                    claims_all.append(claims_text)
                else:
                    claims = soup.find_all('subdoc-claims')
                    claims_text = claims[-1].get_text()
                    claims_text = claims_text.replace('\n\n\n','XXX').replace('\n','').replace('XXX','\n ')
                    claims_all.append(claims_text)
            except(Exception):
                claims_all.append('NA')

            try:
                abstract = soup.find_all('abstract')
                if len(abstract) > 0:
                    abstracts.append(str(abstract[0].get_text()))
                else:
                    abstract = soup.find_all('subdoc-abstract')
                    abstracts.append(str(abstract[0].get_text()))
            except(Exception):
                abstracts.append('NA')
            
            try:
                title = soup.find_all('invention-title')
                if len(title)>0:
                    titles.append(title[0].get_text())
                else:
                    title = soup.find_all('title-of-invention')
                    titles.append(title[0].get_text())
            except:
                titles.append('NA')
                
    #count = len(pgpubs)
    #files = len(next(os.walk(dir))[2])
    #print count," / ", files, 'files parsed'
    os.system('chmod 777 -R ' + folder) 
    return pgpubs, appids, titles, abstracts, specs, claims_all

def loadAppendSaveJSON(jsonFileName, spark, pgpubs, appids, titles, abstracts, specs, claims_all):
    '''
    Loads and appends the JSON file with the input extracted data and then pushes the concatinated JSON to hdfs
    '''
    if os.path.isfile(jsonFileName):
        #df_load = pd.read_json(jsonFileName)
        #df_load = spark.read.json(jsonFileName)
        overwrite = True
    else:
        #print 'Creating First JSON'
        #df_load = pd.DataFrame()
        overwrite = False
    
    df_new = pd.DataFrame()
    df_new['pgpub'] = pgpubs
    df_new['appId'] = appids
    df_new['title'] = titles
    df_new['abstract'] = abstracts
    df_new['spec'] = specs
    df_new['claims'] = claims_all
    
    df_spark_new = spark.createDataFrame(df_new)
    #df_spark_new.printSchema()
    #df_spark_new.show()
    
    #df_concat = pd.concat([df_load, df_new])
    #df_concat.to_json(jsonFileName, orient='records')
    #os.system('hdfs dfs -put -f '+ jsonFileName + ' ' + hdfsLocation)
    #df_concat = df_load.union(df_spark_new)
    
    try:
        df_spark_new.write.json(jsonFileName, mode = 'append')
    except(Exception):
        print('Createing New JSON in HDFS')
        df_spark_new.write.json(jsonFileName)

def cleanUp(zipFileName, xmlFileName, newExtractFolder):
    #os.system('chmod 777 -R /data/wsolomon/workspace/data/raw/pgpubBDSS')
    os.system('rm '+ zipFileName)
    os.system('rm '+ xmlFileName)
    os.system('rm -rf '+ newExtractFolder)

def getConfigs():
    start_date = os.environ['JOB_CNTL_TIMESTAMP_FORMATTED'] #20100801
    save_location = os.environ['LOCAL_TEMP_SAVE_FOLDER'] #os.path.join(os.environ['ROOT_PATH'], os.environ['LOCAL_TEMP_SAVE_FOLDER'])#'/data/wsolomon/workspace/projects/U_PGPUB_Extractor/data/pgpubBDSS'
    unzip_location = os.environ['LOCAL_TEMP_SAVE_FOLDER'] #os.path.join(os.environ['ROOT_PATH'], os.environ['LOCAL_TEMP_SAVE_FOLDER'])
    full_hdfs_fname = str(os.path.join(os.environ['HDFS_SAVE_FOLDER'], os.environ['HDFS_SAVE_FN'])) #'/data/target/pgpub/7.4-whs-PGPUB_Text_2015+_TEST.json'
    
    export_hive_table_name = os.environ['HIVE_TABLE']

    ES_nodes = os.environ['ES_nodes']
    pgpub_ES_index = os.environ['pgpub_ES_index']
    pgpub_ES_type = os.environ['pgpub_ES_type']
    ES_user = os.environ['ES_user']
    ES_pass = os.environ['ES_pass']
    ES_port = os.environ['ES_port']

    job_nm = os.environ['JOB_NAME']
    create_user_id = os.environ['CREATE_USER_ID']
    last_mod_user_id = os.environ['LAST_MOD_USER_ID']
    job_control_table = os.environ['JOB_CONTROL_TABLE']
    job_group = os.environ['JOB_GROUP']
    job_log_table = os.environ['JOB_LOG_TABLE']

    return start_date, save_location, unzip_location, full_hdfs_fname, \
            export_hive_table_name, \
            ES_nodes, pgpub_ES_index, pgpub_ES_type, ES_user, ES_pass, ES_port, \
            job_nm, create_user_id, last_mod_user_id, job_control_table, job_group, job_log_table

def getUrls(start_date):
    start_year = int(str(start_date)[0:4])
    stop_year = int(datetime.datetime.now().year)+1
    years = [str(X)+'/' for X in range(start_year, stop_year)]
    urls = []
    for year in years:
        url = 'https://bulkdata.uspto.gov/data/patent/application/redbook/fulltext/'+year
        data = requests.get(url, allow_redirects=True)
        data.content
        soup = BeautifulSoup(data.content, 'lxml')

        for link in soup.find_all('a', href=True):
            if (link['href'].startswith('ipa')) | (link['href'].startswith('pa')):
                if int(link['href'][-10:-4]) > int(str(start_date)[-6:]):
                    urls.append(url+link['href'])
    return urls

def export_to_hive(df, hive, HIVE_table):
    print('Exporting to Hive')
    hive.sql("DROP TABLE IF EXISTS " + HIVE_table)
    df.createOrReplaceTempView("pgpub_U_temp")
    hive.sql("CREATE TABLE IF NOT EXISTS " + HIVE_table + " STORED AS ORC  AS SELECT * from pgpub_U_temp")
    #hive.sql("INSERT INTO bdr.application_txn_score  SELECT * from application_txn_score_temp")
    print('Exported {} Records to Hive'.format(df.count()))

def export_to_elastic(df, spark, ES_nodes, ES_index, ES_type, ES_user, ES_pass, ES_port):
    #df_mdr = spark.read.table('bdr.appmdr')
    #df_trx = spark.read.table('bdr.application_txn_score')
    #df_joined = df_trx.join(df_mdr, on='patentApplicationNumber')
    #df_joined = df.join(df_mdr, on='patentApplicationNumber')
    #cols = ['patentApplicationNumber','groupArtUnitNumber', 'workGroup', 'techCenter', 'examinerEmployeeNumber', 
    #        'filingDate', 'grantDate', 'nationalClass', 'nationalSubclass', 'bucketType', 'score', 'messages','trxHistory','id'] 
    #df_final = df_joined.select(cols)

    #df_final = df_final.withColumnRenamed('workGroup', 'workGroupNumber').withColumnRenamed('techCenter', 'techCenterNumber')
    #df_final = df_final.withColumn('filingDate', from_unixtime(timestamp=unix_timestamp(timestamp='filingDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))
    #df_final = df_final.withColumn('grantDate', from_unixtime(timestamp=unix_timestamp(timestamp='grantDate', format='yyyy-MM-dd'), format='yyyy-MM-dd'))

    rdd_mapped = df.rdd.map(lambda y: y.asDict())

    def package(doc):
        _json = json.dumps(doc)
        keys = doc.keys()
        for key in keys:
            if doc[key] == 'null' or doc[key] == 'None':
                del doc[key]
        if not doc.has_key('id'):
            id = hashlib.sha224(_json).hexdigest()
            doc['id'] = id
        else:
            id = doc['id']
        _json = json.dumps(doc)
        return (id, _json)
     
    exportRDD = rdd_mapped.map(package)

    print('Exporting to Elastic Search')
    
    try:
        exportRDD.saveAsNewAPIHadoopFile(
            path='-', 
            outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
            keyClass="org.apache.hadoop.io.NullWritable",  
            valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
            conf={ "es.resource" : ES_index + "/" + ES_index, "es.mapping.id":"id","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
                "es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
                "es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port": ES_port, "es.net.ssl":"true"})
        print('Exported {} Records to Elastic Search'.format(df.count()))
    except Exception as ex:
        print(traceback.format_exc())

def update_jobLog_table(hive, job_nm, job_group, no_of_recs_processed, job_log_table, status):
    
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    '''
    Modify Job Log table: 
    root
     |-- jobgroup: string (nullable = true)
     |-- jobname: string (nullable = true)
     |-- starttime: timestamp (nullable = true)
     |-- endtime: timestamp (nullable = true)
     |-- status: string (nullable = true)
     |-- comments: string (nullable = true)
     |-- no_of_recs_processed: integer (nullable = true)
     '''
    insert_values = (job_group, job_nm, 
                start_time, end_time,
                status, 'No. of New PGPUB documents pushed to elastic', 
                no_of_recs_processed)
    print('Values to Insert into bdr.job_log Table: ', insert_values)
    hive.sql("INSERT INTO TABLE " + str(job_log_table) + " VALUES " + str(insert_values))

def update_jobControl_table(hive, job_nm, create_user_id, last_mod_user_id, job_control_table):
    '''
    Modify Job Control Table
    root
     |-- job_nm: string (nullable = true)
     |-- loaded_dt: timestamp (nullable = true)
     |-- create_ts: timestamp (nullable = true)
     |-- create_user_id: string (nullable = true)
     |-- last_mod_ts: timestamp (nullable = true)
     |-- last_mod_user_id: string (nullable = true)
    '''
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    insert_values = (job_nm, start_time,
                end_time, create_user_id,
                end_time, last_mod_user_id)
    print('Values to Insert into bdr.job_control Table: ', insert_values)
    hive.sql("INSERT INTO TABLE " + str(job_control_table) + " VALUES " + str(insert_values))

def backup_hdfs(df_unioned, full_hdfs_fname):#hdfs_folder):
    #Move Current HDFS Folder to _bak
    hdfs_folder=os.path.dirname(full_hdfs_fname)
    os.system('hdfs dfs -mkdir -p ' + hdfs_folder + '_bak')
    fn_write = os.path.join(os.path.dirname(full_hdfs_fname)+'_bak/', full_hdfs_fname.split('/')[-1])
    print('fn_write: ', fn_write)
    try:
        df_unioned.write.json(fn_write)#hdfs_folder + '_bak')
    except:
        df_unioned.write.json(fn_write)#hdfs_folder + '_bak', mode='append')
    #df_bak = spark.read.json(hdfs_folder+_'bak/*.json')
    #df_bak_full = df.join(df_bak, on='appId', how='outer')dropDuplicates()
    #df_bak_full.spark.write(hdfs_folder+'_bak')
    #os.system('hdfs dfs -cp -f ' + hdfs_folder + '/* ' + hdfs_folder + '_bak')
    os.system('hdfs dfs -rm -r -f ' + hdfs_folder)
    #os.system('hdfs dfs -mv ' + hdfs_folder+'_bak '+ hdfs_folder)
    print('Backed-Up ', hdfs_folder, ' to ', hdfs_folder+'_bak')