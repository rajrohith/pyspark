# PGPGUB Extraction Pipeline!

## Overview

This pipeline goes through the following steps for the date range(s) specified. 

1. `bdr-pgpub.sh` exports enviornmental varibales and manages the process
2. `1.0-PGPUB_Text_Extraction.py` is run with any start_date argument either (a) passed through or (b) pulled from HIVE job_log table.
3. The appropriate links are download from bulk data and processed:
	- Downloads from USPTO Bulkdata, e.g. https://bulkdata.uspto.gov/data/patent/application/redbook/fulltext/2018/
	- Unzips and Extracts all XMLs
	- Converts the one huge xml to individiaul xmls for each application
	- Extracts the: pgpub, appId, title,  abstract text, spec text, and claim text
	- Pushes the new data to HDFS
4. Full previous pgpgub dataset is appended (if already exists)
5. Previous Hive Table Dropped (if exists) and new one create updated in HIVE
6. New Index in Elastic Search updated
7. bdr.job_control and bdr.job_log tables in HIVE are updated (with number of entries or error if failure)

NOTE that all logs are saved in a log folder location variable specified in the `bdr-pgpub.sh` 

## To Run:
1. Download the Full Code From the Source Control Repository
2. Confirm the correct permissions for this folder (sudo chmod 777 -R /root)
3. Enter and confirm the hard coded variables in `bdr-pgpub.sh` All external variables are set here, there is no .configuration file
5. Run script with `sh bdr-pgpub.sh *ARG*` If you wish to extract from a certain date range, you can specify it as an argument (YYYYMMDD). Otherwise, the extraction date range will start with the most recent timestamp in the bdr.job_control table in HIVE.

Example 1: "sh bdr-pgpub.sh 20180101" scrapes all PTAB pdfs from 01-01-2018 to Today
Example 2: "sh bdr-pgpub.sh" scrapes all PTAB pdfs from the most recent date in `bdr.job_control` Hive table to Today

**NOTE To do a full data import, use start date: 20000101 or earlier**

## Requirements To Install:

### Server

### Python Packages
requests
xmltodict
bs4
tqdm
