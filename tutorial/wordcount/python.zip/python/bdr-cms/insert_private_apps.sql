Insert into bdr.application SELECT p.appl_id as appid ,'private' as apptype,NULL as md_json, 'open' as md_status,CURRENT_DATE as md_c_dt,CURRENT_DATE as md_u_dt FROM bdr.palm p 
LEFT JOIN bdr.application a
 ON p.appl_id = a.appid Where  NVL(a.appid,'x')='x' and p.appl_id is not null ;