 
from pyspark.sql import SparkSession
import sys
job_group = sys.argv[1]
job_name = sys.argv[2]
status = sys.argv[3]
date = sys.argv[4]
date_new = date.replace("$"," ")

spark = SparkSession.builder.appName("Job Log").enableHiveSupport().getOrCreate()
print(job_name + " " + status + " " + date_new )
if status=='completed' and job_name=='cms-insertprivateapps':
 privatedf=spark.sql("select 1 AS Numberofprivateappids from bdr.application_backup where apptype='private'")
 sqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of private appids',"+str(privatedf.count()) 
 spark.sql(sqlstring)

elif status=='completed' and job_name=='cms-persistapplicationdata':
 pub_completedf=spark.sql("select 1 from bdr.application_delta where apptype='public' and md_status='completed'")
 pubsqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of public appids completed',"+str(pub_completedf.count()) 
 spark.sql(pubsqlstring)

 pvt_completedf=spark.sql("select 1 from bdr.application_delta where apptype='private' and md_status='completed'")
 pvtsqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of private appids completed',"+str(pvt_completedf.count())
 spark.sql(pvtsqlstring)

 pub_errdf=spark.sql("select 1 from bdr.application_delta where apptype='public' and md_status='error'")
 pubesqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of public appids errored',"+str(pub_errdf.count()) 
 spark.sql(pubesqlstring)

 pvt_errdf=spark.sql("select 1 from bdr.application_delta where apptype='private' and md_status='error'")
 pvtesqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of private appids errored',"+str(pvt_errdf.count())
 spark.sql(pvtesqlstring)

elif status=='completed' and job_name=='cms-persistoadata':
 act_completeddf=spark.sql("select 1 from bdr.applicationactions_delta where oa_status='completed'")
 actcsqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of application_actions completed',"+str(act_completeddf.count()) 
 spark.sql(actcsqlstring)

 act_errdf=spark.sql("select 1 from bdr.applicationactions_delta where oa_status='error'")
 actesqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"','No.of application_actions errored',"+str(act_errdf.count()) 
 spark.sql(actesqlstring)

else:
 sqlstring= "insert into bdr.job_log select  '"+job_group+"','"+job_name+"',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'"+status+"',NULL,0 " 
 spark.sql(sqlstring)


spark.stop()