use bdr;
DROP TABLE IF EXISTS process_docs;
CREATE TABLE process_docs STORED AS ORC tblproperties("COMPRESS=SNAPPY") AS
SELECT docid, appid
FROM (SELECT  translate(docid,'[|]|"','') as docid,a.appid 
FROM (SELECT CONCAT('{"root":[', md_json,']}') as json,appid FROM bdr.application where md_status ='completed') as a LATERAL VIEW explode(split(get_json_object(json,'$.root.documentIdentifier') ,','))  json AS docid) tab  WHERE NOT EXISTS (SELECT 1 FROM bdr.applicationactions b WHERE tab.appid = b.appid AND tab.docid = b.docid and b.oa_status ='completed');

select count(*) as totaldocsprocessed from bdr.process_docs;
