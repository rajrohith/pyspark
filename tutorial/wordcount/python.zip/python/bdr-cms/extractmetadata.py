#########################################################################################################################################
#  Written By: Srinivasa Rao
#  Process: BDR Data Ingestion Pipeline
#  Step: extract oa metadata
#  Description: This step makes Rest API calls to oa metadata and pulls oa xml files for each applicationa action
#  approximate time it takes few minutes for delta depending on number applications chosen.
#########################################################################################################################################
from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
import json
import requests
import tarfile
from io import BytesIO
from datetime import datetime
from collections import OrderedDict


import sys,os
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-cms.properties')


conf = SparkConf().setAppName('process applicationactions delta')
conf = conf.setMaster("yarn-client")
sc = SparkContext(conf=conf)

hive =  HiveContext(sc)

hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")

hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","20")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql("SET spark.sql.rcfile.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')
hive.sql("SET hive.exec.dynamic.partition=true")
hive.sql("SET hive.exec.dynamic.partition.mode=nonstrict")


def getMetadata(appid): 
    try:  
        cms_host = config.get('bdr','CMS_HOST')
        url = "/".join((cms_host, "pto", "PATENT","documentMetadata", appid))
        headers = {'Accept': '*/*', 'Content-Type': 'application/json'}
        response = requests.get(url, headers=headers, json=['jsonl'])
        if response.status_code <> 200:
            return response.status_code
        else:
            data = response.content
            if data[0:1] == '[':
                data = data[1:-1]
            return data
    except:
        return "999"

def getoadata(appid,docid):
    try:  
        if docid is None:
            return "404"
        else:
            oa_host = config.get('bdr','OA_HOST')
            url = "/".join((oa_host, "pto", "PATENT","getDocuments", appid,docid))
            headers = {'Accept': '*/*', 'Content-Type': 'application/json'}
            response = requests.get(url, stream=True)
            if response.status_code <> 200:
               return response.status_code
            else:
               file=BytesIO(response.content)
               tar = tarfile.open(mode="r:tar",fileobj=file)
               for member in tar.getmembers():
                   if 'xml' in member.name :
                        data = tar.extractfile(member).read()
                        return data
    except:
        return "999"
        
def getStatus(metadata):
    if metadata is None:
        status = 'error'
        return status
    if len(str(metadata)) > 5:
        status = 'completed'
    else:
        status = 'error'
    return status
    
def xmltojson(xml):
    try:
        if len(str(xml)) > 5 and xml != None:
            d= xmltodict.parse(xml,xml_attribs=True)
            return json.dumps(d)
        else:
            return "404"
    except:
        return "888"

def getformattedxml(xml,docid,oastatus,appid):
    if oastatus == 'completed' and oastatus is not None:
        ordered_json = OrderedDict()# {'documentIdentifier':ifw_no, 'xml': data}
        ordered_json['docid'] = docid
        ordered_json['appid'] = appid
        ordered_json['xml'] =  xml.replace('\n','')
        xml_text = json.dumps(ordered_json)+'\n'
        return xml_text

def getformattedjson(jsontext,docid,oastatus,appid):
    if oastatus == 'completed' and oastatus is not None :
        pure_json_ordered = OrderedDict()# {'documentIdentifier':ifw_no, data}
        pure_json_ordered['docid'] = docid
        pure_json_ordered['appid'] = appid
        pure_json_ordered['data'] =  jsontext.replace('\n','')
        json_text = json.dumps(pure_json_ordered)+'\n'
        return json_text

        
def getdocidappids(appid,docid):
    if docid is not None:
        return docid + ',' + str(appid)
    
savemetadata = udf(getMetadata)
status = udf(getStatus)
saveoadata = udf(getoadata)
saveoajson = udf(xmltojson)

oaxml = udf(getformattedxml)
oajson = udf(getformattedjson)
getids = udf(getdocidappids)


def getData(appids):
    apps = appids.repartition(20)
    apps = apps.withColumn("oa_xml",saveoadata(apps[0],apps[1]))
    apps = apps.withColumn("oa_status",status(apps[2]))
    apps = apps.withColumn("oa_json",saveoajson(apps[2]))
    apps = apps.withColumn("formattedxml",oaxml(apps[2],apps[1],apps[3],apps[0]))
    apps = apps.withColumn("formattedjson",oajson(apps[4],apps[1],apps[3],apps[0]))
 
  
    apps.createOrReplaceTempView("appsfinal")

    hive.sql("insert into table  bdr.applicationactions_delta  select appid,docid, oa_xml,oa_json, oa_status,formattedxml,formattedjson from appsfinal")
  

    
print str(datetime.now())
hive.sql("truncate table bdr.applicationactions_delta")
temp_docsdf=hive.sql("Select * from bdr.process_docs")
recscount=temp_docsdf.count()
datasettoprocess=0
while (datasettoprocess <= ((recscount/5000)) ):
   appids = hive.sql("select appid,docid from bdr.process_docs a where not exists (select 1 from bdr.applicationactions_delta b where a.appid = b.appid and a.docid = b.docid) limit 5000 ")
   getData(appids)
   datasettoprocess = datasettoprocess + 1
   #print i
print str(datetime.now())