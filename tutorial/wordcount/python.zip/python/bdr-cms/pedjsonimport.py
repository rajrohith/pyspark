#########################################################################################################################################
#  Written By: Srinivasa Rao
#  Process: BDR Data Ingestion Pipeline
#  Step: Ped json import
#  Description: This step imports ped json file which has all list of Patent applications.
#               It also unzips the ped file and places contents onto hdfs folder.
#               It also deletes older files from directories.
# approximate time it takes around 10 minutes.
#########################################################################################################################################
from datetime import datetime
import tarfile
from io import BytesIO
import requests
import zipfile
from StringIO import StringIO
from subprocess import call
import subprocess

import sys,os

import ConfigParser
config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-cms.properties')


pedpath = config.get('bdr','PEDPATH')
cmspedpath = config.get('bdr','CMSPEDAPTH') 


subprocess.call("rm -rf "+pedpath+"2*",shell=True,stdout=subprocess.PIPE)
global date
date =  datetime.now().strftime('%Y%m%d')
print str(datetime.now())
url = config.get('bdr','PEDJSONURL' )
response = requests.get(url,stream=True)
print str(datetime.now())
file=BytesIO(response.content)
filename = "/data/bdr/source/ped/"  + str(date) + ".zip"
targetfile = "/data/bdr/source/ped/"  + str(date)
print str(datetime.now())
zipfile.ZipFile(file).extractall(targetfile)
print str(datetime.now())
cmd = "hdfs dfs -copyFromLocal -f "+pedpath + str(date) + " "+ cmspedpath + str(date)
print cmd
subprocess.call("hdfs dfs -rm -r "+cmspedpath+"2*",shell=True, stdout=subprocess.PIPE)
subprocess.call(cmd, shell=True, stdout=subprocess.PIPE)

