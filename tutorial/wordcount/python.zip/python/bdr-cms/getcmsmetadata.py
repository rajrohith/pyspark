#########################################################################################################################################
#  Written By: Srinivasa Rao
#  Process: BDR Data Ingestion Pipeline
#  Step: Get cms Metadata
#  Description: This step makes Rest API calls to CMS metadata and pulls all meta data information
#               for each application chosen.
# approximate time it takes depends on the number for application chosen to process. Delete should not take more than couple of mts.
#########################################################################################################################################
from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
import json
import requests
from io import BytesIO
from datetime import datetime
import sys,os
import traceback
import ConfigParser
config_path=sys.argv[1]
date = sys.argv[2]
date_new = date.replace("$"," ")
config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-cms.properties')

conf = SparkConf().setAppName('Application metadata')
conf = conf.setMaster("yarn-client")
sc = SparkContext(conf=conf)

hive =  HiveContext(sc)

hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")
hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","20")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')



def getMetadata(appid): 
    try:  
        cms_host = config.get('bdr','CMS_HOST') 
        url = "/".join((cms_host, "pto", "PATENT","documentMetadata", appid))
        headers = {'Accept': '*/*', 'Content-Type': 'application/json'}
        response = requests.get(url, headers=headers, json=['jsonl'])
        if response.status_code <> 200:
            return response.status_code
        else:
            data = response.content
            if data[0:1] == '[':
                data = data[1:-1]
            return data
    except Exception as ex:
        print traceback.format_exc()
        return "999"


        
def getStatus(metadata):
    if metadata is None:
        status = 'error'
        return status
    if len(str(metadata))> 4:
        status = 'completed'
    else:
        status = 'error'
    return status

    
savemetadata = udf(getMetadata)
status = udf(getStatus)




def getData(appids):
    appids = appids.repartition(10)
    appids = appids.withColumn("metadata",savemetadata(appids[0]))
    appids = appids.withColumn("mdstatus",status(appids[2]))


    appids.createOrReplaceTempView("apps")
   
    appids.count()
  
    hive.sql("insert into table bdr.application_delta select appid, apptype,metadata as md_json,mdstatus as md_status,current_date as md_c_dt,current_date as md_u_dt FROM apps")
    
print str(datetime.now())

hive.sql("truncate table bdr.application_delta")

appids = hive.sql("select distinct appid,apptype from bdr.application_backup where md_status='open' ")

appids.createOrReplaceTempView("appids_tobe_processed")
recscount=appids.count()
print "Number of applications going to be processed : " + str(recscount)  

datasettoprocess=0
while (datasettoprocess <= ((recscount/10000)) ):
   appids_temp = hive.sql("select appid, apptype from appids_tobe_processed a where not exists(select 1 from bdr.application_delta b where a.appid=b.appid) limit 10000 ")
   getData(appids_temp)
   datasettoprocess = datasettoprocess + 1

numberofapps = hive.sql("select * from bdr.application_delta where md_status = 'completed'")
print "Number of applications processed successfully: " + str(numberofapps.count())   
hive.sql("insert into bdr.job_log select  'bdr-cms','cms-getcmsmetadata',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed','Number of applications processed',"+str(numberofapps.count()))

print str(datetime.now())
