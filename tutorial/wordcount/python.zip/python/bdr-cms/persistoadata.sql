use bdr;


delete from bdr.applicationactions where exists( select 1 from bdr.applicationactions_delta where applicationactions.appid=applicationactions_delta.appid and applicationactions.docid=applicationactions_delta.docid) ;
Insert into bdr.applicationactions(appid,docid,oa_xml,oa_json,oa_status,oa_c_dt,oa_u_dt) Select appid,docid,oa_xml,oa_json,oa_status,current_date,current_date from bdr.applicationactions_delta;


insert into bdr.cms_oaxml select formattedxml from bdr.applicationactions_delta where oa_status = 'completed';
insert into bdr.cms_oajson select formattedjson from bdr.applicationactions_delta where oa_status = 'completed';

