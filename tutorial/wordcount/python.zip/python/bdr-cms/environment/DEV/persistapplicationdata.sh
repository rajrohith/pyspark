#!/bin/bash
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-cms'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-cms'
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')
export HADOOP_USER_NAME=hdfs
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1

chmod 777 $LOGPATH/$JOB.$RUNDATE.log
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-persistapplicationdata' 'started' $startdatetime


hive -f $CODEPATH/persistapplicationdata.sql 
if [ $? -ne 0 ]; then
  /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-persistapplicationdata' 'error' $startdatetime
  echo "persistapplicationdata script failed"
  exit 1
fi
  /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-persistapplicationdata' 'completed' $startdatetime
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
