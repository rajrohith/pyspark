#!/bin/bash

JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-cms'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-cms'
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')
export HADOOP_USER_NAME=hdfs
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
chmod 777 $LOGPATH/$JOB.$RUNDATE.log
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-insertprivateapps' 'started' $startdatetime

hive -e " DROP TABLE IF EXISTS bdr.application_backup "
hive -e " create table bdr.application_backup as select * from bdr.application "

hive -e " truncate table bdr.application "

hive -e " insert into bdr.application select * from bdr.application_backup "

hive -f $CODEPATH/getdeltalistofapps.sql

file=$CODEPATH"/bdr-cms.properties"

if [ -f "$file" ]
then
  echo "$file found."

  while IFS='=' read -r key value
  do
    eval "${key}=${value}"
  done < "$file"

  echo "ENVIRONMENT= " ${ENVIRONMENT}
else
  echo "$file not found."
fi

if [ $ENVIRONMENT == "prod" ]; then
   hive -f $CODEPATH/insert_private_apps.sql 
fi


if [ $? -ne 0 ]; then
  /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-insertprivateapps' 'error' $startdatetime
  echo "getdeltalistofapps script failed"
  exit 1
fi
 /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-cms' 'cms-insertprivateapps' 'completed' $startdatetime

hive -e " DROP TABLE IF EXISTS bdr.application_backup "
hive -e " create table bdr.application_backup as select * from bdr.application "

echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
