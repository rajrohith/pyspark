#!/bin/bash
JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-cms'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-cms'

echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')

exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
chmod 777 $LOGPATH/$JOB.$RUNDATE.log

hive -f $CODEPATH/getdeltalistofapps404.sql 
if [ $? -ne 0 ]; then
  echo "persistapplicationdata script failed"
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')

