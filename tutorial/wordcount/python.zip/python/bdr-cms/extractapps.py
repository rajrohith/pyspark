#########################################################################################################################################
#  Written By: Srinivasa Rao
#  Process: BDR Data Ingestion Pipeline
#  Step: Extract applications from Ped json import
#  Description: This step parses all application numbers from  ped json file imported.
#               Currently it takes all applications for Utilites starting applications numbers with 12, 13, ...19
# approximate time it takes around 2 minutes.
#########################################################################################################################################
from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext
import re
from pyspark.sql.functions import udf
from datetime import datetime


import sys,os
import ConfigParser
config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-cms.properties')
date = sys.argv[2]
date_new = date.replace("$"," ")



#include below if you are running from spark-submit
conf = SparkConf().setAppName('ped files extract')
conf = conf.setMaster("yarn")
sc = SparkContext(conf=conf)

cmspedpath = config.get('bdr','CMSPEDAPTH')

date =  datetime.now().strftime('%Y%m%d')
hive =  HiveContext(sc)
hive.setConf("spark.sql.tungsten.enabled","true")
hive.setConf("spark.io.compression.codec","SNAPPY")
hive.setConf("spark.rdd.compress","true")

hive.setConf("mapred.output.dir.recursive","true")
hive.setConf("spark.sql.rcfile.filterPushdown","true")
hive.setConf("spark.sql.orc.filterPushdown","true")
hive.setConf("spark.sql.shuffle.partitions","1000")
hive.sql("SET spark.sql.orc.compression.codec=SNAPPY")
hive.sql("SET spark.sql.rcfile.compression.codec=SNAPPY")
hive.sql('SET spark.sql.hive.convertMetastoreParquet=false')
hive.sql("SET hive.exec.dynamic.partition=true")
hive.sql("SET hive.exec.dynamic.partition.mode=nonstrict")


def getappids(input):
    return re.findall(r'"electronicText":"(.*?)"}',input)

print str(datetime.now())
appids = udf(getappids)    
pedfiles = cmspedpath + str(date)

ped = hive.read.text(pedfiles)
ped.repartition(100)
ped = ped.withColumn("appids",appids(ped[0]))
ped.createOrReplaceTempView("pedappids")
pedappids = hive.sql("select translate(appids,'[|]','') as appid from (select explode(split(appids,',')) as appids from pedappids )  ")
pedappids.createOrReplaceTempView("pedappids")
pedappids = hive.sql("insert overwrite table bdr.ped_appids select distinct trim(appid) from pedappids where length(trim(appid))> 4 and substr(trim(appid),1,2) in ('12','13','14','15','16','17','18','19','20','29') ")
numberofapps = hive.sql("select * from bdr.ped_appids")
print "Number of applications retrieved from ped files: " + str(numberofapps.count()) 
print str(datetime.now())

hive.sql("insert into bdr.job_log select  'bdr-cms','cms-extractapps',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed','ped appids count',"+str(numberofapps.count()))




