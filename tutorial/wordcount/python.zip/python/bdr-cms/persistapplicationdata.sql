use bdr;
delete from bdr.application where exists( select 1 from bdr.application_delta where application.appid=application_delta.appid) ;
Insert into bdr.application(appid,apptype,md_json,md_status,md_c_dt,md_u_dt) Select appid,apptype,md_json,md_status,md_c_dt,md_u_dt from bdr.application_delta ;

insert overwrite table cms_metadata
Select  case when instr(jsoncol,',')=1 then regexp_replace (jsoncol,'^(.*?),', '$1') else  jsoncol end  jsoncol_new from (
SELECT CONCAT( md_json,']}') as jsoncol from  application LATERAL VIEW explode( split(md_json,']}') ) application as  md_json    ) tab where jsoncol !=']}' ;
