import sys,os
import json
import base64
import datetime
from operator import add
from pyspark.sql.functions import col
from pyspark.sql import SparkSession
from pyspark.sql import HiveContext

from pyspark.sql import Row

import os,itertools
import smtplib, traceback, hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import pandas as pd
import numpy as np
import ConfigParser
config_path=sys.argv[1]
config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-job_log.properties')
emailid = config.get('bdr','EMAIL')
env = config.get('bdr','ENVIRONMENT')
starttime=datetime.datetime.now() - datetime.timedelta(1)
starttime=str(starttime.replace(hour=8, minute=0, second=0,microsecond=0))
#'2017-12-28 20:00:00'
endtime=datetime.datetime.now()
endtime=str(endtime.replace(hour=8, minute=0, second=0,microsecond=0))
#'2017-12-29 08:00:00'
spark = SparkSession.builder.appName("Job Log Report").enableHiveSupport().getOrCreate()

format = '%Y-%m-%d %H:%M:%S'
report_start_date = datetime.datetime.strptime(starttime, format).strftime('%Y-%m-%d %I:%M %p')
report_end_date =  datetime.datetime.strptime(endtime, format).strftime('%Y-%m-%d %I:%M %p')
print("report start date" + report_start_date)
print("report end date" + report_end_date)


HEADER = '''
<html>
    <head>

    </head>
    <body>
'''
FOOTER = '''
    </body>
</html>
'''

templ_str = '<html><head/><body><h2>Job Log Report between '+report_start_date+' and '+report_end_date+'</h2><hr> \
<p><b></b> <h2>INDEXED</h2> \
<hr><p><b></b> <h2>APPSCORE</h2> \
<hr> \
</body></html>'

class Notify(object):

    def render_template(self, rv, data):
        for key in data:
            rv = rv.replace(key,data[key])
        return rv

    def get_messages(self, templ, data):
        rich = self.render_template(templ, data)

        return {'html': rich}

    def compose_email(self, template, subj, to, data):
        content = self.get_messages(template, data)

        from_addr = 'noreply@uspto.gov'

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subj
        msg['From'] = from_addr
        msg['To'] = to

        part2 = MIMEText(content['html'], 'html')

        msg.attach(part2)

        return msg

    def send_mail(self, msg):
        #s = smtplib.SMTP("smtpedge1.uspto.gov")
        s = smtplib.SMTP("mailer.uspto.gov")
        s.sendmail(msg['From'], msg['To'].split(','), msg.as_string())
        s.quit()

    def notify(self, template, subj, to, data):

        msg = self.compose_email(template, subj, to, data)
        self.send_mail(msg)


privatedf=spark.sql("select * from bdr.job_log where status in ('completed','error') and jobname not in ('Application clear score','OA clear score') and endtime > '"+starttime+"'  and endtime < '"+endtime+"' order by starttime Asc ")  
#privatedf=spark.sql("select a.* from bdr.job_log a  where a.endtime > '"+starttime+"'  and a.endtime < '"+endtime+"' and not exists (Select 1 from bdr.job_log b where  a.jobgroup=b.jobgroup and a.jobname=b.jobname and a.status='started' and b.status in ('started','completed','error') ) and a.status='started' and a.jobname <>'Application clear score'")
privatedf.persist()
privatedf.count()

Appdf=spark.sql("select * from bdr.job_log where status in ('completed','error') and jobname in ('Application clear score','OA clear score') and endtime > '"+starttime+"'  and endtime < '"+endtime+"' order by starttime Asc ")  
Appdf.persist()
Appdf.count()

parms = {}
parms['INDEXED']=privatedf.toPandas().to_html()
parms['APPSCORE']=Appdf.toPandas().to_html()
notify = Notify()
msg = notify.compose_email( templ_str, 'JOB Log Report - '+env, emailid, parms )
notify.send_mail(msg)
#privatedf.repartition(1).write.option("header", "true").csv("/data/Job_log_report.csv")
#msg = notify.compose_email( templ_str, '(DEV)JOB LOG Report', 'ravi.koppula@uspto.gov', parms )


#parms = {}
#parms['Report'] = str(privatedf.show(privatedf.count(),False))
#notify = Notify()
#msg = notify.compose_email( templ_str, '(DEV)JOB LOG Report', 'ravi.koppula@uspto.gov', parms)
#with open('test.html', 'w') as f:
#    f.write(HEADER)
#    f.write(privatedf.to_html(classes='df'))
#    attachment = MIMEText(f.read(),'html')
#    msg.attach(attachment)
#    notify.send_mail(msg)


spark.stop()