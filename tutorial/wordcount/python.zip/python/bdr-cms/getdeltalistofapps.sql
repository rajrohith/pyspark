Insert into bdr.application SELECT p.appid as appid ,'public' as apptype,NULL as md_json, 'open' as md_status,CURRENT_DATE as md_c_dt,CURRENT_DATE as md_u_dt FROM bdr.ped_appids p 
LEFT JOIN bdr.application a
 ON p.appid = a.appid Where  NVL(a.appid,'x')='x' and p.appid is not null ;

update bdr.application set md_status='open';

update  bdr.application set apptype = 'public',md_u_dt =current_date where exists ( select 1 from bdr.ped_appids where application.appid = ped_appids.appid ) and application.apptype <> 'public' ;
