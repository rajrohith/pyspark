drop table if exists bdr.appids_tobe_processed;
create table bdr.appids_tobe_processed AS 
    select distinct a.appid from bdr.ped_appids a where not exists (select 1 from bdr.application b where  a.appid = b.appid ) 
    UNION
    select appid from bdr.application where md_json = '999'
    UNION 
    select appid from bdr.application where md_json = '404';
select count(*) AS Numberofapplicationschosetoprocess from bdr.appids_tobe_processed;
