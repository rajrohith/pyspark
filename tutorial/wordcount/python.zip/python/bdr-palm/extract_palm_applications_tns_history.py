from pyspark.sql import SparkSession
import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-palm.properties')

#red args
#read_hdfs = sys.argv[1]   # hdfs://bdr-itwv-kafka-2.dev.uspto.gov/data/source/ped/public_appl_ids.txt
write_hdfs = sys.argv[2]  # hdfs://bdr-itwv-kafka-2.dev.uspto.gov/data/source/palm/PALM_PUBLIC
date = sys.argv[3]
date_new = date.replace("$"," ")
# DB params in one place !
url = config.get('bdr','url')
userId = config.get('bdr','userId')
passwordVal = config.get('bdr','passwordVal')
TimeOut = config.get('bdr','TimeOut')
maxThreads = config.get('bdr','maxThreads')

spark = SparkSession \
    .builder \
    .appName("Python Spark JDBC Connection") \
    .enableHiveSupport()\
    .getOrCreate()

# Dynamically calculate the upper bound of the BDR_ID value to be input as maxvalue into downstream spark jdbc call
tmpDF = spark.read \
    .jdbc(url, "(select Count(BDR_ID) as cnt from BDRAPP_HIST_VIEW)", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})

cnt=tmpDF.select("cnt").collect()[0][0]


jdbcDF = spark.read \
    .jdbc(url, "BDRAPP_HIST_VIEW", "BDR_ID", 1, cnt, maxThreads, properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
jdbcDF.createOrReplaceTempView("PALM")    
    
jdbcDF.write.mode("overwrite").json(write_hdfs+"_Transaction_history")
spark.sql("insert into bdr.job_log select  'bdr-palm','extract_palm_applications_tns_history',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed','No.of applications',"+str(cnt))


 
jdbcDF.select('BDR_ID').count()

spark.stop()

