use bdr;
truncate table bdr.application;
insert into bdr.application select * from bdr.application_private where apptype='private' ; 
insert into bdr.application select * from bdr.application_backup ; 
