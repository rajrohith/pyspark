# -*- coding: utf-8 -*-
"""
Created on Fri Aug  3 11:47:02 2018

@author: rshanmugam
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
from pyspark.sql.types import *
import json
import requests
from datetime import datetime
import sys,os
import traceback
import ConfigParser
import time

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-palm.properties')
btch_cnt=config.get('bdr','batch_count')


spark = SparkSession.builder.appName("get public indicator status and update appsmdr hive table")\
.enableHiveSupport().getOrCreate()

#spark.setConf("spark.sql.tungsten.enabled","true")
# spark.setConf("spark.io.compression.codec","SNAPPY")
# spark.setConf("spark.rdd.compress","true")
# spark.setConf("mapred.output.dir.recursive","true")
# spark.setConf("spark.sql.rcfile.filterPushdown","true")
# spark.setConf("spark.sql.orc.filterPushdown","true")
# spark.setConf("spark.sql.shuffle.partitions","20")
# spark.sql("SET spark.sql.orc.compression.codec=SNAPPY")
# spark.sql('SET spark.sql.hive.convertMetastoreParquet=false')

def getind(appid):
    try:
        #host ='https://opsg-api.sit.uspto.gov/OPSGPCDMServices/application-general-information'
        pub_host=config.get('bdr','PUBLIC_HOST')
        query = {"applicationNumber":appid}
        headers = {
            'Content-Type': "application/json"
                }
        response = requests.request("GET", pub_host, headers=headers, params=query)
        data =  response.json()
        pubstatus =str(data['isPublic'])
        return pubstatus
    except Exception as ex:
        print  traceback.format_exc()
        return "404"


savestatus = udf(getind)

def getdata(app_no):
    app_no = app_no.repartition(10)
    app_no = app_no.withColumn("publicstatus",savestatus(app_no['appid']))
    app_no.createOrReplaceTempView("public_status")
    #a = spark.sql('select * from public_status limit 5')
    #a.show(5)
    app_no.count()
    spark.sql("insert into table bdr.application_type select appid,case when publicstatus == 'True' then 'true' else 'false' end  as publicindicator,current_timestamp as create_ts,'etl' as create_user_id,current_timestamp as last_mod_ts ,'etl' as last_mod_user_id from public_status where publicstatus <> '404' ")
    spark.sql("insert into table bdr.application_error select appid,case when publicstatus == 404 then 'application number error'end as app_status, current_timestamp as create_ts,'etl' as create_user_id from public_status where publicstatus == 404")
        
    
    
spark.sql("drop table if exists bdr.application_error")
spark.sql("create table bdr.application_error (appid string,app_status varchar(30),create_ts timestamp,create_user_id varchar(20))")
appids = spark.sql("select a.appid from bdr.application_backup a where not exists(select b.appid from bdr.application_type b where a.appid = b.appid )  ")
appids.createOrReplaceTempView("appno_tobe_processed")
recscount=appids.count()
print "Number of application no going to be processed : " + str(recscount)
datasettoprocess=0
while (datasettoprocess <= ((recscount/int(btch_cnt))) ):
    appids_temp=spark.sql("select * from appno_tobe_processed a where not exists(select b.appid from bdr.application_type b where a.appid = b.appid ) limit "+str(btch_cnt))
    getdata(appids_temp)
    datasettoprocess = datasettoprocess + 1
    print("processing data set  " + str(datasettoprocess))
            
spark.sql(" insert into bdr.job_control select * from (select 'bdr_getpublicind' as job_nm ,current_timestamp as load_ts , current_timestamp,'etl',current_timestamp,'etl'  ) tab ")
spark.sql("insert into bdr.job_log select  'bdr-palm','bdr_getpublicind',CURRENT_TIMESTAMP ,current_timestamp,'completed','public indicator status count',"+str(recscount)+"")
print "Number of public indicator status are  processed successfully: " + str(recscount)   
print str(datetime.now())