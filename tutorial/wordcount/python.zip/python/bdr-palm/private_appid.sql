DROP TABLE IF EXISTS bdr.application_private;
create table bdr.application_private as 
SELECT p.appl_id as appid ,case when a.appid is null then 'private' else a.apptype end as apptype,a.md_json,a.md_status,a.md_c_dt,a.md_u_dt 
FROM bdr.palm p 
LEFT JOIN (select * from bdr.application where substr(appid,1,2) between 11 and 17 ) a ON p.appl_id = a.appid ;

select count(*) AS Numberofprivateappids from bdr.application_private where apptype='private';