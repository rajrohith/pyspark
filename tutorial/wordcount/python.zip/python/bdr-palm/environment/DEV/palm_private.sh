JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-palm'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-palm'
export HADOOP_USER_NAME=hdfs
startdatetime=$(date +'%Y-%m-%d$%H:%M:%S.%3N')
echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')

exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
chmod 777 $LOGPATH/$JOB.$RUNDATE.log
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-palm' 'palm-private' 'started' $startdatetime
hive -f $CODEPATH/private_appid.sql 
if [ $? -ne 0 ]; then
  /usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-palm' 'palm-private' 'error' $startdatetime 
  echo "palm private script failed"
  exit 1
fi
/usr/hdp/current/spark2-client/bin/spark-submit --master=yarn --conf spark.executor.memory=20g --conf spark.driver.memory=10g  $CODEPATH/job_log.py 'bdr-palm' 'palm-private' 'completed' $startdatetime 
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
