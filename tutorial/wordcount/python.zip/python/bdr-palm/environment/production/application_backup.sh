#!/bin/bash

JOB=`basename $0`
CODEPATH='/data/bdr/scripts/bdr-palm'
RUNDATE=$(date +'%Y%m%d')
LOGPATH='/data/bdr/logs/bdr-palm'
export HADOOP_USER_NAME=hdfs
echo "Started $job:" $(date +'%Y-%m-%d:%H:%M')

exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1
chmod 777 $LOGPATH/$JOB.$RUNDATE.log

hive -f $CODEPATH/application_backup.hql 
if [ $? -ne 0 ]; then
  echo "hive application backup script failed"
  exit 1
fi
echo "Completed $job:" $(date +'%Y-%m-%d:%H:%M')
