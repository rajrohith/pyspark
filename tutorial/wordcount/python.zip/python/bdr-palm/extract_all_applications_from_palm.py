from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql import HiveContext

import sys
import ConfigParser

config_path=sys.argv[1]

config = ConfigParser.RawConfigParser()
config.read(config_path+'/bdr-palm.properties')

#red args
#read_hdfs = sys.argv[1]   # hdfs://bdr-itwv-kafka-2.dev.uspto.gov/data/source/ped/public_appl_ids.txt
write_hdfs = sys.argv[2]  # hdfs://bdr-itwv-kafka-2.dev.uspto.gov/data/source/palm/PALM_PUBLIC
date = sys.argv[3]
date_new = date.replace("$"," ")
# DB params in one place !


# DB params in one place !
url = config.get('bdr','url')
userId = config.get('bdr','userId')
passwordVal = config.get('bdr','passwordVal')
TimeOut = config.get('bdr','TimeOut')
maxThreads = config.get('bdr','maxThreads')

spark = SparkSession \
    .builder \
    .appName("PALM App") \
    .enableHiveSupport()\
    .getOrCreate()

# Dynamically calculate the upper bound of the BDR_ID value to be input as maxvalue into downstream spark jdbc call
tmpDF = spark.read \
    .jdbc(url, "(select count(BDR_ID) as maxId from BDRAPP_VIEW )", properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})

maxId=tmpDF.select("maxId").collect()[0][0]

'''
print maxId
'''

jdbcDF = spark.read \
    .jdbc(url, "BDRAPP_VIEW", "BDR_ID", 1, maxId, maxThreads , properties={"user": userId, "password": passwordVal, "connection_timeout": TimeOut})
jdbcDF.createOrReplaceTempView("PALM")    

spark.sql("DROP TABLE IF EXISTS bdr.palm ") 
spark.sql("create table bdr.palm as select * from PALM")      
hiveCtx = HiveContext(spark)
 
appIds = hiveCtx.sql("Select * from bdr.application_backup where substr(appid,1,2) between 11 and 30 ")
appIds.createOrReplaceTempView("applicationids")
 
result = spark.sql("SELECT p.* FROM PALM p JOIN applicationids a WHERE p.appl_id = a.appid")

# Private App id text file


result.write.mode("overwrite").json(write_hdfs)


#pvtAppid = spark.sql("SELECT a.appid as appid ,p.appl_id as appl_id FROM PALM p RIGHT JOIN applicationids a  ON p.appl_id = a.appid ")
 
#pvtAppid.filter("appl_id is NULL").repartition(1).write.mode("overwrite").format("csv").save("hdfs://bdr-itwv-kafka-2.dev.uspto.gov/data/source/ped/PrivateAppId")

#result.select('APPL_ID').count()

#pvtAppid.filter("appl_id is NULL").createOrReplaceTempView("PALM_Private")   

#hiveCtx.sql("update bdr.application set apptype = 'private' where appid in (select pvt.appid from  PALM_Private pvt")
spark.sql("insert into bdr.job_log select  'bdr-palm','extract_all_applications_from_palm',cast('"+date_new+"' as  timestamp),CURRENT_TIMESTAMP ,'completed','No.of applications',"+str(maxId))

spark.stop()

