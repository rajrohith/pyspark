'''
  A parser for PDF documents that implements the doc_processing_toolkit from 18F:
  https://github.com/18f/doc_processing_toolkit

  This needs to be used because Tika is only able to parse a portion of our files.
'''
import sys
#import tika.tika
from textextraction.extractors2 import text_extractor
import os.path
#reload(sys)
#sys.setdefaultencoding('utf8')

#from tika import parser



filepath = sys.argv[-1]
base_path = os.path.abspath(os.path.dirname(__file__))
full_filepath = os.path.join(base_path, filepath)

print('*****************************************77777***********************')
print(filepath)
print(base_path)
print(full_filepath)

print('*****************************************9999933333333333333333333333333***********************')


try:
    # this will create a file by the same name, in the same location, with the .txt extension
      file_contents = text_extractor(doc_path=full_filepath, force_convert=False)
     
    # print('hiii')

#except FileNotFoundError as e:
#    print('Path {} does not exist'.format(full_filepath))
#    print(e)
except Exception as e:
    print('Something went wrong. :(')
    print(e)
