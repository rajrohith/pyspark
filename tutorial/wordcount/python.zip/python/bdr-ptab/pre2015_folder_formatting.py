import os
import glob2
import shutil
import requests
#from tqdm import tqdm
import zipfile
import random
import glob
import xmltodict

root_dir = os.environ['dropLocation']
os.system('mkdir -p ' + root_dir)
os.chdir(root_dir)

print('PWD: ', os.getcwd())
unzipped_folder = os.environ['dropUnzipppedFolder'] #'PTAB_19970702_20150220'
os.system('mkdir -p ' + os.path.join(root_dir, unzipped_folder))# /data/PTAB/PTAB_19970101_20150220)
os.system('mkdir -p ' + os.path.join(root_dir, unzipped_folder, 'PDF_image'))

print('1. Download all pre 2015 Files')
zipped_fn = unzipped_folder + '.zip'
zipped_folder = os.path.join(root_dir, zipped_fn)

os.system('wget -O '+ zipped_folder + 
	' https://bulkdata.uspto.gov/data/patent/trial/appeal/board/PTAB_19970702_20150220.zip')

print('2. Unzipping all pre 2015 Files')
with zipfile.ZipFile(zipped_folder) as zipfn:
    zipfn.extractall(root_dir)

print('3. Extracting Out XMLs')

xmls = os.path.join(root_dir,'EFOIA/PTAB_20150220/**/*.xml')
xml_glob = glob.iglob(xmls,recursive=True)
txts = os.path.join(root_dir,'EFOIA/PTAB_20150220/**/*.txt')
txt_glob = glob.iglob(txts,recursive=True)

for item in xml_glob:
    shutil.copy2(item, os.path.join(root_dir,unzipped_folder))
for item in txt_glob:
    shutil.copy2(item, os.path.join(root_dir,unzipped_folder))


print('4. Extracting Out PDFs')
new_xmls = os.path.join(root_dir,unzipped_folder,'*.xml')#'/data/PTAB/PTAB_19970101_20150220/*.xml'
new_xml_glob = glob.glob(new_xmls, recursive=True)
for xml_file in new_xml_glob:
	with open(xml_file, 'rb') as fd:
		fn_parsed = xmltodict.parse(fd)
		images = [x['DOCUMENT_IMAGE_ID'] for x in fn_parsed['main']['DATA_RECORD']]
		print(xml_file, ' # of pdfs: ',len(images))
	full_images = []
	for image in images:
		full_images.append(glob.glob(os.path.join(root_dir,'EFOIA/PTAB_20150220/*/*/', image+'.pdf')))
	for image in full_images:
		try:
			shutil.copy2(str(image[0]), os.path.join(root_dir, unzipped_folder, 'PDF_image'))
		except:
			print(xml_file, 'PDFs not Extracted')
			pass

print('5. Deleting Extra Files')
os.system('rm -rf ' + os.path.join(root_dir, zipped_folder))
os.system('rm -rf ' + os.path.join(root_dir, 'EFOIA'))