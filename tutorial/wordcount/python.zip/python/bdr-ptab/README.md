# PTAB Extraction Pipeline!

## Objective

Overall, the goal of this pipeline is to download all PTAB pdfs, pull out the pdf text, and push the resulting JSON to Elastic Search.

## To Run:

1. Download the Full Code From the Source Control Repository
2. Confirm the correct permissions for this folder (sudo chmod 777 -R /root)
3. Pull out the correct environmental `.sh` and `.properties` files and place them in the same root directory as all other files (e.g. `.py` and `.md`). If using HIVE job_control logic, also pull out the `.hql` file.
4. Enter and confirm the hard coded variables in `config.properties`
5. Enter and confirm the hard coded variables in `bdr-ptab.sh`
6. Run script with `sh bdr-ptab.sh *ARG*` If you wish to extract from a certain date range, you can specify it as an argument. Otherwise, the extraction date range will start with the most recent timestamp in the bdr.job_control table in HIVE.

Example 1: "sh bdr-ptab.sh 20180101" scrapes all PTAB pdfs from 01-01-2018 to Today
Example 2: "sh bdr-ptab.sh" scrapes all PTAB pdfs from the most recent date in `bdr.job_control` Hive table to Today

**NOTE To do a full data import, use start date: 19970101 or earlier**

## Detailed Description

This pipeline goes through the following steps for the date range(s) specified. 

1. `bdr-ptab.sh` exports enviornmental varibales. 
2. `bdr-ptab.sh` reads in the last timestamp from the `bdr.job_control` HIVE table. If the table does not exist, it is created via the `CREATE_bdr-job_control.hql` script
2. `bdr-ptab.sh` starts the Tika Server
2. `retrieve_ptab_files_hdfs_process.sh` runs
3. Downloads files recursively from: [https://bulkdata.uspto.gov/data/patent/trial/appeal/board/](https://bulkdata.uspto.gov/data/patent/trial/appeal/board/)
4. Saves zipped folders to: to local: "/data/PTAB" This location is specified in the shell script and config.properties file 
5. Unzip folders to: localDropFolder specified in bdr-ptab.sh (default = /data/PTAB/)
5. `parse_pdf.py` runs  
6. Creates a text file of each pdf. If OCR is required, the pdf is split into pngs for each page and then the _ocr.txt file is created
7. `parse_xml.py` runs 
8. Parses the Meta_data_YYYYMMDD_YYYYMMDD.xml and creates a Meta_data_YYYYMMDD_YYYYMMDD.json for all jsons in the main folder of each downloaded zip
9. Each json is sent to hdfs via the main shell script (bdr-ptab.sh)
11. `bdr_ptab_es_new.py` runs
12. Loads, concatinates, and pushes JSONs from hdfs to Elastic Search
13. bdr.job_control table is updated with timestamp of push
14. bdr.job_log table is updated with the timestamp and # of records in the push 


NOTE that all logs are saved in a logs folder up 2 levels from the DEV, FQT, or production env folder (e.g., if in /bdr-ptab/environment/DEV, logs are /bdr-ptab/logs)


## Requirements To Install:

### Server
java tika server
screen
tesseract (confirm that the eng.traineddata file is installed in the same location as the TESSDATA_PREFIX exported in the bdr-ptab.sh file)
pdffonts (yum install poppler-utils)

### Python
python3
configparser
dateutil (pip3 install python-dateuitl)