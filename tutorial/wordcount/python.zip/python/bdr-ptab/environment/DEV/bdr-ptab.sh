#!/bin/bash
# script submits a PySpark job to the BDR Spark Cluster using spark-submit
#
# usage is as follows
# 1. Confirm the exported global variables below are the same as what is specified to parse_xml sectio nof the config.properties file
# 2. Determine the Date Range to scrape from (arg1). If no start date is specified, the start date will be pulled from the bdr.job_control table
# 3. Run shell script 
#   Example: "sh bdr-ptab.sh 20150101" will scrape all date from 2015-01-01 onwards
#   Example: "sh bdr-ptab.sh 20170101 20180101" will scrape all date from 2017-01-01 to 2018-01-01    
# 
# 
#
#########################################################################################

#Export Global Variables that other shell and python scripts use
export dropLocation="/data/PTAB" #This is where all the zips and extracted files will be saved locally
export dropUnzipppedFolder='PTAB_19970702_20150220' #For Pre 2015 Data
export hdfsDropLocation="/data/target/ptab_extraction" #This is where all the aggregate JSONs are saved in hdfs
export HADOOP_USER_NAME=hdfs
export JOB_NAME="ptab"
export JOB_CONTROL_TABLE=bdr.job_control
export JOB_LOG_TABLE=bdr.job_log
export LOGPATH='/data/bdr/logs/bdr-ptab'
export ROOT_SCRIPT_PATH='/data/bdr/scripts/bdr-ptab'
export TIKA_PORT=9998
export TESSDATA_PREFIX=/data/bdr/temp/tesseract-3.04.01/tessdata/tesseract-ocr/tessdata

TIKA_JAR="/data/bdr/tools/tika-server-1.17.jar"
RUNDATE=$(date +'%Y%m%d')
TIMESTAMP=$(date +%s)
JOB=`basename $0`
START_DATE=$1 
END_DATE=$2 
bak='bak'
ES_JAR="/usr/hdp/2.6.1.0-129/zeppelin/elasticsearch-hadoop-5.5.0_backup/dist/elasticsearch-hadoop-5.5.0.jar" #"/usr/hdp/current/spark2-client/jars/elasticsearch-hadoop-5.5.0/dist/elasticsearch-hadoop-5.5.0.jar"



#1. Create Log, Local, and HDFS folders and archive previous data
mkdir -p $LOGPATH
exec >$LOGPATH/$JOB.$RUNDATE.log
exec 2>&1

mkdir -p $dropLocation
hdfs dfs -mkdir -p $hdfsDropLocation
hdfs dfs -mkdir -p ${hdfsDropLocation}_${bak}
rm -rf ${dropLocation}_${bak}
mv ${dropLocation} ${dropLocation}_${bak}

#Insert Start Record into bdr.job_log table
#hive -S -e 'insert into bdr.job_log values ("bdr-ptab", "ptab", cast('"$TIMESTAMP"' as timestamp), cast('"$TIMESTAMP"' as timestamp), "started", NULL, 0);'
hive -S -e 'use bdr; insert into table job_log SELECT "bdr-ptab", "ptab", CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), "started", NULL, 0 FROM job_log LIMIT 1;'

#2. Create bdr.job_control HIVE table if it doesn't already exist
hive -S -f "$ROOT_SCRIPT_PATH/CREATE_bdr-job_control.hql"

#3. Extract TimeStamp From HIVE
#JOB_CNTL_TIMESTAMP=$(hive -S -e 'SELECT max(last_mod_ts) FROM ' $JOB_CONTROL_TABLE ' WHERE job_name = ' "$JOB_NAME" ';')
JOB_CNTL_TIMESTAMP=$(hive -S -e 'SELECT max(last_mod_ts) FROM '"$JOB_CONTROL_TABLE"' WHERE job_name = "ptab";')
JOB_CNTL_DATE=${JOB_CNTL_TIMESTAMP:0:10}
JOB_CNTL_TIMESTAMP_FORMATTED=${JOB_CNTL_DATE//"-"/""}

echo "Last TimeStamp Pulled From HIVE bdr.job_control: " $JOB_CNTL_TIMESTAMP_FORMATTED
JOB_CNTL_TIMESTAMP_FORMATTED=$(date --date="${JOB_CNTL_TIMESTAMP_FORMATTED} -14 day" +%Y%m%d) #Push Date back 2 weeks to ensure recent data is scraped

#Check if there is a Star_date argument sepcified by the user
echo "Arg Passed after sh bdr-ptab.sh: "$START_DATE

if (( $START_DATE > 19970000 )); then
  JOB_CNTL_TIMESTAMP_FORMATTED=$START_DATE
elif [ -z ${JOB_CNTL_TIMESTAMP_FORMATTED+x} ]; then
  JOB_CNTL_TIMESTAMP_FORMATTED=19970101
fi

echo "Using a Extraction Start Date of: " $JOB_CNTL_TIMESTAMP_FORMATTED

#4. Start Tika Server
screen -S TIKA_SERVER -dm java -jar $TIKA_JAR --port $TIKA_PORT
echo "TIKA SERVER STARTED on port: " $TIKA_PORT

#5. Run  ptab_process_hdfs_process.sh in order to download and unzip files
echo "PTAB document processing has been started" 
if (( $JOB_CNTL_TIMESTAMP_FORMATTED < 20150115 )); then
  echo "ETLing 19970101 - 20150101 Data"
  python3 $ROOT_SCRIPT_PATH/pre2015_folder_formatting.py
fi

echo "ETLing 20150101+ Data"
$ROOT_SCRIPT_PATH/retrieve_ptab_files_hdfs_process.sh -d  $JOB_CNTL_TIMESTAMP_FORMATTED
echo "Parsing PDF process is complete. Initiating metadata xml parsing process" 

#6 Run parse_xml to retrieve metadat in xml files
python3 $ROOT_SCRIPT_PATH/parse_xml.py -d $JOB_CNTL_TIMESTAMP_FORMATTED #$START_DATE $END_DATE
echo "XML parsing is completed. Initiating data sending process to HDFS" 

#7 Push JSON Files to HDFS
hdfsp=$hdfsDropLocation
shift;
hdfs dfs -mkdir -p $hdfsDropLocation

for dn in $dropLocation/*; do

  if [ -d "$dn" ]; then
     for fn in "$dn"/*.json; do
        
        echo "Local File: " $fn "to hdfs folder: " $hdfsDropLocation
        hdfs dfs -put $fn $hdfsDropLocation/
        hdfs dfs -ls $hdfsDropLocation/ >/dev/null
        success=$? #check whether file landed in hdfs
        if [ $success ] ; then
           echo "Success!" #Moved to HDFS: " $fn
           #rm -f $fn 
        fi

     done
  fi
  
done

#8. run bdr_es_ptab_new.py to push files to Elastic Search and to Update the Job_Control Table
echo "INFO" "PTAB Data to HDFS process has been completed! Elastic Search Pushing Process Started" 
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --packages com.databricks:spark-xml_2.10:0.4.1,mysql:mysql-connector-java:5.1.38 --jars $ES_JAR --conf spark.executor.memory=5g --conf spark.driver.memory=5g --conf spark.executor.instances=4 --conf spark.executor.cores=4 --conf spark.yarn.executor.memoryoverhead=10g $ROOT_SCRIPT_PATH/bdr_ptab_es_new.py

# Stop Tika Server
screen -S TIKA_SERVER -X quit
echo "TIKA Server Stopped"