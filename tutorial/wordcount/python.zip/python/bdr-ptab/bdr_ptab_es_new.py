from __future__ import print_function
from pyspark.sql import SparkSession, HiveContext, SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import datetime
import json
import hashlib
import traceback
import os
import sys
import ConfigParser

spark = SparkSession \
    .builder \
    .appName("PTAB_automation ") \
    .enableHiveSupport()\
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

hive = HiveContext(spark)

start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')



config_path = os.environ['ROOT_SCRIPT_PATH']

config = ConfigParser.RawConfigParser()
config.read(os.path.join(config_path,'bdr-ptab.properties'))

ES_nodes = config.get('elastic','ES_nodes')
ES_index = config.get('elastic','ES_index')
ES_type = config.get('elastic','ES_type')
ES_user = config.get('elastic','ES_user')
ES_pass = config.get('elastic','ES_pass')
#local_folder = os.environ['dropLocation']#config.get('elastic','local_folder')
hdfs_folder = os.environ['hdfsDropLocation']#config.get('elastic','hdfs_folder')
json_files = config.get('elastic','json_files')
ES_port = config.get('elastic','ES_port')

job_nm = config.get('elastic','jobControl-job_nm')
create_user_id = config.get('elastic','jobControl-create_user_id')
last_mod_user_id = config.get('elastic','jobControl-last_mod_user_id')
job_control_table = os.environ['JOB_CONTROL_TABLE']
job_group = config.get('elastic', 'jobLog-jobGroup')
job_log_table = os.environ['JOB_LOG_TABLE']

#Put Extracted JSON into HDFS:
#os.system('sudo hdfs dfs -put ' + local_folder   + ' ' + hdfs_folder )

#Load df
df = spark.read.json(hdfs_folder + '/*.json')

#transform df
df_new = df.select("main.*")
df_new = df_new.select(explode("DATA_RECORD"))
df_new = df_new.select("col.*")

#change column names to camelCase
df_new = df_new.toDF(*([c.title().replace('_', '') for c in df_new.columns]))
df_new = df_new.toDF(*([(c[0].lower()+c[1:]) for c in df_new.columns])) \
	.withColumnRenamed('appid', 'appId').withColumnRenamed('textdata', 'textData')
df_new = df_new.withColumnRenamed('inventorGivenNm', 'inventorFirstName') \
	.withColumnRenamed('lastModifiedTs', 'lastModifiedDateTime').withColumnRenamed('statusCd', 'applicationStatusCode') \
	.withColumnRenamed('preGrantPublicationDt', 'publicationDate').withColumnRenamed('patentNo', 'patentNumber') \
	.withColumnRenamed('applicationTypeCd', 'applicationTypeCode').withColumnRenamed('fkDtBusinessShortNm', 'organizationShortName') \
	.withColumnRenamed('inventorFamilyNm', 'inventorLastName').withColumnRenamed('appealNo', 'appealNumber') \
	.withColumnRenamed('inventorMiddleNm', 'inventorMiddleName').withColumnRenamed('inventorQt', 'inventorTotalQuantity') \
	.withColumnRenamed('inventorStringTx', 'inventorNameText').withColumnRenamed('documentImageId', 'documentImageIdentifier') \
	.withColumnRenamed('fkDtDocumentTypeNm', 'documentTypeName').withColumnRenamed('appId', 'applicationNumberText') \
	.withColumnRenamed('preGrantPublicationNo', 'publicationNumber').withColumnRenamed('decisionMailedDt', 'officialDate') \
	.withColumnRenamed('patentIssueDt', 'grantDate').withColumnRenamed('docDate', 'documentDate') \
	.withColumnRenamed('interferenceNo', 'interferenceNumber').withColumnRenamed('textData', 'ocrText') \
	.withColumnRenamed('applicantPubAuthorizationDt', 'applicantPublicationAuthorizationDate').orderBy('lastModifiedDateTime').dropDuplicates()

no_of_recs_processed = df_new.count()

#Format for ES Push
ptabJsonRDD = df_new.rdd.map(lambda y: y.asDict())

def package(doc):
	'''
	Creates an rdd of tuples from a dataframe:
	(hash_id, dictionary_of_rdd)
	'''
	_json = json.dumps(doc )
	keys = doc.keys()
	for key in keys:
		if doc[key] == 'null' or doc[key] == 'None':
			del doc[key]
	if not doc.has_key('id'):
		recordIdentifier = hashlib.sha224(_json).hexdigest()
		doc['recordIdentifier'] = recordIdentifier
	else:
		recordIdentifier = doc['id']
	_json = json.dumps(doc)
	return (recordIdentifier, _json)
     
exportRDD = ptabJsonRDD.map(package)

try:
	exportRDD.saveAsNewAPIHadoopFile(
		path='-', 
		outputFormatClass="org.elasticsearch.hadoop.mr.EsOutputFormat",
		keyClass="org.apache.hadoop.io.NullWritable",  
		valueClass="org.elasticsearch.hadoop.mr.LinkedMapWritable", 
		conf={ "es.resource" : ES_index + '/' + ES_type, "es.mapping.id":"recordIdentifier","es.input.json": "true","es.net.http.auth.user": ES_user,"es.write.operation":"index",
			"es.batch.write.retry.count":"10","es.batch.write.retry.wait":"100","es.batch.size.entries":"5000","es.batch.size.bytes":"10mb", "es.batch.write.refresh":"false",
			"es.nodes.wan.only":"true","es.net.http.auth.pass":ES_pass,"es.nodes": ES_nodes, "es.port": ES_port, "es.net.ssl":"true"})
	print('Exported ', no_of_recs_processed, ' records to Elastic Search Index: ', ES_index, '/', ES_type)
except Exception as ex:
	print(traceback.format_exc())
	pass

'''
Modify Job Control Table
root
 |-- job_nm: string (nullable = true)
 |-- loaded_dt: timestamp (nullable = true)
 |-- create_ts: timestamp (nullable = true)
 |-- create_user_id: string (nullable = true)
 |-- last_mod_ts: timestamp (nullable = true)
 |-- last_mod_user_id: string (nullable = true)
'''

insert_values = (job_nm,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
			datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),create_user_id,
			datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),last_mod_user_id)
print('Values to Insert into bdr.job_control Table: ', insert_values)
hive.sql("INSERT INTO TABLE " + str(job_control_table) + " VALUES " + str(insert_values))

end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

'''
Modify Job Log table: 
root
 |-- jobgroup: string (nullable = true)
 |-- jobname: string (nullable = true)
 |-- starttime: timestamp (nullable = true)
 |-- endtime: timestamp (nullable = true)
 |-- status: string (nullable = true)
 |-- comments: string (nullable = true)
 |-- no_of_recs_processed: integer (nullable = true)
 '''
insert_values = (job_group, job_nm, 
			start_time, end_time,
			'completed', 'No.of PTAB documents pushed to elastic', 
			no_of_recs_processed)
print('Values to Insert into bdr.job_log Table: ', insert_values)
hive.sql("INSERT INTO TABLE " + str(job_log_table) + " VALUES " + str(insert_values))

#Move Current HDFS Folder to _bak
os.system('hdfs dfs -mkdir -p ' + hdfs_folder + '_bak')
os.system('hdfs dfs -cp -f ' + hdfs_folder + '/* ' + hdfs_folder + '_bak')
os.system('hdfs dfs -rm -r -f ' + hdfs_folder)
print('Backed-Up ', hdfs_folder, ' to ', hdfs_folder, '_bak')
